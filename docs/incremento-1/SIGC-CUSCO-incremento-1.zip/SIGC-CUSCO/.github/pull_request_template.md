## Historia

SIGC-__ · (título de la historia en Jira)

## Qué cambia

-

## Definición de hecho

- [ ] Cumple los criterios de aceptación (Dado / Cuando / Entonces) de la historia
- [ ] Pruebas nuevas o actualizadas; `npm test` en verde
- [ ] `npm run lint` y `npm run typecheck` sin advertencias
- [ ] CI en verde (backend, frontend y CodeQL)
- [ ] Revisado y aprobado por otra persona del equipo
- [ ] Probado en el navegador, también en pantalla de teléfono
- [ ] Si se usó IA: registro agregado en `docs/proceso/registro-ia.md`

## Evidencia

(capturas o salida de las pruebas)
