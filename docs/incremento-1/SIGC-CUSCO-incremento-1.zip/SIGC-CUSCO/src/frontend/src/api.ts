export type Rol = 'Admin' | 'Coordinador' | 'Docente' | 'Participante';

export interface Sesion {
  id: number;
  rol: Rol;
  nombre: string;
  institucion: number | null;
}

export class ErrorApi extends Error {
  constructor(public status: number, mensaje: string, public detalles?: Record<string, string> & { pendientes?: string[] }) {
    super(mensaje);
  }
}

const CLAVE_TOKEN = 'sigc.token';

export const token = {
  leer: () => localStorage.getItem(CLAVE_TOKEN),
  guardar: (t: string) => localStorage.setItem(CLAVE_TOKEN, t),
  borrar: () => localStorage.removeItem(CLAVE_TOKEN),
};

async function peticion(metodo: string, ruta: string, cuerpo?: unknown): Promise<Response> {
  const cab: Record<string, string> = {};
  const t = token.leer();
  if (t) cab.Authorization = `Bearer ${t}`;
  if (cuerpo !== undefined) cab['Content-Type'] = 'application/json';
  let r: Response;
  try {
    r = await fetch(`/api${ruta}`, { method: metodo, headers: cab, body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo) });
  } catch {
    throw new ErrorApi(0, 'Sin conexión con el servidor. Revisa tu internet e inténtalo otra vez.');
  }
  if (!r.ok) {
    let datos: { error?: string; detalles?: Record<string, string> } = {};
    try { datos = await r.json(); } catch { /* respuesta sin JSON */ }
    throw new ErrorApi(r.status, datos.error ?? `Error ${r.status}`, datos.detalles);
  }
  return r;
}

export const api = {
  async get<T>(ruta: string): Promise<T> { return (await peticion('GET', ruta)).json(); },
  async post<T>(ruta: string, cuerpo: unknown = {}): Promise<T> { return (await peticion('POST', ruta, cuerpo)).json(); },
  async put<T>(ruta: string, cuerpo: unknown): Promise<T> { return (await peticion('PUT', ruta, cuerpo)).json(); },
  async patch<T>(ruta: string, cuerpo: unknown): Promise<T> { return (await peticion('PATCH', ruta, cuerpo)).json(); },
  async borrar(ruta: string): Promise<void> { await peticion('DELETE', ruta); },
  /** Descarga un archivo (PDF, Excel) respetando la sesión. */
  async descargar(ruta: string, nombre: string): Promise<void> {
    const r = await peticion('GET', ruta);
    const url = URL.createObjectURL(await r.blob());
    const a = document.createElement('a');
    a.href = url;
    a.download = nombre;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
};

// ---------- Tipos compartidos ----------

export interface Capacitacion {
  id_capacitacion: number;
  titulo: string;
  descripcion: string;
  modalidad: 'Presencial' | 'Virtual' | 'Mixta';
  lugar: string;
  horas_academicas: number;
  vacantes_max: number;
  numero_sesiones: number;
  asistencia_minima: number;
  fecha_inicio: string;
  fecha_fin: string | null;
  estado: 'Planificada' | 'Abierta' | 'En_Curso' | 'Finalizada';
  acta_cerrada: boolean;
  id_institucion: number;
  id_docente: number | null;
  institucion: string;
  tipo_institucion: 'Publica' | 'Privada';
  docente: string | null;
  inscritos: number;
  disponibles: number;
}

export interface Institucion { id_institucion: number; razon_social: string; tipo: 'Publica' | 'Privada'; ruc: string; activo: boolean; capacitaciones?: number }

const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'set', 'oct', 'nov', 'dic'];

/** "2026-10-19" → "19 oct" (sin desplazar el día por zona horaria). */
export function fechaCorta(iso: string | null): string {
  if (!iso) return '';
  const [, m, d] = iso.slice(0, 10).split('-').map(Number);
  return `${d} ${MESES[m - 1]}`;
}

export function fechaLarga(iso: string | null): string {
  if (!iso) return '';
  const [a, m, d] = iso.slice(0, 10).split('-').map(Number);
  return `${d} ${MESES[m - 1]} ${a}`;
}

export function fechaHora(iso: string): string {
  return new Date(iso).toLocaleString('es-PE', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'America/Lima' });
}

export const etiquetaEstado: Record<Capacitacion['estado'], string> = {
  Planificada: 'Planificada',
  Abierta: 'Inscripción abierta',
  En_Curso: 'En curso',
  Finalizada: 'Finalizada',
};
