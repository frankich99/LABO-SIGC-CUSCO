/**
 * Cola de asistencias sin conexión (HU-11 · RNF-05) guardada en IndexedDB.
 * Cada registro conserva la hora en que se marcó para sincronizarlo después.
 */
export interface Pendiente {
  clave: string;
  idCapacitacion: number;
  sesion: number;
  identificador: string;
  estado: 'Presente' | 'Tardanza';
  fecha_hora: string;
}

const BASE = 'sigc-offline';
const ALMACEN = 'asistencias';

function abrir(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open(BASE, 1);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains(ALMACEN)) db.createObjectStore(ALMACEN, { keyPath: 'clave' }).createIndex('curso', 'idCapacitacion');
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

async function operar<T>(modo: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await abrir();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(ALMACEN, modo);
    const req = fn(tx.objectStore(ALMACEN));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export const cola = {
  agregar(p: Omit<Pendiente, 'clave' | 'fecha_hora'>): Promise<IDBValidKey> {
    const registro: Pendiente = { ...p, clave: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, fecha_hora: new Date().toISOString() };
    return operar('readwrite', (s) => s.put(registro));
  },
  delCurso(idCapacitacion: number): Promise<Pendiente[]> {
    return operar('readonly', (s) => s.index('curso').getAll(idCapacitacion) as IDBRequest<Pendiente[]>);
  },
  quitar(clave: string): Promise<undefined> {
    return operar('readwrite', (s) => s.delete(clave) as IDBRequest<undefined>);
  },
};
