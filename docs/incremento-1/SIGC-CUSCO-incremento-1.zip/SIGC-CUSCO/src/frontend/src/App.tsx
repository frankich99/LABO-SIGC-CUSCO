import { useEffect, useState, type ReactNode } from 'react';
import { Link, Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import type { Rol } from './api';
import { Cargando } from './componentes/ui';
import { Asistencia } from './paginas/Asistencia';
import { Catalogo } from './paginas/Catalogo';
import { Detalle } from './paginas/Detalle';
import { FormularioCurso } from './paginas/FormularioCurso';
import { Gestion } from './paginas/Gestion';
import { GestionCurso } from './paginas/GestionCurso';
import { Ingresar } from './paginas/Ingresar';
import { Instituciones } from './paginas/Instituciones';
import { MisInscripciones } from './paginas/MisInscripciones';
import { Correos } from './paginas/Correos';
import { Reportes } from './paginas/Reportes';
import { Usuarios } from './paginas/Usuarios';
import { Verificar } from './paginas/Verificar';
import { useSesion } from './sesion';

function Protegida({ roles, children }: { roles: Rol[]; children: ReactNode }) {
  const { usuario, cargando } = useSesion();
  const loc = useLocation();
  if (cargando) return <Cargando />;
  if (!usuario) return <Navigate to={`/ingresar?volver=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  if (!roles.includes(usuario.rol)) return <p className="py-8">Tu rol ({usuario.rol}) no tiene acceso a esta sección.</p>;
  return <>{children}</>;
}

function Enlace({ a, children }: { a: string; children: ReactNode }) {
  return (
    <NavLink to={a} end={a === '/'}
      className={({ isActive }) => `rounded-md px-2.5 py-1.5 ${isActive ? 'bg-carmin-claro font-bold text-carmin' : 'hover:bg-papel'}`}>
      {children}
    </NavLink>
  );
}

function Indicador() {
  const [enLinea, setEnLinea] = useState(navigator.onLine);
  useEffect(() => {
    const on = () => setEnLinea(true);
    const off = () => setEnLinea(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  if (enLinea) return null;
  return <div className="bg-alerta px-4 py-1.5 text-center text-sm font-bold text-white">Sin conexión. Las asistencias que marques se guardan en este equipo.</div>;
}

function Cabecera() {
  const { usuario, salir, tiene } = useSesion();
  return (
    <header className="border-b border-linea bg-blanco">
      <div className="franja" aria-hidden="true" />
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
        <Link to="/" className="mr-auto leading-tight">
          <span className="block text-xl font-bold text-carmin">SIGC-CUSCO</span>
          <span className="block text-sm text-gris">Capacitaciones de municipalidades y empresas del Cusco</span>
        </Link>
        <nav aria-label="Principal" className="flex flex-wrap items-center gap-1 text-[0.97rem]">
          <Enlace a="/">Capacitaciones</Enlace>
          <Enlace a="/verificar">Verificar certificado</Enlace>
          {tiene('Participante') && <Enlace a="/mis-inscripciones">Mis inscripciones</Enlace>}
          {tiene('Admin', 'Coordinador', 'Docente') && <Enlace a="/gestion">Mis cursos</Enlace>}
          {tiene('Admin', 'Coordinador') && <Enlace a="/reportes">Reportes</Enlace>}
          {tiene('Admin') && <Enlace a="/admin/usuarios">Usuarios</Enlace>}
          {tiene('Admin') && <Enlace a="/admin/instituciones">Instituciones</Enlace>}
          {usuario ? (
            <span className="ml-2 flex items-center gap-2 border-l border-linea pl-3">
              <span className="text-sm leading-tight"><b className="block">{usuario.nombre}</b><span className="text-gris">{usuario.rol}</span></span>
              <button type="button" onClick={salir} className="boton-sec !px-3 !py-1.5 text-sm">Cerrar sesión</button>
            </span>
          ) : (
            <Link to="/ingresar" className="boton ml-2 !py-1.5">Ingresar</Link>
          )}
        </nav>
      </div>
    </header>
  );
}

export function App() {
  return (
    <div className="flex min-h-screen flex-col">
      <Indicador />
      <Cabecera />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <Routes>
          <Route path="/" element={<Catalogo />} />
          <Route path="/capacitaciones/:id" element={<Detalle />} />
          <Route path="/ingresar" element={<Ingresar />} />
          <Route path="/verificar" element={<Verificar />} />
          <Route path="/verificar/:codigo" element={<Verificar />} />
          <Route path="/asistencia" element={<Protegida roles={['Participante']}><Asistencia /></Protegida>} />
          <Route path="/mis-inscripciones" element={<Protegida roles={['Participante']}><MisInscripciones /></Protegida>} />
          <Route path="/gestion" element={<Protegida roles={['Admin', 'Coordinador', 'Docente']}><Gestion /></Protegida>} />
          <Route path="/gestion/nueva" element={<Protegida roles={['Admin', 'Coordinador']}><FormularioCurso /></Protegida>} />
          <Route path="/gestion/:id/editar" element={<Protegida roles={['Admin', 'Coordinador']}><FormularioCurso /></Protegida>} />
          <Route path="/gestion/:id" element={<Protegida roles={['Admin', 'Coordinador', 'Docente']}><GestionCurso /></Protegida>} />
          <Route path="/reportes" element={<Protegida roles={['Admin', 'Coordinador']}><Reportes /></Protegida>} />
          <Route path="/admin/usuarios" element={<Protegida roles={['Admin']}><Usuarios /></Protegida>} />
          <Route path="/admin/instituciones" element={<Protegida roles={['Admin']}><Instituciones /></Protegida>} />
          <Route path="/admin/correos" element={<Protegida roles={['Admin']}><Correos /></Protegida>} />
          <Route path="*" element={<p className="py-8">Esta página no existe. <Link className="text-carmin underline" to="/">Ver capacitaciones</Link></p>} />
        </Routes>
      </main>
      <footer className="border-t border-linea bg-blanco">
        <div className="mx-auto max-w-6xl px-4 py-5 text-sm text-gris">
          SIGC-CUSCO · Proyecto de Ingeniería de Software I, UNSAAC 2026-II. Los certificados se verifican en <Link className="underline" to="/verificar">/verificar</Link>.
        </div>
      </footer>
    </div>
  );
}
