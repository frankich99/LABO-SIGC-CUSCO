import { useEffect, useState } from 'react';
import { api, fechaHora } from '../api';
import { Cargando, Titulo } from '../componentes/ui';

interface Notificacion { id_notificacion: number; destinatario: string; asunto: string; cuerpo: string; estado: string; creado_en: string }

export function Correos() {
  const [lista, setLista] = useState<Notificacion[] | null>(null);
  useEffect(() => { api.get<Notificacion[]>('/notificaciones').then(setLista); }, []);
  if (!lista) return <Cargando />;
  return (
    <>
      <Titulo sub="Últimos 50 correos. «Simulado» significa que no hay servidor SMTP configurado y el mensaje quedó solo registrado.">Correos del sistema</Titulo>
      <ul className="space-y-3">
        {lista.map((n) => (
          <li key={n.id_notificacion} className="rounded-xl border border-linea bg-blanco p-4">
            <p className="flex flex-wrap justify-between gap-2"><b>{n.asunto}</b><span className="text-sm text-gris">{n.estado} · {fechaHora(n.creado_en)}</span></p>
            <p className="text-sm text-gris">Para: {n.destinatario}</p>
            <pre className="mt-2 font-sans text-[0.95rem] whitespace-pre-wrap">{n.cuerpo}</pre>
          </li>
        ))}
        {lista.length === 0 && <li className="text-gris">Aún no se envió ningún correo.</li>}
      </ul>
    </>
  );
}
