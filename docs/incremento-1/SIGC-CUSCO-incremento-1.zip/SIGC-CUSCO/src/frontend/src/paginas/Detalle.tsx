import { useEffect, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, ErrorApi, fechaLarga, type Capacitacion, type Sesion } from '../api';
import { Aviso, Campo, Cargando, EstadoCurso, Vacantes } from '../componentes/ui';
import { useSesion } from '../sesion';

interface RespuestaInscripcion {
  id_inscripcion: number;
  credencial: string;
  disponibles: number;
  cuenta_nueva: boolean;
  token: string;
  usuario: Sesion;
}

export function Detalle() {
  const { id } = useParams();
  const { usuario, entrar } = useSesion();
  const [c, setC] = useState<Capacitacion | null>(null);
  const [errorCarga, setErrorCarga] = useState('');
  const [form, setForm] = useState({ dni: '', nombres: '', apellidos: '', correo: '', password: '' });
  const [tieneCuenta, setTieneCuenta] = useState(false);
  const [errores, setErrores] = useState<Record<string, string>>({});
  const [mensaje, setMensaje] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [hecho, setHecho] = useState<RespuestaInscripcion | null>(null);

  useEffect(() => {
    api.get<Capacitacion>(`/capacitaciones/${id}`).then(setC).catch((e) => setErrorCarga(e.message));
  }, [id, hecho]);

  const cambiar = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });

  async function inscribir(e: FormEvent) {
    e.preventDefault();
    setErrores({});
    setMensaje('');
    if (!/^\d{8}$/.test(form.dni)) { setErrores({ dni: 'El DNI debe tener exactamente 8 dígitos.' }); return; }
    setEnviando(true);
    try {
      const cuerpo = tieneCuenta ? { dni: form.dni, password: form.password } : form;
      const r = await api.post<RespuestaInscripcion>(`/capacitaciones/${id}/inscripciones`, cuerpo);
      entrar(r.token, r.usuario);
      setHecho(r);
    } catch (err) {
      if (err instanceof ErrorApi) {
        setMensaje(err.message);
        setErrores(err.detalles ?? {});
        if (err.status === 401) setTieneCuenta(true);
      }
    } finally {
      setEnviando(false);
    }
  }

  if (errorCarga) return <Aviso tono="error">{errorCarga}</Aviso>;
  if (!c) return <Cargando />;

  const abierta = c.estado === 'Abierta' && c.disponibles > 0;
  const puedeUsarCuenta = usuario?.rol === 'Participante';

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_24rem]">
      <article>
        <p className="mb-2"><Link to="/" className="text-carmin underline">Capacitaciones</Link></p>
        <h1 className="text-3xl font-bold sm:text-4xl">{c.titulo}</h1>
        <p className="mt-2 text-lg text-gris">{c.institucion}</p>
        <div className="mt-4"><EstadoCurso estado={c.estado} /></div>
        {c.descripcion && <p className="mt-6 max-w-prose text-lg">{c.descripcion}</p>}
        <dl className="mt-8 grid max-w-2xl grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-3">
          <div><dt className="text-gris">Fechas</dt><dd className="font-bold">{fechaLarga(c.fecha_inicio)}{c.fecha_fin ? ` al ${fechaLarga(c.fecha_fin)}` : ''}</dd></div>
          <div><dt className="text-gris">Duración</dt><dd className="font-bold">{c.horas_academicas} horas académicas</dd></div>
          <div><dt className="text-gris">Sesiones</dt><dd className="font-bold">{c.numero_sesiones}</dd></div>
          <div><dt className="text-gris">Modalidad</dt><dd className="font-bold">{c.modalidad}</dd></div>
          {c.lugar && <div><dt className="text-gris">Lugar</dt><dd className="font-bold">{c.lugar}</dd></div>}
          {c.docente && <div><dt className="text-gris">Docente</dt><dd className="font-bold">{c.docente}</dd></div>}
        </dl>
        <p className="mt-8 max-w-prose rounded-lg bg-blanco p-4 text-[0.97rem] text-gris ring-1 ring-linea">
          Para recibir el certificado necesitas nota final de 11 o más y asistir al menos al {c.asistencia_minima} % de las sesiones.
        </p>
      </article>

      <aside className="h-fit rounded-xl border border-linea bg-blanco p-5">
        {hecho ? (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-exito">Inscripción confirmada</h2>
            <p>Te enviamos la confirmación a tu correo. En cada sesión, escanea el QR que proyecta el docente o muestra tu credencial.</p>
            {hecho.cuenta_nueva && <p className="text-gris">Creamos tu cuenta con tu DNI. Usa la misma contraseña para volver a ingresar.</p>}
            <p className="rounded-lg bg-papel p-3 text-sm">Tu código de credencial: <b className="break-all">{hecho.credencial}</b></p>
            <Link to="/mis-inscripciones" className="boton w-full">Ver mis inscripciones</Link>
          </div>
        ) : (
          <>
            <h2 className="text-2xl font-bold">Inscribirme</h2>
            <div className="my-4"><Vacantes inscritos={c.inscritos} total={c.vacantes_max} /></div>
            {!abierta && <Aviso tono="alerta">{c.estado !== 'Abierta' ? 'La inscripción para esta capacitación está cerrada.' : 'Ya no quedan vacantes.'}</Aviso>}
            {abierta && (
              <form onSubmit={inscribir} className="space-y-4" noValidate>
                {mensaje && <Aviso tono="error">{mensaje}</Aviso>}
                <Campo etiqueta="DNI" inputMode="numeric" autoComplete="off" maxLength={8} value={form.dni} onChange={cambiar('dni')} error={errores.dni} required />
                <fieldset className="flex gap-4 text-[0.97rem]">
                  <legend className="sr-only">¿Ya tienes cuenta?</legend>
                  <label className="flex items-center gap-2"><input type="radio" checked={!tieneCuenta} onChange={() => setTieneCuenta(false)} /> Es mi primera vez</label>
                  <label className="flex items-center gap-2"><input type="radio" checked={tieneCuenta} onChange={() => setTieneCuenta(true)} /> Ya tengo cuenta</label>
                </fieldset>
                {!tieneCuenta && (
                  <>
                    <Campo etiqueta="Nombres" autoComplete="given-name" value={form.nombres} onChange={cambiar('nombres')} error={errores.nombres} />
                    <Campo etiqueta="Apellidos" autoComplete="family-name" value={form.apellidos} onChange={cambiar('apellidos')} error={errores.apellidos} />
                    <Campo etiqueta="Correo" type="email" autoComplete="email" value={form.correo} onChange={cambiar('correo')} error={errores.correo} />
                  </>
                )}
                <Campo etiqueta={tieneCuenta ? 'Contraseña' : 'Crea una contraseña'} type="password"
                  autoComplete={tieneCuenta ? 'current-password' : 'new-password'} value={form.password} onChange={cambiar('password')}
                  error={errores.password} ayuda={tieneCuenta ? undefined : 'Mínimo 8 caracteres. La usarás para descargar tu certificado.'} />
                <button className="boton w-full" disabled={enviando}>{enviando ? 'Inscribiendo…' : 'Inscribirme'}</button>
                {puedeUsarCuenta && <p className="text-sm text-gris">Sesión iniciada como {usuario.nombre}. Ingresa tu DNI y contraseña para confirmar.</p>}
              </form>
            )}
          </>
        )}
      </aside>
    </div>
  );
}
