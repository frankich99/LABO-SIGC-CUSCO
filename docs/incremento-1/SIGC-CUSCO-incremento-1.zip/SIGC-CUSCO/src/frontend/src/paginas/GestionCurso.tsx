import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, ErrorApi, fechaHora, fechaLarga, type Capacitacion } from '../api';
import { cola, type Pendiente } from '../cola';
import { Aviso, Cargando, Condicion, EstadoCurso } from '../componentes/ui';
import { useSesion } from '../sesion';

interface Inscrito {
  id_inscripcion: number;
  estado: string;
  nota_final: number | null;
  dni: string;
  nombres: string;
  apellidos: string;
  asistidas: number;
  certificado: string | null;
}

interface Marca { id_inscripcion: number; numero_sesion: number; estado: string; metodo: string; fecha_hora: string }

type Pestana = 'asistencia' | 'notas' | 'certificados' | 'reportes';
type Mensaje = { tono: 'exito' | 'alerta' | 'error'; texto: string } | null;

// ---------- QR proyectado ----------

function QrSesion({ idCap, sesion }: { idCap: number; sesion: number }) {
  const [qr, setQr] = useState<{ qr: string; url: string; expira: number } | null>(null);
  const [resta, setResta] = useState(0);
  const [error, setError] = useState('');

  const generar = useCallback(() => {
    api.post<{ qr: string; url: string; expira: number }>(`/capacitaciones/${idCap}/sesiones/${sesion}/qr`)
      .then((r) => { setQr(r); setError(''); })
      .catch((e) => setError(e.message));
  }, [idCap, sesion]);

  useEffect(generar, [generar]);
  useEffect(() => {
    const t = setInterval(() => {
      if (!qr) return;
      const s = Math.max(0, Math.round((qr.expira - Date.now()) / 1000));
      setResta(s);
      if (s <= 5) generar(); // se renueva antes de vencer
    }, 1000);
    return () => clearInterval(t);
  }, [qr, generar]);

  if (error) return <Aviso tono="error">{error}</Aviso>;
  if (!qr) return <Cargando texto="Generando QR…" />;
  return (
    <div className="rounded-xl border border-linea bg-white p-6 text-center">
      <p className="text-2xl font-bold">Sesión {sesion}: escanea para marcar tu asistencia</p>
      <img src={qr.qr} alt={`QR de asistencia de la sesión ${sesion}`} className="mx-auto my-4 w-full max-w-sm" />
      <p className="text-gris">El código se renueva solo. Vence en {resta} s.</p>
    </div>
  );
}

// ---------- Asistencia ----------

function PestanaAsistencia({ c, inscritos, recargar }: { c: Capacitacion; inscritos: Inscrito[]; recargar: () => void }) {
  const [sesion, setSesion] = useState(1);
  const [proyectar, setProyectar] = useState(false);
  const [ident, setIdent] = useState('');
  const [estado, setEstado] = useState<'Presente' | 'Tardanza'>('Presente');
  const [msg, setMsg] = useState<Mensaje>(null);
  const [marcas, setMarcas] = useState<Marca[]>([]);
  const [pendientes, setPendientes] = useState<Pendiente[]>([]);
  const [sincronizando, setSincronizando] = useState(false);
  const enCurso = useRef(false);

  const cargarMarcas = useCallback(() => {
    api.get<Marca[]>(`/capacitaciones/${c.id_capacitacion}/asistencias`).then(setMarcas).catch(() => undefined);
    cola.delCurso(c.id_capacitacion).then(setPendientes);
  }, [c.id_capacitacion]);
  useEffect(cargarMarcas, [cargarMarcas]);

  const sincronizar = useCallback(async () => {
    if (enCurso.current || !navigator.onLine) return; // evita dos envíos simultáneos de la misma cola
    enCurso.current = true;
    try {
      const lista = await cola.delCurso(c.id_capacitacion);
      if (lista.length === 0) return;
      setSincronizando(true);
      const r = await api.post<{ resultados: { clave: string; resultado: string; mensaje: string }[] }>(
        `/capacitaciones/${c.id_capacitacion}/asistencias/sync`,
        { registros: lista.map(({ clave, sesion: s, identificador, estado: e, fecha_hora }) => ({ clave, sesion: s, identificador, estado: e, fecha_hora })) },
      );
      for (const x of r.resultados) if (x.resultado !== 'error') await cola.quitar(x.clave);
      const ok = r.resultados.filter((x) => x.resultado === 'registrado').length;
      const dup = r.resultados.filter((x) => x.resultado === 'duplicado').length;
      const err = r.resultados.filter((x) => x.resultado === 'error');
      setMsg({
        tono: err.length ? 'alerta' : 'exito',
        texto: `Sincronizadas ${ok} asistencias${dup ? `, ${dup} ya estaban registradas` : ''}${err.length ? `. ${err.length} con error: ${err.map((e) => e.mensaje).join('; ')}` : '.'}`,
      });
      cargarMarcas();
      recargar();
    } catch (e) {
      setMsg({ tono: 'error', texto: e instanceof ErrorApi ? e.message : 'No se pudo sincronizar.' });
    } finally {
      enCurso.current = false;
      setSincronizando(false);
    }
  }, [c.id_capacitacion, cargarMarcas, recargar]);

  useEffect(() => {
    sincronizar();
    window.addEventListener('online', sincronizar);
    return () => window.removeEventListener('online', sincronizar);
  }, [sincronizar]);

  async function marcar(e: FormEvent) {
    e.preventDefault();
    const id = ident.trim();
    if (!id) return;
    setMsg(null);
    const guardarLocal = async () => {
      await cola.agregar({ idCapacitacion: c.id_capacitacion, sesion, identificador: id, estado });
      setMsg({ tono: 'alerta', texto: `Sin conexión: guardé la asistencia de ${id} en este equipo. Se enviará al volver la red.` });
      setIdent('');
      cola.delCurso(c.id_capacitacion).then(setPendientes);
    };
    if (!navigator.onLine) return guardarLocal();
    try {
      const r = await api.post<{ participante: string }>(`/capacitaciones/${c.id_capacitacion}/asistencias`, { sesion, identificador: id, estado });
      setMsg({ tono: 'exito', texto: `${r.participante}: ${estado.toLowerCase()} en la sesión ${sesion}.` });
      setIdent('');
      cargarMarcas();
      recargar();
    } catch (err) {
      if (err instanceof ErrorApi && err.status === 0) return guardarLocal();
      setMsg({ tono: err instanceof ErrorApi && err.status === 409 ? 'alerta' : 'error', texto: err instanceof Error ? err.message : 'Error' });
    }
  }

  const porCelda = useMemo(() => {
    const m = new Map<string, Marca>();
    for (const x of marcas) m.set(`${x.id_inscripcion}-${x.numero_sesion}`, x);
    return m;
  }, [marcas]);
  const sesiones = Array.from({ length: c.numero_sesiones }, (_, i) => i + 1);

  if (c.acta_cerrada) {
    return <Aviso>El acta está cerrada; la asistencia quedó como se muestra en los reportes.</Aviso>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end gap-4">
        <div>
          <label htmlFor="sesion" className="mb-1 block font-bold">Sesión</label>
          <select id="sesion" className="campo !w-40" value={sesion} onChange={(e) => setSesion(Number(e.target.value))}>
            {sesiones.map((s) => <option key={s} value={s}>Sesión {s}</option>)}
          </select>
        </div>
        <button type="button" className={proyectar ? 'boton-sec' : 'boton'} onClick={() => setProyectar(!proyectar)}>
          {proyectar ? 'Dejar de proyectar' : 'Proyectar QR de la sesión'}
        </button>
      </div>

      {proyectar && <QrSesion idCap={c.id_capacitacion} sesion={sesion} />}

      <form onSubmit={marcar} className="grid gap-3 rounded-xl border border-linea bg-blanco p-4 sm:grid-cols-[1fr_auto_auto] sm:items-end">
        <div>
          <label htmlFor="ident" className="mb-1 block font-bold">Marcar por DNI o código de credencial</label>
          <input id="ident" className="campo" placeholder="70123450 o INS-12-…" value={ident} onChange={(e) => setIdent(e.target.value)} />
        </div>
        <select aria-label="Estado" className="campo !w-36" value={estado} onChange={(e) => setEstado(e.target.value as 'Presente' | 'Tardanza')}>
          <option>Presente</option><option>Tardanza</option>
        </select>
        <button className="boton">Marcar</button>
      </form>
      {msg && <Aviso tono={msg.tono}>{msg.texto}</Aviso>}

      {pendientes.length > 0 && (
        <div className="rounded-xl border border-alerta/40 bg-alerta-claro p-4">
          <p className="font-bold text-alerta">{pendientes.length} asistencia(s) guardadas en este equipo, sin enviar</p>
          <ul className="mt-2 text-sm">
            {pendientes.map((p) => <li key={p.clave}>Sesión {p.sesion} · {p.identificador} · {p.estado} · {fechaHora(p.fecha_hora)}</li>)}
          </ul>
          <button type="button" className="boton mt-3" onClick={sincronizar} disabled={sincronizando || !navigator.onLine}>
            {sincronizando ? 'Sincronizando…' : 'Sincronizar ahora'}
          </button>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-linea bg-blanco">
        <table className="tabla">
          <thead>
            <tr><th>Participante</th>{sesiones.map((s) => <th key={s} className="text-center">S{s}</th>)}<th>Total</th></tr>
          </thead>
          <tbody>
            {inscritos.map((i) => (
              <tr key={i.id_inscripcion}>
                <td><b>{i.apellidos}, {i.nombres}</b><span className="block text-sm text-gris">DNI {i.dni}</span></td>
                {sesiones.map((s) => {
                  const m = porCelda.get(`${i.id_inscripcion}-${s}`);
                  return (
                    <td key={s} className="text-center" title={m ? `${m.estado} · ${m.metodo.replace('_', ' ')} · ${fechaHora(m.fecha_hora)}` : 'Sin registro'}>
                      {m ? <span className={m.estado === 'Tardanza' ? 'font-bold text-alerta' : 'font-bold text-exito'}>{m.estado === 'Tardanza' ? 'T' : '✓'}</span> : <span className="text-linea">—</span>}
                    </td>
                  );
                })}
                <td className="whitespace-nowrap">{i.asistidas}/{c.numero_sesiones}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {inscritos.length === 0 && <p className="p-4 text-gris">Aún no hay inscritos.</p>}
      </div>
      <p className="text-sm text-gris">✓ presente · T tardanza (ambas cuentan para la asistencia mínima). Pasa el cursor sobre una marca para ver la hora y el método.</p>
    </div>
  );
}

// ---------- Notas y acta ----------

function PestanaNotas({ c, inscritos, recargar }: { c: Capacitacion; inscritos: Inscrito[]; recargar: () => void }) {
  const [notas, setNotas] = useState<Record<number, string>>({});
  const [msg, setMsg] = useState<Mensaje>(null);

  useEffect(() => {
    setNotas(Object.fromEntries(inscritos.map((i) => [i.id_inscripcion, i.nota_final === null ? '' : String(i.nota_final)])));
  }, [inscritos]);

  const prevista = (i: Inscrito) => {
    const n = notas[i.id_inscripcion];
    if (n === '' || n === undefined) return '—';
    const pct = (Math.min(i.asistidas, c.numero_sesiones) / c.numero_sesiones) * 100;
    return Number(n) >= 11 && pct >= c.asistencia_minima ? 'Aprobado' : 'Desaprobado';
  };

  async function guardar() {
    setMsg(null);
    try {
      const lista = inscritos.map((i) => ({ id_inscripcion: i.id_inscripcion, nota: notas[i.id_inscripcion] === '' ? null : Number(notas[i.id_inscripcion]) }));
      await api.put(`/capacitaciones/${c.id_capacitacion}/notas`, { notas: lista });
      setMsg({ tono: 'exito', texto: 'Notas guardadas.' });
      recargar();
    } catch (e) {
      setMsg({ tono: 'error', texto: e instanceof ErrorApi ? `${e.message} ${Object.values(e.detalles ?? {}).join(' ')}` : 'No se pudieron guardar.' });
    }
  }

  async function cerrar() {
    if (!confirm('Al cerrar el acta se calcula la condición final y ya no podrás cambiar notas ni asistencia. ¿Cerrar el acta?')) return;
    try {
      await guardar();
      const r = await api.post<{ aprobados: number; desaprobados: number }>(`/capacitaciones/${c.id_capacitacion}/acta/cerrar`);
      setMsg({ tono: 'exito', texto: `Acta cerrada: ${r.aprobados} aprobados y ${r.desaprobados} desaprobados.` });
      recargar();
    } catch (e) {
      if (e instanceof ErrorApi) setMsg({ tono: 'error', texto: e.detalles?.pendientes ? `${e.message} Pendientes: ${e.detalles.pendientes.join(', ')}.` : e.message });
    }
  }

  return (
    <div className="space-y-4">
      <p className="max-w-prose text-gris">Aprueba quien tiene nota de 11 o más (escala de 0 a 20) y asistió al menos al {c.asistencia_minima} % de las {c.numero_sesiones} sesiones.</p>
      {msg && <Aviso tono={msg.tono}>{msg.texto}</Aviso>}
      <div className="overflow-x-auto rounded-xl border border-linea bg-blanco">
        <table className="tabla">
          <thead><tr><th>Participante</th><th>Asistencia</th><th>Nota (0–20)</th><th>{c.acta_cerrada ? 'Condición' : 'Condición prevista'}</th></tr></thead>
          <tbody>
            {inscritos.map((i) => (
              <tr key={i.id_inscripcion}>
                <td><b>{i.apellidos}, {i.nombres}</b><span className="block text-sm text-gris">DNI {i.dni}</span></td>
                <td>{Math.round((Math.min(i.asistidas, c.numero_sesiones) / c.numero_sesiones) * 100)} %</td>
                <td>
                  {c.acta_cerrada ? <b>{i.nota_final?.toFixed(2)}</b> : (
                    <input aria-label={`Nota de ${i.nombres} ${i.apellidos}`} className="campo !w-24" type="number" min={0} max={20} step={0.5}
                      value={notas[i.id_inscripcion] ?? ''} onChange={(e) => setNotas({ ...notas, [i.id_inscripcion]: e.target.value })} />
                  )}
                </td>
                <td>{c.acta_cerrada ? <Condicion estado={i.estado} /> : <Condicion estado={prevista(i) === '—' ? 'Confirmada' : prevista(i)} />}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!c.acta_cerrada && inscritos.length > 0 && (
        <div className="flex flex-wrap gap-3">
          <button type="button" className="boton-sec" onClick={guardar}>Guardar notas</button>
          <button type="button" className="boton" onClick={cerrar}>Cerrar acta</button>
        </div>
      )}
    </div>
  );
}

// ---------- Certificados ----------

function PestanaCertificados({ c, inscritos, recargar }: { c: Capacitacion; inscritos: Inscrito[]; recargar: () => void }) {
  const [msg, setMsg] = useState<Mensaje>(null);
  const [emitiendo, setEmitiendo] = useState(false);
  const aprobados = inscritos.filter((i) => i.estado === 'Aprobado');

  async function emitir() {
    setEmitiendo(true);
    try {
      const r = await api.post<{ emitidos: number; ya_existian: number; milisegundos: number }>(`/capacitaciones/${c.id_capacitacion}/certificados`);
      setMsg({ tono: 'exito', texto: `Emitidos ${r.emitidos} certificados en ${(r.milisegundos / 1000).toFixed(1)} s${r.ya_existian ? ` (${r.ya_existian} ya existían)` : ''}.` });
      recargar();
    } catch (e) {
      setMsg({ tono: 'error', texto: e instanceof ErrorApi ? e.message : 'No se pudo emitir.' });
    } finally {
      setEmitiendo(false);
    }
  }

  if (!c.acta_cerrada) return <Aviso tono="alerta">Cierra el acta en la pestaña «Notas y acta» para emitir los certificados.</Aviso>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-4">
        <button type="button" className="boton" onClick={emitir} disabled={emitiendo || aprobados.length === 0}>
          {emitiendo ? 'Emitiendo…' : `Emitir certificados de ${aprobados.length} aprobados`}
        </button>
        <p className="text-gris">Cada PDF lleva un QR a la verificación pública y su huella SHA-256.</p>
      </div>
      {msg && <Aviso tono={msg.tono}>{msg.texto}</Aviso>}
      <div className="overflow-x-auto rounded-xl border border-linea bg-blanco">
        <table className="tabla">
          <thead><tr><th>Participante</th><th>Nota</th><th>Certificado</th><th></th></tr></thead>
          <tbody>
            {aprobados.map((i) => (
              <tr key={i.id_inscripcion}>
                <td><b>{i.apellidos}, {i.nombres}</b></td>
                <td>{i.nota_final?.toFixed(2)}</td>
                <td>{i.certificado ? <Link to={`/verificar/${i.certificado}`} className="font-bold text-carmin underline">{i.certificado}</Link> : <span className="text-gris">Sin emitir</span>}</td>
                <td>
                  {i.certificado && (
                    <button type="button" className="boton-sec !py-1 text-sm"
                      onClick={() => api.descargar(`/capacitaciones/${c.id_capacitacion}/certificados/${i.id_inscripcion}/pdf`, `${i.certificado}.pdf`)}>
                      Descargar PDF
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {aprobados.length === 0 && <p className="p-4 text-gris">Nadie aprobó esta capacitación.</p>}
      </div>
    </div>
  );
}

// ---------- Página ----------

export function GestionCurso() {
  const { id } = useParams();
  const { tiene } = useSesion();
  const [c, setC] = useState<Capacitacion | null>(null);
  const [inscritos, setInscritos] = useState<Inscrito[]>([]);
  const [pestana, setPestana] = useState<Pestana>('asistencia');
  const [error, setError] = useState('');

  const recargar = useCallback(() => {
    api.get<Capacitacion>(`/capacitaciones/${id}`).then(setC).catch((e) => setError(e.message));
    api.get<Inscrito[]>(`/capacitaciones/${id}/inscritos`).then(setInscritos).catch((e) => setError(e.message));
  }, [id]);
  useEffect(recargar, [recargar]);

  async function cambiarEstado(estado: string) {
    await api.patch(`/capacitaciones/${id}/estado`, { estado });
    recargar();
  }

  if (error) return <Aviso tono="error">{error}</Aviso>;
  if (!c) return <Cargando />;

  const pestanas: [Pestana, string][] = [['asistencia', 'Asistencia'], ['notas', 'Notas y acta'], ['certificados', 'Certificados'], ['reportes', 'Reportes']];

  return (
    <>
      <p className="mb-2"><Link to="/gestion" className="text-carmin underline">Mis cursos</Link></p>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">{c.titulo}</h1>
          <p className="mt-1 text-gris">{c.institucion} · {fechaLarga(c.fecha_inicio)} · {c.inscritos} inscritos de {c.vacantes_max} · {c.numero_sesiones} sesiones</p>
          <div className="mt-3"><EstadoCurso estado={c.estado} /></div>
        </div>
        {tiene('Admin', 'Coordinador') && !c.acta_cerrada && (
          <div className="flex flex-wrap items-center gap-2">
            <select aria-label="Cambiar estado" className="campo !w-auto" value={c.estado} onChange={(e) => cambiarEstado(e.target.value)}>
              <option value="Planificada">Planificada</option>
              <option value="Abierta">Inscripción abierta</option>
              <option value="En_Curso">En curso</option>
            </select>
            <Link to={`/gestion/${c.id_capacitacion}/editar`} className="boton-sec">Editar</Link>
          </div>
        )}
      </div>

      <div role="tablist" aria-label="Secciones del curso" className="mt-8 mb-6 flex flex-wrap gap-1 border-b border-linea">
        {pestanas.map(([k, t]) => (
          <button key={k} role="tab" type="button" aria-selected={pestana === k} onClick={() => setPestana(k)}
            className={`-mb-px border-b-2 px-4 py-2 font-bold ${pestana === k ? 'border-carmin text-carmin' : 'border-transparent text-gris hover:text-tinta'}`}>
            {t}
          </button>
        ))}
      </div>

      <div role="tabpanel">
        {pestana === 'asistencia' && <PestanaAsistencia c={c} inscritos={inscritos} recargar={recargar} />}
        {pestana === 'notas' && <PestanaNotas c={c} inscritos={inscritos} recargar={recargar} />}
        {pestana === 'certificados' && <PestanaCertificados c={c} inscritos={inscritos} recargar={recargar} />}
        {pestana === 'reportes' && (
          <div className="space-y-4">
            <p className="max-w-prose text-gris">Padrón con asistencia por sesión, nota y condición, listo para sustentar las horas ante órganos de control.</p>
            <div className="flex flex-wrap gap-3">
              <button type="button" className="boton" onClick={() => api.descargar(`/reportes/capacitaciones/${c.id_capacitacion}/excel`, `reporte-${c.id_capacitacion}.xlsx`)}>Descargar Excel</button>
              <button type="button" className="boton-sec" onClick={() => api.descargar(`/reportes/capacitaciones/${c.id_capacitacion}/pdf`, `padron-${c.id_capacitacion}.pdf`)}>Descargar padrón PDF</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
