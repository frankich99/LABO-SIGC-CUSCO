import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, fechaCorta, type Capacitacion, type Institucion } from '../api';
import { Aviso, Cargando, EstadoCurso, Vacantes } from '../componentes/ui';

export function Catalogo() {
  const [cursos, setCursos] = useState<Capacitacion[] | null>(null);
  const [instituciones, setInstituciones] = useState<Institucion[]>([]);
  const [q, setQ] = useState('');
  const [inst, setInst] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { api.get<Institucion[]>('/instituciones').then(setInstituciones).catch(() => undefined); }, []);

  useEffect(() => {
    const t = setTimeout(() => {
      const p = new URLSearchParams();
      if (q.trim()) p.set('q', q.trim());
      if (inst) p.set('institucion', inst);
      api.get<Capacitacion[]>(`/capacitaciones?${p}`).then((r) => { setCursos(r); setError(''); }).catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [q, inst]);

  return (
    <>
      <section className="mb-8 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
        <div>
          <h1 className="text-3xl font-bold sm:text-5xl">Capacitaciones abiertas en el Cusco</h1>
          <p className="mt-3 max-w-prose text-lg text-gris">
            Inscríbete con tu DNI, marca tu asistencia desde el teléfono y descarga un certificado que cualquiera puede verificar.
          </p>
        </div>
        <form className="grid gap-3 sm:grid-cols-2 lg:w-[34rem]" role="search" onSubmit={(e) => e.preventDefault()}>
          <div>
            <label htmlFor="buscar" className="mb-1 block font-bold">Buscar</label>
            <input id="buscar" className="campo" type="search" placeholder="Turismo, contrataciones…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div>
            <label htmlFor="inst" className="mb-1 block font-bold">Institución</label>
            <select id="inst" className="campo" value={inst} onChange={(e) => setInst(e.target.value)}>
              <option value="">Todas</option>
              {instituciones.map((i) => <option key={i.id_institucion} value={i.id_institucion}>{i.razon_social}</option>)}
            </select>
          </div>
        </form>
      </section>

      {error && <Aviso tono="error">{error}</Aviso>}
      {!cursos && !error && <Cargando texto="Buscando capacitaciones…" />}
      {cursos && cursos.length === 0 && (
        <Aviso>No hay capacitaciones con esos filtros. Prueba con otra palabra o elige «Todas» las instituciones.</Aviso>
      )}

      {cursos && cursos.length > 0 && (
        <ol className="divide-y divide-linea rounded-xl border border-linea bg-blanco">
          {cursos.map((c) => (
            <li key={c.id_capacitacion} className="grid gap-4 p-5 sm:grid-cols-[5.5rem_1fr_auto] sm:items-center">
              <div className="flex items-baseline gap-2 sm:block">
                <span className="text-sm text-gris sm:block">Inicia</span>
                <span className="text-2xl font-bold text-carmin">{fechaCorta(c.fecha_inicio)}</span>
              </div>
              <div>
                <h2 className="text-xl font-bold">
                  <Link to={`/capacitaciones/${c.id_capacitacion}`} className="hover:text-carmin hover:underline">{c.titulo}</Link>
                </h2>
                <p className="text-gris">{c.institucion}</p>
                <p className="mt-1 text-[0.97rem]">
                  {c.horas_academicas} horas · {c.numero_sesiones} sesiones · {c.modalidad}{c.lugar ? `, ${c.lugar}` : ''}
                </p>
              </div>
              <div className="flex items-center gap-4 sm:flex-col sm:items-end">
                {c.estado === 'Abierta' ? <Vacantes inscritos={c.inscritos} total={c.vacantes_max} /> : <EstadoCurso estado={c.estado} />}
                <Link to={`/capacitaciones/${c.id_capacitacion}`} className="boton-sec whitespace-nowrap">
                  {c.estado === 'Abierta' && c.disponibles > 0 ? 'Ver e inscribirme' : 'Ver detalle'}
                </Link>
              </div>
            </li>
          ))}
        </ol>
      )}
    </>
  );
}
