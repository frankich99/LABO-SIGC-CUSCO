import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { api, ErrorApi, type Institucion } from '../api';
import { Aviso, Campo, Cargando, Selector, Titulo } from '../componentes/ui';

const vacio = { ruc: '', razon_social: '', tipo: 'Publica' };

export function Instituciones() {
  const [lista, setLista] = useState<Institucion[] | null>(null);
  const [f, setF] = useState(vacio);
  const [errores, setErrores] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ tono: 'exito' | 'error'; texto: string } | null>(null);

  const cargar = useCallback(() => { api.get<Institucion[]>('/instituciones/todas').then(setLista); }, []);
  useEffect(cargar, [cargar]);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setErrores({});
    try {
      await api.post('/instituciones', f);
      setMsg({ tono: 'exito', texto: `${f.razon_social} registrada.` });
      setF(vacio);
      cargar();
    } catch (err) {
      if (err instanceof ErrorApi) { setErrores(err.detalles ?? {}); setMsg({ tono: 'error', texto: err.message }); }
    }
  }

  async function alternar(i: Institucion) {
    await api.patch(`/instituciones/${i.id_institucion}`, { activo: !i.activo });
    cargar();
  }

  return (
    <>
      <Titulo sub="Municipalidades y empresas que organizan capacitaciones. Cada una gestiona sus cursos por separado.">Instituciones</Titulo>
      {msg && <div className="mb-4"><Aviso tono={msg.tono}>{msg.texto}</Aviso></div>}
      <div className="grid gap-8 lg:grid-cols-[1fr_22rem]">
        {!lista ? <Cargando /> : (
          <div className="h-fit overflow-x-auto rounded-xl border border-linea bg-blanco">
            <table className="tabla">
              <thead><tr><th>Institución</th><th>Tipo</th><th>Cursos</th><th>Estado</th></tr></thead>
              <tbody>
                {lista.map((i) => (
                  <tr key={i.id_institucion}>
                    <td><b>{i.razon_social}</b><span className="block text-sm text-gris">RUC {i.ruc}</span></td>
                    <td>{i.tipo === 'Publica' ? 'Pública' : 'Privada'}</td>
                    <td>{i.capacitaciones}</td>
                    <td><button type="button" className="text-carmin underline" onClick={() => alternar(i)}>{i.activo ? 'Activa · desactivar' : 'Inactiva · activar'}</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <form onSubmit={crear} noValidate className="h-fit space-y-4 rounded-xl border border-linea bg-blanco p-5">
          <h2 className="text-xl font-bold">Registrar institución</h2>
          <Campo etiqueta="RUC" inputMode="numeric" maxLength={11} value={f.ruc} onChange={(e) => setF({ ...f, ruc: e.target.value })} error={errores.ruc} />
          <Campo etiqueta="Razón social" value={f.razon_social} onChange={(e) => setF({ ...f, razon_social: e.target.value })} error={errores.razon_social} />
          <Selector etiqueta="Tipo" value={f.tipo} onChange={(e) => setF({ ...f, tipo: e.target.value })} error={errores.tipo}>
            <option value="Publica">Pública</option><option value="Privada">Privada</option>
          </Selector>
          <button className="boton w-full">Registrar institución</button>
        </form>
      </div>
      <p className="mt-6 text-sm text-gris"><Link to="/admin/correos" className="underline">Ver los correos enviados por el sistema</Link></p>
    </>
  );
}
