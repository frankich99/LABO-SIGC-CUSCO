import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api, ErrorApi } from '../api';
import { Aviso, Cargando } from '../componentes/ui';

/** El participante llega aquí al escanear con su teléfono el QR que proyecta el docente. */
export function Asistencia() {
  const [params] = useSearchParams();
  const t = params.get('t');
  const [estado, setEstado] = useState<{ tono: 'exito' | 'alerta' | 'error'; texto: string } | null>(null);
  const enviado = useRef(false);

  useEffect(() => {
    if (!t || enviado.current) return;
    enviado.current = true;
    api.post<{ mensaje: string }>('/asistencias/qr', { token: t })
      .then((r) => setEstado({ tono: 'exito', texto: r.mensaje }))
      .catch((e) => setEstado({ tono: e instanceof ErrorApi && e.status === 409 ? 'alerta' : 'error', texto: e.message }));
  }, [t]);

  return (
    <div className="mx-auto max-w-md space-y-6">
      <h1 className="text-3xl font-bold">Registrar asistencia</h1>
      {!t && <Aviso tono="alerta">Abre esta página escaneando el QR que proyecta tu docente en la sesión.</Aviso>}
      {t && !estado && <Cargando texto="Registrando tu asistencia…" />}
      {estado && <Aviso tono={estado.tono}><span className="text-lg font-bold">{estado.texto}</span></Aviso>}
      <Link to="/mis-inscripciones" className="boton-sec">Ver mis inscripciones</Link>
    </div>
  );
}
