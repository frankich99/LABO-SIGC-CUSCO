import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ErrorApi, fechaLarga } from '../api';
import { Aviso, Cargando, Condicion, Titulo } from '../componentes/ui';

interface Mia {
  id_inscripcion: number;
  estado: string;
  nota_final: number | null;
  id_capacitacion: number;
  titulo: string;
  fecha_inicio: string;
  fecha_fin: string | null;
  modalidad: string;
  lugar: string;
  horas_academicas: number;
  numero_sesiones: number;
  asistencia_minima: number;
  acta_cerrada: boolean;
  estado_capacitacion: string;
  institucion: string;
  asistidas: number;
  certificado: string | null;
  credencial: string;
}

function Credencial({ id }: { id: number }) {
  const [c, setC] = useState<{ codigo: string; qr: string } | null>(null);
  useEffect(() => { api.get<{ codigo: string; qr: string }>(`/inscripciones/${id}/credencial`).then(setC); }, [id]);
  return (
    <div className="mt-4 rounded-lg border border-linea bg-papel p-4 text-center">
      {c ? (
        <>
          <img src={c.qr} alt={`QR de tu credencial ${c.codigo}`} className="mx-auto w-56 rounded bg-white p-2" />
          <p className="mt-2 break-all text-lg font-bold">{c.codigo}</p>
          <p className="text-sm text-gris">Muéstralo al docente si no puedes escanear el QR de la sesión.</p>
        </>
      ) : <Cargando />}
    </div>
  );
}

export function MisInscripciones() {
  const [lista, setLista] = useState<Mia[] | null>(null);
  const [abierta, setAbierta] = useState<number | null>(null);
  const [aviso, setAviso] = useState<{ tono: 'exito' | 'error'; texto: string } | null>(null);

  const cargar = useCallback(() => { api.get<Mia[]>('/mis-inscripciones').then(setLista); }, []);
  useEffect(cargar, [cargar]);

  async function cancelar(m: Mia) {
    if (!confirm(`¿Cancelar tu inscripción a "${m.titulo}"? Liberarás tu vacante.`)) return;
    try {
      await api.borrar(`/inscripciones/${m.id_inscripcion}`);
      setAviso({ tono: 'exito', texto: `Cancelaste tu inscripción a ${m.titulo}.` });
      cargar();
    } catch (e) {
      setAviso({ tono: 'error', texto: e instanceof ErrorApi ? e.message : 'No se pudo cancelar.' });
    }
  }

  async function descargar(m: Mia) {
    try {
      await api.descargar(`/inscripciones/${m.id_inscripcion}/certificado`, `certificado-${m.titulo.slice(0, 30)}.pdf`);
      cargar();
    } catch (e) {
      setAviso({ tono: 'error', texto: e instanceof ErrorApi ? e.message : 'No se pudo descargar.' });
    }
  }

  if (!lista) return <Cargando />;

  return (
    <>
      <Titulo sub="Tu asistencia, tus notas y tus certificados en un solo lugar.">Mis inscripciones</Titulo>
      {aviso && <div className="mb-4"><Aviso tono={aviso.tono}>{aviso.texto}</Aviso></div>}
      {lista.length === 0 && (
        <Aviso>Aún no te inscribes a ninguna capacitación. <Link to="/" className="font-bold text-carmin underline">Ver capacitaciones abiertas</Link></Aviso>
      )}
      <ul className="space-y-4">
        {lista.map((m) => {
          const pct = Math.round((Math.min(m.asistidas, m.numero_sesiones) / m.numero_sesiones) * 100);
          const activa = m.estado !== 'Anulada';
          return (
            <li key={m.id_inscripcion} className={`rounded-xl border border-linea bg-blanco p-5 ${activa ? '' : 'opacity-70'}`}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl font-bold">{m.titulo}</h2>
                  <p className="text-gris">{m.institucion} · {fechaLarga(m.fecha_inicio)}{m.lugar ? ` · ${m.lugar}` : ''}</p>
                </div>
                <Condicion estado={m.estado} />
              </div>

              {activa && (
                <div className="mt-4 grid gap-4 sm:grid-cols-3">
                  <div>
                    <p className="text-sm text-gris">Asistencia</p>
                    <p className="font-bold">{m.asistidas} de {m.numero_sesiones} sesiones ({pct} %)</p>
                    <div className="mt-1 h-1.5 rounded-full bg-linea" aria-hidden="true">
                      <div className={`h-1.5 rounded-full ${pct >= m.asistencia_minima ? 'bg-exito' : 'bg-alerta'}`} style={{ width: `${pct}%` }} />
                    </div>
                    <p className="mt-1 text-sm text-gris">Mínimo para certificar: {m.asistencia_minima} %</p>
                  </div>
                  <div>
                    <p className="text-sm text-gris">Nota final</p>
                    <p className="font-bold">{m.nota_final === null ? 'Aún sin nota' : m.nota_final.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gris">Certificado</p>
                    <p className="font-bold">
                      {m.certificado ? m.certificado : m.estado === 'Aprobado' ? 'Listo para descargar' : m.acta_cerrada ? 'No corresponde' : 'Al cerrar el acta'}
                    </p>
                  </div>
                </div>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                {m.estado === 'Aprobado' && <button type="button" className="boton" onClick={() => descargar(m)}>Descargar certificado PDF</button>}
                {m.certificado && <Link className="boton-sec" to={`/verificar/${m.certificado}`}>Ver verificación pública</Link>}
                {m.estado === 'Confirmada' && !m.acta_cerrada && (
                  <>
                    <button type="button" className="boton-sec" onClick={() => setAbierta(abierta === m.id_inscripcion ? null : m.id_inscripcion)}>
                      {abierta === m.id_inscripcion ? 'Ocultar credencial' : 'Mostrar mi credencial QR'}
                    </button>
                    <button type="button" className="boton-sec text-error" onClick={() => cancelar(m)}>Cancelar inscripción</button>
                  </>
                )}
              </div>
              {abierta === m.id_inscripcion && <Credencial id={m.id_inscripcion} />}
            </li>
          );
        })}
      </ul>
    </>
  );
}
