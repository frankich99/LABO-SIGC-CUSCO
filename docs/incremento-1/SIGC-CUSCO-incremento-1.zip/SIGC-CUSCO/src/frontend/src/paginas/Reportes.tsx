import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, etiquetaEstado, type Capacitacion } from '../api';
import { Aviso, Cargando, Titulo } from '../componentes/ui';
import { useSesion } from '../sesion';

interface Fila {
  id_capacitacion: number;
  titulo: string;
  institucion: string;
  estado: Capacitacion['estado'];
  vacantes_max: number;
  inscritos: number;
  aprobados: number;
  desaprobados: number;
  certificados: number;
  ocupacion: number;
  asistencia_promedio: number;
}

interface Resumen {
  totales: { capacitaciones: number; inscritos: number; aprobados: number; desaprobados: number; certificados: number };
  capacitaciones: Fila[];
}

function Barra({ valor, tono = 'bg-carmin' }: { valor: number; tono?: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-20 shrink-0 rounded-full bg-linea" aria-hidden="true"><div className={`h-2 rounded-full ${tono}`} style={{ width: `${Math.min(100, valor)}%` }} /></div>
      <span className="whitespace-nowrap tabular-nums">{valor} %</span>
    </div>
  );
}

export function Reportes() {
  const { usuario } = useSesion();
  const [r, setR] = useState<Resumen | null>(null);
  const [error, setError] = useState('');
  useEffect(() => { api.get<Resumen>('/reportes/resumen').then(setR).catch((e) => setError(e.message)); }, []);

  if (error) return <Aviso tono="error">{error}</Aviso>;
  if (!r) return <Cargando />;
  const t = r.totales;
  const evaluados = t.aprobados + t.desaprobados;

  return (
    <>
      <Titulo sub={usuario?.rol === 'Coordinador' ? 'Indicadores de las capacitaciones de tu institución.' : 'Indicadores de todas las instituciones.'}>Reportes</Titulo>
      <dl className="mb-8 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-linea bg-linea sm:grid-cols-4">
        {[
          ['Capacitaciones', t.capacitaciones],
          ['Personas inscritas', t.inscritos],
          ['Aprobación', evaluados ? `${Math.round((t.aprobados / evaluados) * 100)} % de ${evaluados} evaluados` : 'Sin actas cerradas'],
          ['Certificados emitidos', t.certificados],
        ].map(([k, v]) => (
          <div key={k} className="bg-blanco p-4"><dt className="text-sm text-gris">{k}</dt><dd className="text-xl font-bold">{v}</dd></div>
        ))}
      </dl>
      <div className="overflow-x-auto rounded-xl border border-linea bg-blanco">
        <table className="tabla">
          <thead>
            <tr><th>Capacitación</th><th>Estado</th><th>Ocupación</th><th>Asistencia promedio</th><th>Aprobados</th><th>Certificados</th><th>Exportar</th></tr>
          </thead>
          <tbody>
            {r.capacitaciones.map((f) => (
              <tr key={f.id_capacitacion}>
                <td><Link to={`/gestion/${f.id_capacitacion}`} className="font-bold hover:text-carmin hover:underline">{f.titulo}</Link><span className="block text-sm text-gris">{f.institucion}</span></td>
                <td className="whitespace-nowrap">{etiquetaEstado[f.estado]}</td>
                <td><Barra valor={f.ocupacion} /><span className="text-sm text-gris">{f.inscritos} de {f.vacantes_max}</span></td>
                <td><Barra valor={f.asistencia_promedio} tono="bg-exito" /></td>
                <td>{f.aprobados + f.desaprobados > 0 ? `${f.aprobados} de ${f.aprobados + f.desaprobados}` : '—'}</td>
                <td>{f.certificados}</td>
                <td className="whitespace-nowrap">
                  <button type="button" className="text-carmin underline" onClick={() => api.descargar(`/reportes/capacitaciones/${f.id_capacitacion}/excel`, `reporte-${f.id_capacitacion}.xlsx`)}>Excel</button>
                  {' · '}
                  <button type="button" className="text-carmin underline" onClick={() => api.descargar(`/reportes/capacitaciones/${f.id_capacitacion}/pdf`, `padron-${f.id_capacitacion}.pdf`)}>PDF</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
