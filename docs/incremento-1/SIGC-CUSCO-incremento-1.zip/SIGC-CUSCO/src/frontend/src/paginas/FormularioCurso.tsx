import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, ErrorApi, type Capacitacion, type Institucion } from '../api';
import { Aviso, Campo, Cargando, Selector, Titulo } from '../componentes/ui';
import { useSesion } from '../sesion';

interface Docente { id_usuario: number; nombres: string; apellidos: string }

const vacio = {
  id_institucion: '', id_docente: '', titulo: '', descripcion: '', modalidad: 'Presencial', lugar: '',
  horas_academicas: '', vacantes_max: '', numero_sesiones: '', asistencia_minima: '75', fecha_inicio: '', fecha_fin: '',
};

export function FormularioCurso() {
  const { id } = useParams();
  const { usuario } = useSesion();
  const ir = useNavigate();
  const [f, setF] = useState(vacio);
  const [instituciones, setInstituciones] = useState<Institucion[]>([]);
  const [docentes, setDocentes] = useState<Docente[]>([]);
  const [errores, setErrores] = useState<Record<string, string>>({});
  const [mensaje, setMensaje] = useState('');
  const [listo, setListo] = useState(!id);

  useEffect(() => {
    api.get<Institucion[]>('/instituciones').then((l) => {
      const propias = usuario?.rol === 'Coordinador' ? l.filter((i) => i.id_institucion === usuario.institucion) : l;
      setInstituciones(propias);
      if (!id && propias.length === 1) setF((x) => ({ ...x, id_institucion: String(propias[0].id_institucion) }));
    });
    api.get<Docente[]>('/usuarios/docentes').then(setDocentes);
    if (id) {
      api.get<Capacitacion>(`/capacitaciones/${id}`).then((c) => {
        setF({
          id_institucion: String(c.id_institucion), id_docente: c.id_docente ? String(c.id_docente) : '', titulo: c.titulo,
          descripcion: c.descripcion, modalidad: c.modalidad, lugar: c.lugar, horas_academicas: String(c.horas_academicas),
          vacantes_max: String(c.vacantes_max), numero_sesiones: String(c.numero_sesiones), asistencia_minima: String(c.asistencia_minima),
          fecha_inicio: c.fecha_inicio, fecha_fin: c.fecha_fin ?? '',
        });
        setListo(true);
      });
    }
  }, [id, usuario]);

  const cambiar = (k: keyof typeof vacio) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const num = (v: string) => (v === '' ? undefined : Number(v));

  async function guardar(e: FormEvent) {
    e.preventDefault();
    setErrores({});
    setMensaje('');
    const cuerpo = {
      id_institucion: num(f.id_institucion), id_docente: f.id_docente ? Number(f.id_docente) : null, titulo: f.titulo,
      descripcion: f.descripcion, modalidad: f.modalidad, lugar: f.lugar, horas_academicas: num(f.horas_academicas),
      vacantes_max: num(f.vacantes_max), numero_sesiones: num(f.numero_sesiones), asistencia_minima: num(f.asistencia_minima),
      fecha_inicio: f.fecha_inicio, fecha_fin: f.fecha_fin || null,
    };
    try {
      const r = id
        ? await api.put<{ id_capacitacion: number }>(`/capacitaciones/${id}`, cuerpo)
        : await api.post<{ id_capacitacion: number }>('/capacitaciones', cuerpo);
      ir(`/gestion/${r.id_capacitacion}`);
    } catch (err) {
      if (err instanceof ErrorApi) { setMensaje(err.message); setErrores(err.detalles ?? {}); }
    }
  }

  if (!listo) return <Cargando />;

  return (
    <div className="max-w-3xl">
      <Titulo sub={id ? undefined : 'Al guardarla queda con inscripción abierta y aparece en el catálogo público.'}>
        {id ? 'Editar capacitación' : 'Crear capacitación'}
      </Titulo>
      <form onSubmit={guardar} noValidate className="space-y-5 rounded-xl border border-linea bg-blanco p-5">
        {mensaje && <Aviso tono="error">{mensaje}</Aviso>}
        <Campo etiqueta="Título" value={f.titulo} onChange={cambiar('titulo')} error={errores.titulo} />
        <div className="space-y-1">
          <label htmlFor="desc" className="block font-bold">Descripción y temario</label>
          <textarea id="desc" rows={4} className="campo" value={f.descripcion} onChange={cambiar('descripcion')} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Selector etiqueta="Institución" value={f.id_institucion} onChange={cambiar('id_institucion')} error={errores.id_institucion}>
            <option value="">Elige la institución</option>
            {instituciones.map((i) => <option key={i.id_institucion} value={i.id_institucion}>{i.razon_social}</option>)}
          </Selector>
          <Selector etiqueta="Docente" value={f.id_docente} onChange={cambiar('id_docente')} error={errores.id_docente}>
            <option value="">Sin asignar</option>
            {docentes.map((d) => <option key={d.id_usuario} value={d.id_usuario}>{d.apellidos}, {d.nombres}</option>)}
          </Selector>
          <Selector etiqueta="Modalidad" value={f.modalidad} onChange={cambiar('modalidad')}>
            <option>Presencial</option><option>Virtual</option><option>Mixta</option>
          </Selector>
          <Campo etiqueta="Lugar o enlace" value={f.lugar} onChange={cambiar('lugar')} error={errores.lugar} />
          <Campo etiqueta="Fecha de inicio" type="date" value={f.fecha_inicio} onChange={cambiar('fecha_inicio')} error={errores.fecha_inicio} />
          <Campo etiqueta="Fecha de fin" type="date" value={f.fecha_fin} onChange={cambiar('fecha_fin')} error={errores.fecha_fin} />
        </div>
        <div className="grid gap-4 sm:grid-cols-4">
          <Campo etiqueta="Horas académicas" type="number" min={1} value={f.horas_academicas} onChange={cambiar('horas_academicas')} error={errores.horas_academicas} />
          <Campo etiqueta="Vacantes" type="number" min={1} value={f.vacantes_max} onChange={cambiar('vacantes_max')} error={errores.vacantes_max} />
          <Campo etiqueta="Sesiones" type="number" min={1} value={f.numero_sesiones} onChange={cambiar('numero_sesiones')} error={errores.numero_sesiones} />
          <Campo etiqueta="Asistencia mínima (%)" type="number" min={0} max={100} value={f.asistencia_minima} onChange={cambiar('asistencia_minima')} error={errores.asistencia_minima} />
        </div>
        <div className="flex gap-3">
          <button className="boton">{id ? 'Guardar cambios' : 'Crear capacitación'}</button>
          <button type="button" className="boton-sec" onClick={() => ir(-1)}>Volver</button>
        </div>
      </form>
    </div>
  );
}
