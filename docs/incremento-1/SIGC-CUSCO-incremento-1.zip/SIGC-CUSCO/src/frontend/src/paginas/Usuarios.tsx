import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { api, ErrorApi, type Institucion, type Rol } from '../api';
import { Aviso, Campo, Cargando, Selector, Titulo } from '../componentes/ui';

interface Usuario {
  id_usuario: number;
  dni: string;
  nombres: string;
  apellidos: string;
  correo: string;
  rol: Rol;
  id_institucion: number | null;
  institucion: string | null;
  activo: boolean;
}

const ROLES: Rol[] = ['Admin', 'Coordinador', 'Docente', 'Participante'];
const vacio = { dni: '', nombres: '', apellidos: '', correo: '', password: '', rol: 'Docente', id_institucion: '' };

export function Usuarios() {
  const [lista, setLista] = useState<Usuario[] | null>(null);
  const [insts, setInsts] = useState<Institucion[]>([]);
  const [filtro, setFiltro] = useState('');
  const [msg, setMsg] = useState<{ tono: 'exito' | 'error'; texto: string } | null>(null);
  const [f, setF] = useState(vacio);
  const [errores, setErrores] = useState<Record<string, string>>({});

  const cargar = useCallback(() => {
    api.get<Usuario[]>(`/usuarios${filtro ? `?rol=${filtro}` : ''}`).then(setLista);
  }, [filtro]);
  useEffect(cargar, [cargar]);
  useEffect(() => { api.get<Institucion[]>('/instituciones').then(setInsts); }, []);

  async function cambiarRol(u: Usuario, rol: Rol, inst: number | null) {
    try {
      await api.patch(`/usuarios/${u.id_usuario}`, { rol, id_institucion: inst });
      setMsg({ tono: 'exito', texto: `${u.nombres} ${u.apellidos} ahora es ${rol}. El cambio ya rige en su sesión.` });
      cargar();
    } catch (e) {
      setMsg({ tono: 'error', texto: e instanceof ErrorApi ? e.message : 'No se pudo cambiar el rol.' });
    }
  }

  async function crear(e: FormEvent) {
    e.preventDefault();
    setErrores({});
    try {
      await api.post('/usuarios', { ...f, id_institucion: f.id_institucion ? Number(f.id_institucion) : null });
      setMsg({ tono: 'exito', texto: `Usuario ${f.nombres} ${f.apellidos} creado como ${f.rol}.` });
      setF(vacio);
      cargar();
    } catch (err) {
      if (err instanceof ErrorApi) { setErrores(err.detalles ?? {}); setMsg({ tono: 'error', texto: err.message }); }
    }
  }

  return (
    <>
      <Titulo sub="Asigna el rol de cada persona. Un coordinador solo ve las capacitaciones de su institución.">Usuarios y roles</Titulo>
      {msg && <div className="mb-4"><Aviso tono={msg.tono}>{msg.texto}</Aviso></div>}
      <div className="grid gap-8 lg:grid-cols-[1fr_22rem]">
        <section>
          <div className="mb-3 flex items-center gap-3">
            <label htmlFor="filtro" className="font-bold">Mostrar</label>
            <select id="filtro" className="campo !w-48" value={filtro} onChange={(e) => setFiltro(e.target.value)}>
              <option value="">Todos los roles</option>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </div>
          {!lista ? <Cargando /> : (
            <div className="overflow-x-auto rounded-xl border border-linea bg-blanco">
              <table className="tabla">
                <thead><tr><th>Persona</th><th>Rol</th><th>Institución</th></tr></thead>
                <tbody>
                  {lista.map((u) => (
                    <tr key={u.id_usuario}>
                      <td><b>{u.apellidos}, {u.nombres}</b><span className="block text-sm text-gris">DNI {u.dni} · {u.correo}</span></td>
                      <td>
                        <select aria-label={`Rol de ${u.nombres}`} className="campo !w-40 !py-1.5" value={u.rol}
                          onChange={(e) => cambiarRol(u, e.target.value as Rol, e.target.value === 'Coordinador' ? (u.id_institucion ?? insts[0]?.id_institucion ?? null) : null)}>
                          {ROLES.map((r) => <option key={r}>{r}</option>)}
                        </select>
                      </td>
                      <td>
                        {u.rol === 'Coordinador' ? (
                          <select aria-label={`Institución de ${u.nombres}`} className="campo !py-1.5" value={u.id_institucion ?? ''}
                            onChange={(e) => cambiarRol(u, 'Coordinador', Number(e.target.value))}>
                            {insts.map((i) => <option key={i.id_institucion} value={i.id_institucion}>{i.razon_social}</option>)}
                          </select>
                        ) : <span className="text-gris">—</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
        <form onSubmit={crear} noValidate className="h-fit space-y-4 rounded-xl border border-linea bg-blanco p-5">
          <h2 className="text-xl font-bold">Crear usuario</h2>
          <Campo etiqueta="DNI" inputMode="numeric" maxLength={8} value={f.dni} onChange={(e) => setF({ ...f, dni: e.target.value })} error={errores.dni} />
          <Campo etiqueta="Nombres" value={f.nombres} onChange={(e) => setF({ ...f, nombres: e.target.value })} error={errores.nombres} />
          <Campo etiqueta="Apellidos" value={f.apellidos} onChange={(e) => setF({ ...f, apellidos: e.target.value })} error={errores.apellidos} />
          <Campo etiqueta="Correo" type="email" value={f.correo} onChange={(e) => setF({ ...f, correo: e.target.value })} error={errores.correo} />
          <Campo etiqueta="Contraseña inicial" type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} error={errores.password} ayuda="Mínimo 8 caracteres." />
          <Selector etiqueta="Rol" value={f.rol} onChange={(e) => setF({ ...f, rol: e.target.value })}>{ROLES.map((r) => <option key={r}>{r}</option>)}</Selector>
          {f.rol === 'Coordinador' && (
            <Selector etiqueta="Institución" value={f.id_institucion} onChange={(e) => setF({ ...f, id_institucion: e.target.value })} error={errores.id_institucion}>
              <option value="">Elige la institución</option>
              {insts.map((i) => <option key={i.id_institucion} value={i.id_institucion}>{i.razon_social}</option>)}
            </Selector>
          )}
          <button className="boton w-full">Crear usuario</button>
        </form>
      </div>
    </>
  );
}
