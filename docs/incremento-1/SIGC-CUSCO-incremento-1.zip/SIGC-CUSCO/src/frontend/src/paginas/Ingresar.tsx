import { useState, type FormEvent } from 'react';
import { Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { api, ErrorApi, type Sesion } from '../api';
import { Aviso, Campo } from '../componentes/ui';
import { useSesion } from '../sesion';

const destino: Record<Sesion['rol'], string> = {
  Admin: '/gestion',
  Coordinador: '/gestion',
  Docente: '/gestion',
  Participante: '/mis-inscripciones',
};

export function Ingresar() {
  const { usuario, entrar } = useSesion();
  const [params] = useSearchParams();
  const ir = useNavigate();
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);

  if (usuario) return <Navigate to={params.get('volver') ?? destino[usuario.rol]} replace />;

  async function enviar(e: FormEvent) {
    e.preventDefault();
    setEnviando(true);
    setError('');
    try {
      const r = await api.post<{ token: string; usuario: Sesion }>('/auth/login', { usuario: u, password: p });
      entrar(r.token, r.usuario);
      ir(params.get('volver') ?? destino[r.usuario.rol], { replace: true });
    } catch (err) {
      setError(err instanceof ErrorApi ? err.message : 'No se pudo iniciar sesión.');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="mx-auto max-w-md">
      <h1 className="text-3xl font-bold">Ingresar</h1>
      <p className="mt-2 text-gris">Usa tu DNI o tu correo. Si te inscribiste a un curso, tu cuenta ya existe.</p>
      <form onSubmit={enviar} className="mt-6 space-y-4 rounded-xl border border-linea bg-blanco p-5">
        {error && <Aviso tono="error">{error}</Aviso>}
        <Campo etiqueta="DNI o correo" autoComplete="username" value={u} onChange={(e) => setU(e.target.value)} required />
        <Campo etiqueta="Contraseña" type="password" autoComplete="current-password" value={p} onChange={(e) => setP(e.target.value)} required />
        <button className="boton w-full" disabled={enviando}>{enviando ? 'Ingresando…' : 'Ingresar'}</button>
      </form>
    </div>
  );
}
