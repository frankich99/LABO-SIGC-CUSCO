import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, ErrorApi, fechaHora } from '../api';
import { Aviso, Cargando } from '../componentes/ui';

interface Resultado {
  codigo: string;
  integro: boolean;
  participante: string;
  dni_parcial: string;
  capacitacion: string;
  institucion: string;
  horas: number;
  nota: number;
  fecha_emision: string;
  hash_sha256: string;
}

async function huellaArchivo(f: File): Promise<string> {
  const h = await crypto.subtle.digest('SHA-256', await f.arrayBuffer());
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function Verificar() {
  const { codigo } = useParams();
  const ir = useNavigate();
  const [entrada, setEntrada] = useState(codigo ?? '');
  const [r, setR] = useState<Resultado | null>(null);
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);
  const [archivo, setArchivo] = useState<{ nombre: string; coincide: boolean } | null>(null);

  useEffect(() => {
    if (!codigo) return;
    setCargando(true);
    setError('');
    setR(null);
    setArchivo(null);
    api.get<Resultado>(`/verificar/${encodeURIComponent(codigo)}`)
      .then(setR)
      .catch((e) => setError(e instanceof ErrorApi && e.status === 404 ? `No existe ningún certificado con el código ${codigo.toUpperCase()}.` : e.message))
      .finally(() => setCargando(false));
  }, [codigo]);

  function buscar(e: FormEvent) {
    e.preventDefault();
    if (entrada.trim()) ir(`/verificar/${entrada.trim().toUpperCase()}`);
  }

  async function revisarArchivo(f: File | undefined) {
    if (!f || !r) return;
    const sha256 = await huellaArchivo(f);
    const v = await api.post<{ coincide: boolean }>(`/verificar/${r.codigo}/archivo`, { sha256 });
    setArchivo({ nombre: f.name, coincide: v.coincide });
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-3xl font-bold sm:text-4xl">Verificar un certificado</h1>
      <p className="mt-2 max-w-prose text-gris">Escanea el QR del certificado o escribe su código. No necesitas cuenta.</p>
      <form onSubmit={buscar} className="mt-6 flex flex-col gap-3 sm:flex-row" role="search">
        <label htmlFor="codigo" className="sr-only">Código del certificado</label>
        <input id="codigo" className="campo font-bold tracking-wide sm:max-w-sm" placeholder="SIGC-2026-XXXXXXXXXX"
          value={entrada} onChange={(e) => setEntrada(e.target.value)} />
        <button className="boton">Verificar</button>
      </form>

      <div className="mt-8">
        {cargando && <Cargando texto="Consultando el registro…" />}
        {error && <Aviso tono="error">{error}</Aviso>}
        {r && (
          <section className={`rounded-xl border-2 bg-blanco p-6 ${r.integro ? 'border-exito' : 'border-error'}`}>
            <p className={`text-2xl font-bold ${r.integro ? 'text-exito' : 'text-error'}`}>
              {r.integro ? 'Certificado auténtico' : 'Los datos no coinciden con lo emitido'}
            </p>
            <p className="mt-1 text-gris">
              {r.integro
                ? 'Los datos de abajo son los que registró la institución al emitirlo.'
                : 'El registro cambió después de la emisión. No aceptes este certificado sin consultar a la institución.'}
            </p>
            <dl className="mt-6 grid gap-x-8 gap-y-3 sm:grid-cols-2">
              <div><dt className="text-gris">Participante</dt><dd className="text-xl font-bold">{r.participante}</dd></div>
              <div><dt className="text-gris">DNI</dt><dd className="font-bold">{r.dni_parcial}</dd></div>
              <div className="sm:col-span-2"><dt className="text-gris">Capacitación</dt><dd className="font-bold">{r.capacitacion}</dd></div>
              <div><dt className="text-gris">Institución</dt><dd className="font-bold">{r.institucion}</dd></div>
              <div><dt className="text-gris">Horas y nota</dt><dd className="font-bold">{r.horas} horas · nota {r.nota.toFixed(2)}</dd></div>
              <div><dt className="text-gris">Emitido</dt><dd className="font-bold">{fechaHora(r.fecha_emision)}</dd></div>
              <div><dt className="text-gris">Código</dt><dd className="font-bold">{r.codigo}</dd></div>
            </dl>
            <p className="mt-4 break-all text-sm text-gris">Huella SHA-256: {r.hash_sha256}</p>

            <div className="mt-6 border-t border-linea pt-4">
              <label htmlFor="archivo" className="font-bold">¿Te enviaron el PDF? Comprueba que no fue modificado</label>
              <p className="text-sm text-gris">El archivo se revisa en tu navegador; solo se envía su huella.</p>
              <input id="archivo" type="file" accept="application/pdf" className="mt-2 block text-sm" onChange={(e) => revisarArchivo(e.target.files?.[0])} />
              {archivo && (
                <div className="mt-3">
                  <Aviso tono={archivo.coincide ? 'exito' : 'error'}>
                    {archivo.coincide
                      ? `${archivo.nombre} es idéntico al PDF emitido.`
                      : `${archivo.nombre} no es el PDF emitido para este código: fue modificado o pertenece a otro certificado.`}
                  </Aviso>
                </div>
              )}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
