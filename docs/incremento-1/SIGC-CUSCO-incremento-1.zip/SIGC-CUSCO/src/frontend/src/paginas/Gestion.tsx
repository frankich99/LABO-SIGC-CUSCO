import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, fechaCorta, type Capacitacion } from '../api';
import { Aviso, Cargando, EstadoCurso, Titulo } from '../componentes/ui';
import { useSesion } from '../sesion';

export function Gestion() {
  const { usuario, tiene } = useSesion();
  const [lista, setLista] = useState<Capacitacion[] | null>(null);
  const [error, setError] = useState('');

  useEffect(() => { api.get<Capacitacion[]>('/capacitaciones/gestion').then(setLista).catch((e) => setError(e.message)); }, []);

  const sub = usuario?.rol === 'Docente'
    ? 'Las capacitaciones que dictas: toma asistencia, registra notas y cierra el acta.'
    : usuario?.rol === 'Coordinador'
      ? 'Las capacitaciones de tu institución.'
      : 'Todas las capacitaciones del sistema.';

  return (
    <>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <Titulo sub={sub}>Mis cursos</Titulo>
        {tiene('Admin', 'Coordinador') && <Link to="/gestion/nueva" className="boton">Crear capacitación</Link>}
      </div>
      {error && <Aviso tono="error">{error}</Aviso>}
      {!lista && !error && <Cargando />}
      {lista && lista.length === 0 && <Aviso>Todavía no tienes capacitaciones asignadas.</Aviso>}
      {lista && lista.length > 0 && (
        <div className="overflow-x-auto rounded-xl border border-linea bg-blanco">
          <table className="tabla">
            <thead>
              <tr><th>Inicio</th><th>Capacitación</th><th>Estado</th><th>Inscritos</th><th>Acta</th></tr>
            </thead>
            <tbody>
              {lista.map((c) => (
                <tr key={c.id_capacitacion}>
                  <td className="whitespace-nowrap font-bold text-carmin">{fechaCorta(c.fecha_inicio)}</td>
                  <td>
                    <Link to={`/gestion/${c.id_capacitacion}`} className="font-bold hover:text-carmin hover:underline">{c.titulo}</Link>
                    <span className="block text-sm text-gris">{c.institucion}{c.docente ? ` · ${c.docente}` : ' · sin docente'}</span>
                  </td>
                  <td><EstadoCurso estado={c.estado} /></td>
                  <td className="whitespace-nowrap">{c.inscritos} / {c.vacantes_max}</td>
                  <td>{c.acta_cerrada ? 'Cerrada' : 'Abierta'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
