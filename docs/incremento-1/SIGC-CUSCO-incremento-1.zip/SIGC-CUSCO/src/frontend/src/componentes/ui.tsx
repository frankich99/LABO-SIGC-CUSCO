import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes } from 'react';
import { etiquetaEstado, type Capacitacion } from '../api';

type Tono = 'info' | 'exito' | 'alerta' | 'error';

const tonos: Record<Tono, string> = {
  info: 'bg-blanco border-linea text-tinta',
  exito: 'bg-exito-claro border-exito/30 text-exito',
  alerta: 'bg-alerta-claro border-alerta/30 text-alerta',
  error: 'bg-error-claro border-error/30 text-error',
};

export function Aviso({ tono = 'info', children }: { tono?: Tono; children: ReactNode }) {
  return (
    <div role={tono === 'error' ? 'alert' : 'status'} className={`rounded-lg border px-4 py-3 ${tonos[tono]}`}>
      {children}
    </div>
  );
}

interface PropsCampo extends InputHTMLAttributes<HTMLInputElement> {
  etiqueta: string;
  error?: string;
  ayuda?: string;
}

export function Campo({ etiqueta, error, ayuda, ...resto }: PropsCampo) {
  const id = useId();
  return (
    <div className="space-y-1">
      <label htmlFor={id} className="block font-bold">{etiqueta}</label>
      <input id={id} className="campo" aria-invalid={error ? true : undefined}
        aria-describedby={error || ayuda ? `${id}-nota` : undefined} {...resto} />
      {(error || ayuda) && (
        <p id={`${id}-nota`} className={`text-sm ${error ? 'text-error' : 'text-gris'}`}>{error ?? ayuda}</p>
      )}
    </div>
  );
}

interface PropsSelector extends SelectHTMLAttributes<HTMLSelectElement> {
  etiqueta: string;
  error?: string;
  children: ReactNode;
}

export function Selector({ etiqueta, error, children, ...resto }: PropsSelector) {
  const id = useId();
  return (
    <div className="space-y-1">
      <label htmlFor={id} className="block font-bold">{etiqueta}</label>
      <select id={id} className="campo" aria-invalid={error ? true : undefined} {...resto}>{children}</select>
      {error && <p className="text-sm text-error">{error}</p>}
    </div>
  );
}

const colorEstado: Record<Capacitacion['estado'], string> = {
  Planificada: 'bg-papel text-gris border-linea',
  Abierta: 'bg-exito-claro text-exito border-exito/30',
  En_Curso: 'bg-alerta-claro text-alerta border-alerta/30',
  Finalizada: 'bg-papel text-gris border-linea',
};

export function EstadoCurso({ estado }: { estado: Capacitacion['estado'] }) {
  return <span className={`inline-block rounded-full border px-2.5 py-0.5 text-sm font-bold ${colorEstado[estado]}`}>{etiquetaEstado[estado]}</span>;
}

const colorCondicion: Record<string, string> = {
  Confirmada: 'text-gris',
  Aprobado: 'text-exito',
  Desaprobado: 'text-error',
  Anulada: 'text-gris line-through',
};

export function Condicion({ estado }: { estado: string }) {
  return <span className={`font-bold ${colorCondicion[estado] ?? ''}`}>{estado === 'Confirmada' ? 'Inscrito' : estado}</span>;
}

/** Barra de vacantes: lo ocupado frente a la capacidad. */
export function Vacantes({ inscritos, total }: { inscritos: number; total: number }) {
  const libres = Math.max(0, total - inscritos);
  const pct = Math.min(100, Math.round((inscritos / total) * 100));
  const pocas = libres > 0 && libres <= Math.max(3, total * 0.1);
  return (
    <div className="min-w-36">
      <p className={`text-sm font-bold ${libres === 0 ? 'text-error' : pocas ? 'text-alerta' : 'text-tinta'}`}>
        {libres === 0 ? 'Sin vacantes' : `Quedan ${libres} de ${total} vacantes`}
      </p>
      <div className="mt-1 h-1.5 rounded-full bg-linea" aria-hidden="true">
        <div className={`h-1.5 rounded-full ${libres === 0 ? 'bg-error' : 'bg-carmin'}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function Cargando({ texto = 'Cargando…' }: { texto?: string }) {
  return <p className="py-8 text-gris" role="status">{texto}</p>;
}

export function Titulo({ children, sub }: { children: ReactNode; sub?: ReactNode }) {
  return (
    <header className="mb-6">
      <h1 className="text-3xl font-bold sm:text-4xl">{children}</h1>
      {sub && <p className="mt-2 max-w-prose text-gris">{sub}</p>}
    </header>
  );
}
