import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api, token, type Rol, type Sesion } from './api';

interface Contexto {
  usuario: Sesion | null;
  cargando: boolean;
  entrar: (t: string, u: Sesion) => void;
  salir: () => void;
  tiene: (...roles: Rol[]) => boolean;
}

const Ctx = createContext<Contexto | null>(null);

export function ProveedorSesion({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Sesion | null>(null);
  const [cargando, setCargando] = useState(() => token.leer() !== null);

  useEffect(() => {
    if (!token.leer()) return;
    api.get<{ usuario: Sesion }>('/auth/yo')
      .then((r) => setUsuario(r.usuario))
      .catch(() => token.borrar())
      .finally(() => setCargando(false));
  }, []);

  const entrar = useCallback((t: string, u: Sesion) => { token.guardar(t); setUsuario(u); }, []);
  const salir = useCallback(() => { token.borrar(); setUsuario(null); }, []);
  const tiene = useCallback((...roles: Rol[]) => !!usuario && roles.includes(usuario.rol), [usuario]);

  const valor = useMemo(() => ({ usuario, cargando, entrar, salir, tiene }), [usuario, cargando, entrar, salir, tiene]);
  return <Ctx.Provider value={valor}>{children}</Ctx.Provider>;
}

export function useSesion(): Contexto {
  const c = useContext(Ctx);
  if (!c) throw new Error('useSesion fuera de ProveedorSesion');
  return c;
}
