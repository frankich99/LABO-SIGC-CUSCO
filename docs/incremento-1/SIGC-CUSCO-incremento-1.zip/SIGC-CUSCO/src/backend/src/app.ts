import cors from 'cors';
import express, { type NextFunction, type Request, type Response } from 'express';
import helmet from 'helmet';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { ErrorApp } from './domain/errores.js';
import { leerSesion } from './middleware/auth.js';
import { rutasAdministracion } from './routes/administracion.js';
import { rutasAsistencias } from './routes/asistencias.js';
import { rutasAuth } from './routes/auth.js';
import { rutasCapacitaciones } from './routes/capacitaciones.js';
import { rutasEvaluacion } from './routes/evaluacion.js';
import { rutasInscripciones } from './routes/inscripciones.js';
import { rutasReportes } from './routes/reportes.js';

export function crearApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(cors());
  app.use(express.json({ limit: '1mb' }));
  app.use(leerSesion);

  app.get('/api/salud', (_req, res) => { res.json({ estado: 'ok' }); });
  app.use('/api/auth', rutasAuth);
  app.use('/api/capacitaciones', rutasCapacitaciones);
  app.use('/api/reportes', rutasReportes);
  app.use('/api', rutasAdministracion);
  app.use('/api', rutasInscripciones);
  app.use('/api', rutasAsistencias);
  app.use('/api', rutasEvaluacion);
  app.use('/api', (_req, _res, next) => next(new ErrorApp(404, 'Ruta no encontrada.')));

  // En producción, el mismo servidor entrega el frontend compilado.
  const web = process.env.WEB_DIR ?? path.resolve(process.cwd(), '../frontend/dist');
  if (existsSync(web)) {
    app.use(express.static(web, { index: false }));
    app.get(/^(?!\/api).*/, (_req, res) => { res.sendFile(path.join(web, 'index.html')); });
  }

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof ErrorApp) {
      res.status(err.status).json({ error: err.message, detalles: err.detalles });
      return;
    }
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ error: 'El cuerpo de la petición no es JSON válido.' });
      return;
    }
    console.error(err);
    res.status(500).json({ error: 'Ocurrió un error interno. Intenta de nuevo.' });
  });
  return app;
}
