function requerido(nombre: string, porDefecto?: string): string {
  const valor = process.env[nombre] ?? porDefecto;
  if (valor === undefined || valor === '') {
    throw new Error(`Falta la variable de entorno ${nombre}`);
  }
  return valor;
}

const esProduccion = process.env.NODE_ENV === 'production';

export const config = {
  puerto: Number(process.env.PORT ?? 3000),
  databaseUrl: requerido('DATABASE_URL', 'postgres://postgres:postgres@localhost:5432/sigc'),
  jwtSecret: requerido('JWT_SECRET', esProduccion ? undefined : 'secreto-solo-para-desarrollo'),
  qrSecret: requerido('QR_SECRET', esProduccion ? undefined : 'secreto-qr-solo-para-desarrollo'),
  bcryptCost: Number(process.env.BCRYPT_COST ?? 12),
  publicUrl: process.env.PUBLIC_URL ?? 'http://localhost:5173',
  storageDir: process.env.STORAGE_DIR ?? new URL('../storage', import.meta.url).pathname,
  // Duración de vigencia del QR de sesión que proyecta el docente.
  qrSesionSegundos: Number(process.env.QR_SESION_SEGUNDOS ?? 90),
  smtp: {
    host: process.env.SMTP_HOST ?? '',
    port: Number(process.env.SMTP_PORT ?? 587),
    user: process.env.SMTP_USER ?? '',
    pass: process.env.SMTP_PASS ?? '',
    from: process.env.MAIL_FROM ?? 'SIGC-CUSCO <no-responder@sigc-cusco.pe>',
  },
};
