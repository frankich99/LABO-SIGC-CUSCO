/**
 * Datos de demostración (ficticios) para desarrollo y la demo con usuarios.
 * Borra todo y vuelve a cargar. No se ejecuta en producción.
 */
import bcrypt from 'bcryptjs';
import { config } from '../config.js';
import { condicionFinal } from '../domain/evaluacion.js';
import { emitirCertificado } from '../services/certificados.js';
import { aplicarEsquema, vaciarBase } from './esquema.js';
import { consulta, pool } from './pool.js';

if (process.env.NODE_ENV === 'production') {
  console.error('El seed no se ejecuta en producción.');
  process.exit(1);
}

await aplicarEsquema();
await vaciarBase();

const hash = (c: string) => bcrypt.hash(c, Math.min(config.bcryptCost, 10));
const uno = async <T extends object>(sql: string, v: unknown[]) => (await consulta<T & Record<string, unknown>>(sql, v))[0];

const muni = await uno<{ id_institucion: number }>(
  "INSERT INTO instituciones (ruc, razon_social, tipo) VALUES ('20100000011', 'Municipalidad Distrital de Wanchaq', 'Publica') RETURNING id_institucion", []);
const hotel = await uno<{ id_institucion: number }>(
  "INSERT INTO instituciones (ruc, razon_social, tipo) VALUES ('20600000022', 'Hotel Inti Wasi Cusco S.A.C.', 'Privada') RETURNING id_institucion", []);
const agencia = await uno<{ id_institucion: number }>(
  "INSERT INTO instituciones (ruc, razon_social, tipo) VALUES ('20600000033', 'Qosqo Andes Travel E.I.R.L.', 'Privada') RETURNING id_institucion", []);

async function usuario(dni: string, nombres: string, apellidos: string, correo: string, clave: string, rol: string, inst: number | null = null) {
  const u = await uno<{ id_usuario: number }>(
    `INSERT INTO usuarios (dni, nombres, apellidos, correo, password_hash, rol, id_institucion)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id_usuario`,
    [dni, nombres, apellidos, correo, await hash(clave), rol, inst],
  );
  return u.id_usuario;
}

await usuario('40000001', 'Ana', 'Quispe Mamani', 'admin@sigc-cusco.pe', 'Admin2026!', 'Admin');
await usuario('40000002', 'Rosa', 'Huamán Ccori', 'coordinacion@wanchaq.demo', 'Coordina2026!', 'Coordinador', muni.id_institucion);
await usuario('40000005', 'Luis', 'Paucar Rojas', 'rrhh@intiwasi.demo', 'Coordina2026!', 'Coordinador', hotel.id_institucion);
const docente1 = await usuario('40000003', 'Julio', 'Condori Apaza', 'jcondori@sigc-cusco.pe', 'Docente2026!', 'Docente');
const docente2 = await usuario('40000004', 'María', 'Ttito Huallpa', 'mttito@sigc-cusco.pe', 'Docente2026!', 'Docente');

const nombres = [
  ['Carmen', 'Villca Sutta'], ['Edwin', 'Mayta Choque'], ['Lucía', 'Arroyo Puma'], ['Hernán', 'Chávez Quispe'],
  ['Yesenia', 'Ccahuana Loayza'], ['Wilber', 'Ayma Huarca'], ['Flor', 'Cusi Tupa'], ['Rubén', 'Sallo Inca'],
  ['Nélida', 'Huillca Roque'], ['Percy', 'Taype Ccasa'], ['Gladys', 'Pumayalli Farfán'], ['Marco', 'Alvarez Ccoa'],
];
const participantes: number[] = [];
for (let i = 0; i < nombres.length; i++) {
  const [n, a] = nombres[i];
  participantes.push(await usuario(`701234${50 + i}`, n, a, `${n.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')}.${i}@correo.demo`, 'Cusco2026', 'Participante'));
}

async function curso(d: {
  inst: number; doc: number; titulo: string; desc: string; modalidad: string; lugar: string; horas: number; vacantes: number;
  sesiones: number; inicio: string; fin: string; estado?: string;
}) {
  const c = await uno<{ id_capacitacion: number }>(
    `INSERT INTO capacitaciones (id_institucion, id_docente, titulo, descripcion, modalidad, lugar, horas_academicas,
       vacantes_max, numero_sesiones, asistencia_minima, fecha_inicio, fecha_fin, estado)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,75,$10,$11,$12) RETURNING id_capacitacion`,
    [d.inst, d.doc, d.titulo, d.desc, d.modalidad, d.lugar, d.horas, d.vacantes, d.sesiones, d.inicio, d.fin, d.estado ?? 'Abierta'],
  );
  return c.id_capacitacion;
}

const contrataciones = await curso({
  inst: muni.id_institucion, doc: docente1, titulo: 'Contrataciones públicas para áreas usuarias',
  desc: 'Requerimientos, términos de referencia y conformidad de servicios para personal municipal.',
  modalidad: 'Presencial', lugar: 'Auditorio municipal de Wanchaq', horas: 24, vacantes: 30, sesiones: 4,
  inicio: '2026-10-19', fin: '2026-10-30',
});
await curso({
  inst: hotel.id_institucion, doc: docente2, titulo: 'Atención al turista y calidad de servicio',
  desc: 'Protocolos de recepción, manejo de quejas y comunicación intercultural en hotelería.',
  modalidad: 'Mixta', lugar: 'Sala Pumacchupan, Hotel Inti Wasi', horas: 16, vacantes: 25, sesiones: 4,
  inicio: '2026-10-26', fin: '2026-11-06',
});
await curso({
  inst: agencia.id_institucion, doc: docente2, titulo: 'Inglés funcional para guías de turismo',
  desc: 'Vocabulario de circuitos, indicaciones y atención de emergencias en ruta.',
  modalidad: 'Virtual', lugar: 'Google Meet', horas: 40, vacantes: 40, sesiones: 10,
  inicio: '2026-11-02', fin: '2026-12-11',
});
const auxilios = await curso({
  inst: muni.id_institucion, doc: docente1, titulo: 'Primeros auxilios en eventos masivos',
  desc: 'Respuesta inicial ante emergencias en ferias, desfiles y actividades del Inti Raymi.',
  modalidad: 'Presencial', lugar: 'Compañía de Bomberos Cusco 39', horas: 12, vacantes: 6, sesiones: 3,
  inicio: '2026-10-12', fin: '2026-10-16',
});
const residuos = await curso({
  inst: muni.id_institucion, doc: docente1, titulo: 'Gestión de residuos sólidos municipales',
  desc: 'Segregación en la fuente, rutas de recolección y reportes al SIGERSOL.',
  modalidad: 'Presencial', lugar: 'Auditorio municipal de Wanchaq', horas: 20, vacantes: 20, sesiones: 4,
  inicio: '2026-09-07', fin: '2026-09-25', estado: 'En_Curso',
});

async function inscribir(idCap: number, idUsu: number) {
  const x = await uno<{ id_inscripcion: number }>(
    'INSERT INTO inscripciones (id_capacitacion, id_participante) VALUES ($1,$2) RETURNING id_inscripcion', [idCap, idUsu]);
  return x.id_inscripcion;
}

for (const p of participantes.slice(0, 5)) await inscribir(contrataciones, p);
for (const p of participantes.slice(3, 8)) await inscribir(auxilios, p);

// Curso terminado: asistencia, notas, acta cerrada y certificados emitidos.
const notas = [17, 14.5, 9, 16, 12, 18, 13.5, 15];
const asistio = [4, 4, 3, 4, 2, 4, 3, 4];
for (let i = 0; i < 8; i++) {
  const ins = await inscribir(residuos, participantes[i + 4]);
  for (let s = 1; s <= asistio[i]; s++) {
    await consulta(
      "INSERT INTO asistencias (id_inscripcion, numero_sesion, metodo, fecha_hora) VALUES ($1,$2,$3,$4)",
      [ins, s, s === 2 ? 'Offline_Sync' : 'QR_Digital', `2026-09-${String(7 + (s - 1) * 5).padStart(2, '0')}T09:0${i}:00-05:00`],
    );
  }
  const cond = condicionFinal(notas[i], asistio[i], 4, 75);
  await consulta('UPDATE inscripciones SET nota_final = $2, estado = $3 WHERE id_inscripcion = $1', [ins, notas[i], cond]);
}
await consulta("UPDATE capacitaciones SET acta_cerrada = TRUE, estado = 'Finalizada' WHERE id_capacitacion = $1", [residuos]);
const aprobados = await consulta<{ id_inscripcion: number }>(
  "SELECT id_inscripcion FROM inscripciones WHERE id_capacitacion = $1 AND estado = 'Aprobado'", [residuos]);
for (const a of aprobados) await emitirCertificado(a.id_inscripcion);

console.log('Datos de demostración cargados.');
console.log('  Admin        DNI 40000001 · Admin2026!');
console.log('  Coordinadora DNI 40000002 · Coordina2026!  (Municipalidad Distrital de Wanchaq)');
console.log('  Docente      DNI 40000003 · Docente2026!');
console.log('  Participante DNI 70123450 · Cusco2026');
await pool.end();
