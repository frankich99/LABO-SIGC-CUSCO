import { readFile } from 'node:fs/promises';
import { pool } from './pool.js';

const archivo = new URL('../../sql/001_esquema.sql', import.meta.url);

export async function aplicarEsquema(): Promise<void> {
  const sql = await readFile(archivo, 'utf8');
  await pool.query(sql);
}

/** Solo para pruebas: deja la base vacía. */
export async function vaciarBase(): Promise<void> {
  await pool.query(
    'TRUNCATE notificaciones, certificados, asistencias, inscripciones, capacitaciones, usuarios, instituciones RESTART IDENTITY CASCADE',
  );
}
