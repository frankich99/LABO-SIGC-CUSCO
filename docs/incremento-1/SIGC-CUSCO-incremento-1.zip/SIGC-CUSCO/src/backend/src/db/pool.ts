import pg from 'pg';
import { config } from '../config.js';

// NUMERIC llega como texto en pg; las notas se convierten a número.
pg.types.setTypeParser(1700, (v) => Number(v));
// DATE se mantiene como texto ISO (YYYY-MM-DD) para no desplazar el día por zona horaria.
pg.types.setTypeParser(1082, (v) => v);

export const pool = new pg.Pool({ connectionString: config.databaseUrl, max: 10 });

export type Cliente = pg.PoolClient;

export async function consulta<T extends pg.QueryResultRow = pg.QueryResultRow>(
  texto: string,
  valores: unknown[] = [],
): Promise<T[]> {
  const r = await pool.query<T>(texto, valores);
  return r.rows;
}

/** Ejecuta una función dentro de una transacción ACID. */
export async function transaccion<T>(fn: (c: Cliente) => Promise<T>): Promise<T> {
  const cliente = await pool.connect();
  try {
    await cliente.query('BEGIN');
    const r = await fn(cliente);
    await cliente.query('COMMIT');
    return r;
  } catch (e) {
    await cliente.query('ROLLBACK');
    throw e;
  } finally {
    cliente.release();
  }
}
