import { aplicarEsquema } from './esquema.js';
import { pool } from './pool.js';

await aplicarEsquema();
console.log('Esquema aplicado correctamente.');
await pool.end();
