/** Cupos disponibles = capacidad − inscripciones activas (nunca negativo). */
export function disponibles(capacidad: number, inscritos: number): number {
  if (!Number.isInteger(capacidad) || capacidad <= 0) throw new RangeError('La capacidad debe ser un entero positivo.');
  if (!Number.isInteger(inscritos) || inscritos < 0) throw new RangeError('Los inscritos deben ser un entero no negativo.');
  return Math.max(0, capacidad - inscritos);
}

export function hayCupo(capacidad: number, inscritos: number): boolean {
  return disponibles(capacidad, inscritos) > 0;
}
