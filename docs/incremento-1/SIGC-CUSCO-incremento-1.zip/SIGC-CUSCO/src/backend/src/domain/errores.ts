/** Error de negocio con código HTTP y mensaje para la persona usuaria. */
export class ErrorApp extends Error {
  constructor(
    public readonly status: number,
    mensaje: string,
    public readonly detalles?: unknown,
  ) {
    super(mensaje);
  }
}
