export type ResultadoValidacion = { valido: true } | { valido: false; motivo: string };

/**
 * Valida el formato de un DNI peruano: 8 dígitos numéricos.
 * Rechaza secuencias imposibles en el padrón (todos los dígitos iguales).
 */
export function validarDni(entrada: unknown): ResultadoValidacion {
  if (typeof entrada !== 'string') return { valido: false, motivo: 'El DNI debe ser texto.' };
  const dni = entrada.trim();
  if (!/^\d+$/.test(dni)) return { valido: false, motivo: 'El DNI solo puede contener números.' };
  if (dni.length !== 8) return { valido: false, motivo: 'El DNI debe tener exactamente 8 dígitos.' };
  if (/^(\d)\1{7}$/.test(dni)) return { valido: false, motivo: 'El DNI no puede tener todos los dígitos iguales.' };
  return { valido: true };
}
