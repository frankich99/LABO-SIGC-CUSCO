import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const b64 = (b: Buffer | string) => Buffer.from(b).toString('base64url');

function hmac(secreto: string, datos: string): string {
  return createHmac('sha256', secreto).update(datos).digest('base64url');
}

function iguales(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export function sha256(datos: string | Buffer): string {
  return createHash('sha256').update(datos).digest('hex');
}

// ---- QR dinámico de sesión (lo proyecta el docente) ----

export interface TokenSesion { idCapacitacion: number; sesion: number; expira: number }

export function firmarSesion(secreto: string, idCapacitacion: number, sesion: number, expiraEnMs: number): string {
  const carga = b64(JSON.stringify({ c: idCapacitacion, s: sesion, e: expiraEnMs }));
  return `${carga}.${hmac(secreto, carga)}`;
}

export type LecturaToken =
  | { ok: true; datos: TokenSesion }
  | { ok: false; motivo: 'invalido' | 'expirado' };

export function verificarSesion(secreto: string, token: string, ahoraMs: number): LecturaToken {
  const [carga, firma] = token.split('.');
  if (!carga || !firma || !iguales(firma, hmac(secreto, carga))) return { ok: false, motivo: 'invalido' };
  try {
    const d = JSON.parse(Buffer.from(carga, 'base64url').toString('utf8')) as { c: number; s: number; e: number };
    if (ahoraMs > d.e) return { ok: false, motivo: 'expirado' };
    return { ok: true, datos: { idCapacitacion: d.c, sesion: d.s, expira: d.e } };
  } catch {
    return { ok: false, motivo: 'invalido' };
  }
}

// ---- Credencial del participante (QR que muestra en su teléfono) ----

export function codigoCredencial(secreto: string, idInscripcion: number): string {
  return `INS-${idInscripcion}-${hmac(secreto, `ins:${idInscripcion}`).slice(0, 10)}`;
}

export function leerCredencial(secreto: string, codigo: string): number | null {
  const m = /^INS-(\d+)-([A-Za-z0-9_-]{10})$/.exec(codigo.trim());
  if (!m) return null;
  const id = Number(m[1]);
  return iguales(codigoCredencial(secreto, id), codigo.trim()) ? id : null;
}

// ---- Certificado ----

const ALFABETO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function nuevoCodigoCertificado(anio: number): string {
  const bytes = randomBytes(10);
  let s = '';
  for (const b of bytes) s += ALFABETO[b % ALFABETO.length];
  return `SIGC-${anio}-${s}`;
}

export interface DatosCertificado {
  codigo: string;
  dni: string;
  participante: string;
  capacitacion: string;
  institucion: string;
  horas: number;
  nota: number;
  fechaEmision: string; // ISO
}

/** Huella SHA-256 de los datos que acredita el certificado, en orden fijo. */
export function huellaCertificado(d: DatosCertificado): string {
  const canonico = [d.codigo, d.dni, d.participante, d.capacitacion, d.institucion, d.horas, d.nota.toFixed(2), d.fechaEmision].join('|');
  return sha256(canonico);
}
