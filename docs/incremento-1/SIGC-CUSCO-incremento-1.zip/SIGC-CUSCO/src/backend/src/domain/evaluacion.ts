export const NOTA_APROBATORIA = 11;

export type Condicion = 'Aprobado' | 'Desaprobado';

export function validarNota(nota: unknown): nota is number {
  return typeof nota === 'number' && Number.isFinite(nota) && nota >= 0 && nota <= 20;
}

/** Porcentaje de sesiones asistidas, redondeado a un decimal. */
export function porcentajeAsistencia(asistidas: number, totalSesiones: number): number {
  if (totalSesiones <= 0) throw new RangeError('El curso debe tener al menos una sesión.');
  const pct = (Math.min(asistidas, totalSesiones) / totalSesiones) * 100;
  return Math.round(pct * 10) / 10;
}

/**
 * Condición final: aprueba quien tiene nota ≥ 11 (escala vigesimal)
 * y cumple la asistencia mínima del curso.
 */
export function condicionFinal(nota: number, asistidas: number, totalSesiones: number, asistenciaMinima: number): Condicion {
  if (!validarNota(nota)) throw new RangeError('La nota debe estar entre 0 y 20.');
  const cumpleAsistencia = porcentajeAsistencia(asistidas, totalSesiones) >= asistenciaMinima;
  return nota >= NOTA_APROBATORIA && cumpleAsistencia ? 'Aprobado' : 'Desaprobado';
}
