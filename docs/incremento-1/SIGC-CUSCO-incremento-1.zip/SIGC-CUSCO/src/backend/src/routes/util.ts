import type { Request } from 'express';
import type { z } from 'zod';
import { consulta } from '../db/pool.js';
import { ErrorApp } from '../domain/errores.js';
import { sesionDe } from '../middleware/auth.js';

/** Valida un cuerpo con zod; si falla, responde 400 con el mensaje por campo. */
export function validar<T extends z.ZodType>(esquema: T, datos: unknown): z.infer<T> {
  const r = esquema.safeParse(datos);
  if (!r.success) {
    const campos: Record<string, string> = {};
    for (const i of r.error.issues) campos[i.path.join('.') || 'general'] ??= i.message;
    throw new ErrorApp(400, 'Revisa los datos marcados.', campos);
  }
  return r.data;
}

export function idParam(req: Request, nombre = 'id'): number {
  const v = Number(req.params[nombre]);
  if (!Number.isInteger(v) || v <= 0) throw new ErrorApp(400, `El parámetro ${nombre} no es válido.`);
  return v;
}

export interface Capacitacion {
  id_capacitacion: number;
  id_institucion: number;
  id_docente: number | null;
  titulo: string;
  descripcion: string;
  modalidad: string;
  lugar: string;
  horas_academicas: number;
  vacantes_max: number;
  numero_sesiones: number;
  asistencia_minima: number;
  fecha_inicio: string;
  fecha_fin: string | null;
  estado: string;
  acta_cerrada: boolean;
  institucion: string;
}

export async function obtenerCapacitacion(id: number): Promise<Capacitacion> {
  const [c] = await consulta<Capacitacion>(
    `SELECT c.*, i.razon_social AS institucion
       FROM capacitaciones c JOIN instituciones i USING (id_institucion)
      WHERE c.id_capacitacion = $1`,
    [id],
  );
  if (!c) throw new ErrorApp(404, 'La capacitación no existe.');
  return c;
}

/**
 * Nivel "gestion": Admin o Coordinador de la misma institución (editar el curso).
 * Nivel "aula": además el Docente asignado (asistencia, notas, certificados).
 */
export async function autorizarCapacitacion(req: Request, id: number, nivel: 'gestion' | 'aula'): Promise<Capacitacion> {
  const u = sesionDe(req);
  const c = await obtenerCapacitacion(id);
  const permitido =
    u.rol === 'Admin' ||
    (u.rol === 'Coordinador' && u.institucion === c.id_institucion) ||
    (nivel === 'aula' && u.rol === 'Docente' && c.id_docente === u.id);
  if (!permitido) throw new ErrorApp(403, 'No tienes acceso a esta capacitación.');
  return c;
}

export function exigirActaAbierta(c: Capacitacion): void {
  if (c.acta_cerrada) throw new ErrorApp(409, 'El acta de esta capacitación ya está cerrada; no admite cambios.');
}
