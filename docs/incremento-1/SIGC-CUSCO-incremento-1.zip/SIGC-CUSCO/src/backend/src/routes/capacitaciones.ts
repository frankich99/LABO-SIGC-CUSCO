import { Router } from 'express';
import { z } from 'zod';
import { consulta } from '../db/pool.js';
import { ErrorApp } from '../domain/errores.js';
import { requiere, sesionDe } from '../middleware/auth.js';
import { autorizarCapacitacion, exigirActaAbierta, idParam, validar } from './util.js';

export const rutasCapacitaciones = Router();

const fecha = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Usa el formato AAAA-MM-DD.');

const base = z.object({
  id_institucion: z.number({ message: 'Elige la institución.' }).int().positive(),
  id_docente: z.number().int().positive().nullable().optional(),
  titulo: z.string().trim().min(5, 'El título debe tener al menos 5 caracteres.').max(150),
  descripcion: z.string().trim().max(4000).default(''),
  modalidad: z.enum(['Presencial', 'Virtual', 'Mixta']).default('Presencial'),
  lugar: z.string().trim().max(150).default(''),
  horas_academicas: z.number({ message: 'Indica las horas.' }).int().min(1, 'Mínimo 1 hora.').max(500),
  vacantes_max: z.number({ message: 'Indica las vacantes.' }).int().min(1, 'Mínimo 1 vacante.').max(5000),
  numero_sesiones: z.number({ message: 'Indica las sesiones.' }).int().min(1, 'Mínimo 1 sesión.').max(200),
  asistencia_minima: z.number().int().min(0).max(100).default(75),
  fecha_inicio: fecha,
  fecha_fin: fecha.nullable().optional(),
});

const esquemaCapacitacion = base.refine((d) => !d.fecha_fin || d.fecha_fin >= d.fecha_inicio, {
  message: 'La fecha de fin no puede ser anterior a la de inicio.',
  path: ['fecha_fin'],
});

const COLUMNAS_PUBLICAS = `
  c.id_capacitacion, c.titulo, c.descripcion, c.modalidad, c.lugar, c.horas_academicas, c.vacantes_max,
  c.numero_sesiones, c.asistencia_minima, c.fecha_inicio, c.fecha_fin, c.estado, c.acta_cerrada,
  c.id_institucion, c.id_docente, i.razon_social AS institucion, i.tipo AS tipo_institucion,
  d.nombres || ' ' || d.apellidos AS docente,
  (SELECT count(*)::int FROM inscripciones x WHERE x.id_capacitacion = c.id_capacitacion AND x.estado <> 'Anulada') AS inscritos`;

const DESDE = `FROM capacitaciones c
  JOIN instituciones i USING (id_institucion)
  LEFT JOIN usuarios d ON d.id_usuario = c.id_docente`;

function conCupos<T extends { vacantes_max: number; inscritos: number }>(c: T) {
  return { ...c, disponibles: Math.max(0, c.vacantes_max - c.inscritos) };
}

// Catálogo público (HU-12): cursos abiertos o en curso.
rutasCapacitaciones.get('/', async (req, res) => {
  const q = typeof req.query.q === 'string' && req.query.q.trim() ? `%${req.query.q.trim()}%` : null;
  const inst = req.query.institucion ? Number(req.query.institucion) : null;
  const filas = await consulta<{ vacantes_max: number; inscritos: number }>(
    `SELECT ${COLUMNAS_PUBLICAS} ${DESDE}
      WHERE c.estado IN ('Abierta', 'En_Curso') AND i.activo
        AND ($1::text IS NULL OR c.titulo ILIKE $1 OR c.descripcion ILIKE $1)
        AND ($2::int IS NULL OR c.id_institucion = $2)
      ORDER BY c.fecha_inicio, c.titulo`,
    [q, Number.isInteger(inst) ? inst : null],
  );
  res.json(filas.map(conCupos));
});

// Cursos que la persona puede gestionar según su rol.
rutasCapacitaciones.get('/gestion', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const u = sesionDe(req);
  const filas = await consulta<{ vacantes_max: number; inscritos: number }>(
    `SELECT ${COLUMNAS_PUBLICAS} ${DESDE}
      WHERE $1 = 'Admin'
         OR ($1 = 'Coordinador' AND c.id_institucion = $2)
         OR ($1 = 'Docente' AND c.id_docente = $3)
      ORDER BY c.fecha_inicio DESC`,
    [u.rol, u.institucion, u.id],
  );
  res.json(filas.map(conCupos));
});

rutasCapacitaciones.get('/:id', async (req, res) => {
  const [c] = await consulta<{ vacantes_max: number; inscritos: number }>(
    `SELECT ${COLUMNAS_PUBLICAS} ${DESDE} WHERE c.id_capacitacion = $1`,
    [idParam(req)],
  );
  if (!c) throw new ErrorApp(404, 'La capacitación no existe.');
  res.json(conCupos(c));
});

async function validarReferencias(idInstitucion: number, idDocente: number | null | undefined, rol: string, instUsuario: number | null) {
  if (rol === 'Coordinador' && idInstitucion !== instUsuario) {
    throw new ErrorApp(403, 'Solo puedes crear capacitaciones de tu institución.');
  }
  const [i] = await consulta('SELECT 1 FROM instituciones WHERE id_institucion = $1 AND activo', [idInstitucion]);
  if (!i) throw new ErrorApp(400, 'Revisa los datos marcados.', { id_institucion: 'La institución no existe o está inactiva.' });
  if (idDocente) {
    const [d] = await consulta("SELECT 1 FROM usuarios WHERE id_usuario = $1 AND rol = 'Docente' AND activo", [idDocente]);
    if (!d) throw new ErrorApp(400, 'Revisa los datos marcados.', { id_docente: 'El docente elegido no es válido.' });
  }
}

// HU-06: crear capacitación; queda "Abierta" y se publica en el catálogo.
rutasCapacitaciones.post('/', requiere('Admin', 'Coordinador'), async (req, res) => {
  const u = sesionDe(req);
  const d = validar(esquemaCapacitacion, req.body);
  await validarReferencias(d.id_institucion, d.id_docente, u.rol, u.institucion);
  const [c] = await consulta(
    `INSERT INTO capacitaciones (id_institucion, id_docente, titulo, descripcion, modalidad, lugar, horas_academicas,
        vacantes_max, numero_sesiones, asistencia_minima, fecha_inicio, fecha_fin, estado)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'Abierta') RETURNING *`,
    [d.id_institucion, d.id_docente ?? null, d.titulo, d.descripcion, d.modalidad, d.lugar, d.horas_academicas,
      d.vacantes_max, d.numero_sesiones, d.asistencia_minima, d.fecha_inicio, d.fecha_fin ?? null],
  );
  res.status(201).json(c);
});

rutasCapacitaciones.put('/:id', requiere('Admin', 'Coordinador'), async (req, res) => {
  const id = idParam(req);
  const u = sesionDe(req);
  const actual = await autorizarCapacitacion(req, id, 'gestion');
  exigirActaAbierta(actual);
  const d = validar(esquemaCapacitacion, req.body);
  await validarReferencias(d.id_institucion, d.id_docente, u.rol, u.institucion);
  const [{ n }] = await consulta<{ n: number }>(
    "SELECT count(*)::int AS n FROM inscripciones WHERE id_capacitacion = $1 AND estado <> 'Anulada'",
    [id],
  );
  if (d.vacantes_max < n) {
    throw new ErrorApp(409, `Ya hay ${n} inscritos; las vacantes no pueden ser menos.`, { vacantes_max: `Mínimo ${n}.` });
  }
  const [c] = await consulta(
    `UPDATE capacitaciones SET id_institucion=$2, id_docente=$3, titulo=$4, descripcion=$5, modalidad=$6, lugar=$7,
        horas_academicas=$8, vacantes_max=$9, numero_sesiones=$10, asistencia_minima=$11, fecha_inicio=$12, fecha_fin=$13
      WHERE id_capacitacion = $1 RETURNING *`,
    [id, d.id_institucion, d.id_docente ?? null, d.titulo, d.descripcion, d.modalidad, d.lugar, d.horas_academicas,
      d.vacantes_max, d.numero_sesiones, d.asistencia_minima, d.fecha_inicio, d.fecha_fin ?? null],
  );
  res.json(c);
});

const esquemaEstado = z.object({ estado: z.enum(['Planificada', 'Abierta', 'En_Curso', 'Finalizada']) });

rutasCapacitaciones.patch('/:id/estado', requiere('Admin', 'Coordinador'), async (req, res) => {
  const id = idParam(req);
  const actual = await autorizarCapacitacion(req, id, 'gestion');
  const { estado } = validar(esquemaEstado, req.body);
  if (actual.acta_cerrada && estado !== 'Finalizada') throw new ErrorApp(409, 'Una capacitación con acta cerrada queda finalizada.');
  const [c] = await consulta('UPDATE capacitaciones SET estado = $2 WHERE id_capacitacion = $1 RETURNING *', [id, estado]);
  res.json(c);
});
