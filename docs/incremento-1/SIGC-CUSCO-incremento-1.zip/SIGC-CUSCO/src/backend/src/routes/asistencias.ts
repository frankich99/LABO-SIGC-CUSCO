import { Router } from 'express';
import QRCode from 'qrcode';
import { z } from 'zod';
import { config } from '../config.js';
import { consulta } from '../db/pool.js';
import { validarDni } from '../domain/dni.js';
import { ErrorApp } from '../domain/errores.js';
import { firmarSesion, leerCredencial, verificarSesion } from '../domain/firma.js';
import { requiere, sesionDe } from '../middleware/auth.js';
import { autorizarCapacitacion, exigirActaAbierta, idParam, obtenerCapacitacion, type Capacitacion, validar } from './util.js';

export const rutasAsistencias = Router();

function exigirSesionValida(c: Capacitacion, sesion: number): void {
  if (!Number.isInteger(sesion) || sesion < 1 || sesion > c.numero_sesiones) {
    throw new ErrorApp(400, `La sesión debe estar entre 1 y ${c.numero_sesiones}.`, { sesion: 'Sesión fuera de rango.' });
  }
}

type Metodo = 'QR_Digital' | 'PIN_Manual' | 'Offline_Sync';
type Estado = 'Presente' | 'Tardanza' | 'Falta';

/** Inserta la asistencia; devuelve false si ya existía para esa sesión. */
async function registrar(idInscripcion: number, sesion: number, estado: Estado, metodo: Metodo, fechaHora?: string): Promise<boolean> {
  const filas = await consulta(
    `INSERT INTO asistencias (id_inscripcion, numero_sesion, estado, metodo, fecha_hora)
     VALUES ($1, $2, $3, $4, COALESCE($5::timestamptz, now()))
     ON CONFLICT (id_inscripcion, numero_sesion) DO NOTHING
     RETURNING id_asistencia`,
    [idInscripcion, sesion, estado, metodo, fechaHora ?? null],
  );
  return filas.length === 1;
}

/** Ubica la inscripción activa a partir de un DNI o del código de credencial del participante. */
async function resolverInscripcion(idCap: number, identificador: string): Promise<{ id_inscripcion: number; nombre: string } | null> {
  const id = identificador.trim();
  const porCredencial = leerCredencial(config.qrSecret, id);
  if (porCredencial === null && !validarDni(id).valido) return null;
  const [x] = await consulta<{ id_inscripcion: number; nombre: string }>(
    `SELECT x.id_inscripcion, u.nombres || ' ' || u.apellidos AS nombre
       FROM inscripciones x JOIN usuarios u ON u.id_usuario = x.id_participante
      WHERE x.id_capacitacion = $1 AND x.estado <> 'Anulada'
        AND (x.id_inscripcion = $2 OR u.dni = $3)`,
    [idCap, porCredencial ?? -1, porCredencial === null ? id : null],
  );
  return x ?? null;
}

// HU-03 · El docente genera el QR dinámico de la sesión (vigencia corta).
rutasAsistencias.post('/capacitaciones/:id/sesiones/:sesion/qr', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const sesion = idParam(req, 'sesion');
  const c = await autorizarCapacitacion(req, id, 'aula');
  exigirActaAbierta(c);
  exigirSesionValida(c, sesion);
  const expira = Date.now() + config.qrSesionSegundos * 1000;
  const token = firmarSesion(config.qrSecret, id, sesion, expira);
  const url = `${config.publicUrl}/asistencia?t=${encodeURIComponent(token)}`;
  res.json({ token, url, expira, segundos: config.qrSesionSegundos, qr: await QRCode.toDataURL(url, { margin: 1, width: 480 }) });
});

// El participante abre el enlace del QR proyectado desde su teléfono.
rutasAsistencias.post('/asistencias/qr', requiere('Participante'), async (req, res) => {
  const { token } = validar(z.object({ token: z.string().min(10, 'Falta el código del QR.') }), req.body);
  const lectura = verificarSesion(config.qrSecret, token, Date.now());
  if (!lectura.ok) {
    throw new ErrorApp(400, lectura.motivo === 'expirado'
      ? 'Este QR ya venció. Escanea el código que se proyecta ahora.'
      : 'El código QR no es válido.');
  }
  const { idCapacitacion, sesion } = lectura.datos;
  const c = await obtenerCapacitacion(idCapacitacion);
  exigirActaAbierta(c);
  const [x] = await consulta<{ id_inscripcion: number }>(
    "SELECT id_inscripcion FROM inscripciones WHERE id_capacitacion = $1 AND id_participante = $2 AND estado <> 'Anulada'",
    [idCapacitacion, sesionDe(req).id],
  );
  if (!x) throw new ErrorApp(403, 'No estás inscrito en esta capacitación.');
  const nueva = await registrar(x.id_inscripcion, sesion, 'Presente', 'QR_Digital');
  if (!nueva) throw new ErrorApp(409, `Tu asistencia a la sesión ${sesion} ya fue registrada.`);
  res.status(201).json({ capacitacion: c.titulo, sesion, mensaje: `Asistencia registrada: sesión ${sesion} de ${c.titulo}.` });
});

const esquemaManual = z.object({
  sesion: z.number().int(),
  identificador: z.string().trim().min(1, 'Ingresa el DNI o el código de credencial.'),
  estado: z.enum(['Presente', 'Tardanza', 'Falta']).default('Presente'),
});

// Marcado manual por DNI o código de credencial (PIN_Manual).
rutasAsistencias.post('/capacitaciones/:id/asistencias', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  exigirActaAbierta(c);
  const d = validar(esquemaManual, req.body);
  exigirSesionValida(c, d.sesion);
  const x = await resolverInscripcion(id, d.identificador);
  if (!x) throw new ErrorApp(404, 'No hay un inscrito con ese DNI o código en esta capacitación.', { identificador: 'No encontrado.' });
  const nueva = await registrar(x.id_inscripcion, d.sesion, d.estado, 'PIN_Manual');
  if (!nueva) throw new ErrorApp(409, `La asistencia de ${x.nombre} a la sesión ${d.sesion} ya estaba registrada.`);
  res.status(201).json({ participante: x.nombre, sesion: d.sesion, estado: d.estado });
});

const esquemaSync = z.object({
  registros: z.array(z.object({
    clave: z.string().max(64),
    sesion: z.number().int(),
    identificador: z.string().trim().min(1),
    estado: z.enum(['Presente', 'Tardanza', 'Falta']).default('Presente'),
    fecha_hora: z.string().datetime({ offset: true, message: 'Fecha y hora inválidas.' }),
  })).max(2000),
});

// HU-11 · Sincroniza lo marcado sin conexión (Offline_Sync). Cada registro se resuelve por separado.
rutasAsistencias.post('/capacitaciones/:id/asistencias/sync', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  exigirActaAbierta(c);
  const { registros } = validar(esquemaSync, req.body);
  const limite = Date.now() + 5 * 60 * 1000;
  const resultados = [];
  for (const r of registros) {
    if (r.sesion < 1 || r.sesion > c.numero_sesiones) {
      resultados.push({ clave: r.clave, resultado: 'error', mensaje: 'Sesión fuera de rango.' });
      continue;
    }
    if (Date.parse(r.fecha_hora) > limite) {
      resultados.push({ clave: r.clave, resultado: 'error', mensaje: 'La fecha está en el futuro.' });
      continue;
    }
    const x = await resolverInscripcion(id, r.identificador);
    if (!x) {
      resultados.push({ clave: r.clave, resultado: 'error', mensaje: 'No hay un inscrito con ese DNI o código.' });
      continue;
    }
    const nueva = await registrar(x.id_inscripcion, r.sesion, r.estado, 'Offline_Sync', r.fecha_hora);
    resultados.push({ clave: r.clave, resultado: nueva ? 'registrado' : 'duplicado', mensaje: x.nombre });
  }
  res.json({ resultados });
});

// Matriz de asistencia de la capacitación.
rutasAsistencias.get('/capacitaciones/:id/asistencias', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  await autorizarCapacitacion(req, id, 'aula');
  res.json(await consulta(
    `SELECT a.id_asistencia, a.id_inscripcion, a.numero_sesion, a.fecha_hora, a.estado, a.metodo, u.dni,
            u.nombres || ' ' || u.apellidos AS participante
       FROM asistencias a
       JOIN inscripciones x USING (id_inscripcion)
       JOIN usuarios u ON u.id_usuario = x.id_participante
      WHERE x.id_capacitacion = $1
      ORDER BY a.numero_sesion, u.apellidos`,
    [id],
  ));
});
