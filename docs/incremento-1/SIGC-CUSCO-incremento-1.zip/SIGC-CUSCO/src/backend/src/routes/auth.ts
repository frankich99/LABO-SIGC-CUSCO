import bcrypt from 'bcryptjs';
import { Router } from 'express';
import { z } from 'zod';
import { config } from '../config.js';
import { consulta } from '../db/pool.js';
import { ErrorApp } from '../domain/errores.js';
import { emitirToken, requiere, sesionDe, type Rol, type Sesion } from '../middleware/auth.js';
import { validar } from './util.js';

export const rutasAuth = Router();

interface FilaUsuario {
  id_usuario: number;
  dni: string;
  nombres: string;
  apellidos: string;
  correo: string;
  password_hash: string;
  rol: Rol;
  id_institucion: number | null;
  activo: boolean;
}

export function sesionDesdeUsuario(u: FilaUsuario): Sesion {
  return { id: u.id_usuario, rol: u.rol, nombre: `${u.nombres} ${u.apellidos}`, institucion: u.id_institucion };
}

export function hashPassword(clave: string): Promise<string> {
  return bcrypt.hash(clave, config.bcryptCost);
}

export async function buscarPorDni(dni: string): Promise<FilaUsuario | undefined> {
  const [u] = await consulta<FilaUsuario>('SELECT * FROM usuarios WHERE dni = $1', [dni]);
  return u;
}

export async function comprobarClave(u: FilaUsuario, clave: string): Promise<boolean> {
  return bcrypt.compare(clave, u.password_hash);
}

const esquemaLogin = z.object({
  usuario: z.string().trim().min(1, 'Ingresa tu DNI o correo.'),
  password: z.string().min(1, 'Ingresa tu contraseña.'),
});

rutasAuth.post('/login', async (req, res) => {
  const { usuario, password } = validar(esquemaLogin, req.body);
  const [u] = await consulta<FilaUsuario>('SELECT * FROM usuarios WHERE dni = $1 OR lower(correo) = lower($1)', [usuario]);
  if (!u || !(await comprobarClave(u, password))) throw new ErrorApp(401, 'El DNI, el correo o la contraseña no coinciden.');
  if (!u.activo) throw new ErrorApp(403, 'Tu cuenta está desactivada. Comunícate con el administrador.');
  const sesion = sesionDesdeUsuario(u);
  res.json({ token: emitirToken(sesion), usuario: sesion });
});

rutasAuth.get('/yo', requiere(), (req, res) => {
  res.json({ usuario: sesionDe(req) });
});
