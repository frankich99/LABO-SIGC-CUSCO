import { Router } from 'express';
import { consulta } from '../db/pool.js';
import { porcentajeAsistencia } from '../domain/evaluacion.js';
import { requiere, sesionDe } from '../middleware/auth.js';
import { excelReporte } from '../services/excel.js';
import { pdfPadron, type FilaPadron } from '../services/pdf.js';
import { autorizarCapacitacion, idParam } from './util.js';

export const rutasReportes = Router();

// HU-09 · Tablero gerencial (Admin: todo; Coordinador: su institución)
rutasReportes.get('/resumen', requiere('Admin', 'Coordinador'), async (req, res) => {
  const u = sesionDe(req);
  const filas = await consulta<{
    id_capacitacion: number; titulo: string; institucion: string; estado: string; vacantes_max: number;
    numero_sesiones: number; inscritos: number; asistencias: number; aprobados: number; desaprobados: number; certificados: number;
  }>(
    `SELECT c.id_capacitacion, c.titulo, i.razon_social AS institucion, c.estado, c.vacantes_max, c.numero_sesiones,
            count(x.*) FILTER (WHERE x.estado <> 'Anulada')::int AS inscritos,
            (SELECT count(*)::int FROM asistencias a JOIN inscripciones y USING (id_inscripcion)
              WHERE y.id_capacitacion = c.id_capacitacion AND y.estado <> 'Anulada' AND a.estado <> 'Falta') AS asistencias,
            count(x.*) FILTER (WHERE x.estado = 'Aprobado')::int AS aprobados,
            count(x.*) FILTER (WHERE x.estado = 'Desaprobado')::int AS desaprobados,
            (SELECT count(*)::int FROM certificados k JOIN inscripciones y USING (id_inscripcion)
              WHERE y.id_capacitacion = c.id_capacitacion) AS certificados
       FROM capacitaciones c
       JOIN instituciones i USING (id_institucion)
       LEFT JOIN inscripciones x ON x.id_capacitacion = c.id_capacitacion
      WHERE $1 = 'Admin' OR c.id_institucion = $2
      GROUP BY c.id_capacitacion, i.razon_social
      ORDER BY c.fecha_inicio DESC`,
    [u.rol, u.institucion],
  );
  const capacitaciones = filas.map((f) => ({
    ...f,
    ocupacion: Math.round((f.inscritos / f.vacantes_max) * 1000) / 10,
    asistencia_promedio: f.inscritos === 0 ? 0 : porcentajeAsistencia(f.asistencias / f.inscritos, f.numero_sesiones),
  }));
  const suma = (k: 'inscritos' | 'aprobados' | 'desaprobados' | 'certificados') => filas.reduce((s, f) => s + f[k], 0);
  res.json({
    totales: {
      capacitaciones: filas.length,
      inscritos: suma('inscritos'),
      aprobados: suma('aprobados'),
      desaprobados: suma('desaprobados'),
      certificados: suma('certificados'),
    },
    capacitaciones,
  });
});

async function datosPadron(id: number, sesiones: number): Promise<FilaPadron[]> {
  const filas = await consulta<{ dni: string; participante: string; asistidas: number; nota_final: number | null; estado: string }>(
    `SELECT u.dni, u.apellidos || ', ' || u.nombres AS participante, x.nota_final, x.estado,
            (SELECT count(*)::int FROM asistencias a WHERE a.id_inscripcion = x.id_inscripcion AND a.estado <> 'Falta') AS asistidas
       FROM inscripciones x JOIN usuarios u ON u.id_usuario = x.id_participante
      WHERE x.id_capacitacion = $1 AND x.estado <> 'Anulada'
      ORDER BY u.apellidos, u.nombres`,
    [id],
  );
  return filas.map((f) => ({
    dni: f.dni, participante: f.participante, asistidas: f.asistidas,
    porcentaje: porcentajeAsistencia(f.asistidas, sesiones), nota: f.nota_final, estado: f.estado,
  }));
}

rutasReportes.get('/capacitaciones/:id/excel', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  const padron = await datosPadron(id, c.numero_sesiones);
  const detalle = await consulta<{ dni: string; participante: string; sesion: number; fecha_hora: Date; estado: string; metodo: string }>(
    `SELECT u.dni, u.apellidos || ', ' || u.nombres AS participante, a.numero_sesion AS sesion, a.fecha_hora, a.estado, a.metodo
       FROM asistencias a JOIN inscripciones x USING (id_inscripcion) JOIN usuarios u ON u.id_usuario = x.id_participante
      WHERE x.id_capacitacion = $1 ORDER BY a.numero_sesion, u.apellidos`,
    [id],
  );
  const libro = await excelReporte(c.titulo, c.institucion, c.numero_sesiones, padron, detalle.map((d) => ({
    ...d, fechaHora: new Date(d.fecha_hora).toLocaleString('es-PE', { timeZone: 'America/Lima' }),
  })));
  res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    .setHeader('Content-Disposition', `attachment; filename="reporte-capacitacion-${id}.xlsx"`)
    .send(libro);
});

rutasReportes.get('/capacitaciones/:id/pdf', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  const pdf = await pdfPadron(c.titulo, c.institucion, c.numero_sesiones, await datosPadron(id, c.numero_sesiones));
  res.type('application/pdf').setHeader('Content-Disposition', `attachment; filename="padron-capacitacion-${id}.pdf"`).send(pdf);
});
