import { Router } from 'express';
import { z } from 'zod';
import { consulta } from '../db/pool.js';
import { validarDni } from '../domain/dni.js';
import { ErrorApp } from '../domain/errores.js';
import { requiere } from '../middleware/auth.js';
import { hashPassword } from './auth.js';
import { idParam, validar } from './util.js';

export const rutasAdministracion = Router();

// ---------- Instituciones (HU-07 · multientidad) ----------

const esquemaInstitucion = z.object({
  ruc: z.string().trim().regex(/^(10|15|17|20)\d{9}$/, 'El RUC debe tener 11 dígitos y empezar con 10, 15, 17 o 20.'),
  razon_social: z.string().trim().min(3, 'Escribe la razón social.').max(150),
  tipo: z.enum(['Publica', 'Privada'], { message: 'Elige Pública o Privada.' }),
  logo_url: z.string().trim().url('El logo debe ser una URL válida.').optional().or(z.literal('')),
});

// Lista pública: el catálogo filtra por institución.
rutasAdministracion.get('/instituciones', async (_req, res) => {
  res.json(await consulta(
    'SELECT id_institucion, razon_social, tipo, logo_url, ruc, activo FROM instituciones WHERE activo ORDER BY razon_social',
  ));
});

rutasAdministracion.get('/instituciones/todas', requiere('Admin'), async (_req, res) => {
  res.json(await consulta(
    `SELECT i.*, (SELECT count(*)::int FROM capacitaciones c WHERE c.id_institucion = i.id_institucion) AS capacitaciones
       FROM instituciones i ORDER BY razon_social`,
  ));
});

rutasAdministracion.post('/instituciones', requiere('Admin'), async (req, res) => {
  const d = validar(esquemaInstitucion, req.body);
  const [dup] = await consulta('SELECT 1 FROM instituciones WHERE ruc = $1', [d.ruc]);
  if (dup) throw new ErrorApp(409, 'Ya existe una institución con ese RUC.', { ruc: 'RUC ya registrado.' });
  const [nueva] = await consulta(
    'INSERT INTO instituciones (ruc, razon_social, tipo, logo_url) VALUES ($1, $2, $3, $4) RETURNING *',
    [d.ruc, d.razon_social, d.tipo, d.logo_url || null],
  );
  res.status(201).json(nueva);
});

rutasAdministracion.patch('/instituciones/:id', requiere('Admin'), async (req, res) => {
  const id = idParam(req);
  const d = validar(esquemaInstitucion.partial().extend({ activo: z.boolean().optional() }), req.body);
  const [act] = await consulta(
    `UPDATE instituciones SET
        razon_social = COALESCE($2, razon_social), tipo = COALESCE($3, tipo),
        logo_url = COALESCE($4, logo_url), activo = COALESCE($5, activo)
      WHERE id_institucion = $1 RETURNING *`,
    [id, d.razon_social ?? null, d.tipo ?? null, d.logo_url ?? null, d.activo ?? null],
  );
  if (!act) throw new ErrorApp(404, 'La institución no existe.');
  res.json(act);
});

// ---------- Usuarios y roles (HU-10 · RBAC) ----------

const roles = ['Admin', 'Coordinador', 'Docente', 'Participante'] as const;

const esquemaUsuario = z.object({
  dni: z.string().trim(),
  nombres: z.string().trim().min(2, 'Escribe los nombres.').max(80),
  apellidos: z.string().trim().min(2, 'Escribe los apellidos.').max(80),
  correo: z.string().trim().toLowerCase().email('Escribe un correo válido.'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres.'),
  rol: z.enum(roles, { message: 'Elige un rol.' }),
  id_institucion: z.number().int().positive().nullable().optional(),
});

function exigirInstitucionSiCoordinador(rol: string, inst: number | null | undefined): void {
  if (rol === 'Coordinador' && !inst) {
    throw new ErrorApp(400, 'Un coordinador debe pertenecer a una institución.', { id_institucion: 'Elige la institución.' });
  }
}

rutasAdministracion.get('/usuarios', requiere('Admin'), async (req, res) => {
  const rol = typeof req.query.rol === 'string' ? req.query.rol : null;
  res.json(await consulta(
    `SELECT u.id_usuario, u.dni, u.nombres, u.apellidos, u.correo, u.rol, u.id_institucion, u.activo,
            i.razon_social AS institucion
       FROM usuarios u LEFT JOIN instituciones i USING (id_institucion)
      WHERE ($1::text IS NULL OR u.rol = $1)
      ORDER BY u.rol, u.apellidos`,
    [rol],
  ));
});

rutasAdministracion.get('/usuarios/docentes', requiere('Admin', 'Coordinador'), async (_req, res) => {
  res.json(await consulta(
    "SELECT id_usuario, nombres, apellidos, dni FROM usuarios WHERE rol = 'Docente' AND activo ORDER BY apellidos",
  ));
});

rutasAdministracion.post('/usuarios', requiere('Admin'), async (req, res) => {
  const d = validar(esquemaUsuario, req.body);
  const v = validarDni(d.dni);
  if (!v.valido) throw new ErrorApp(400, 'Revisa los datos marcados.', { dni: v.motivo });
  exigirInstitucionSiCoordinador(d.rol, d.id_institucion);
  const [dup] = await consulta<{ dni: string }>('SELECT dni FROM usuarios WHERE dni = $1 OR correo = $2', [d.dni, d.correo]);
  if (dup) throw new ErrorApp(409, 'Ya existe un usuario con ese DNI o correo.');
  const [u] = await consulta(
    `INSERT INTO usuarios (dni, nombres, apellidos, correo, password_hash, rol, id_institucion)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id_usuario, dni, nombres, apellidos, correo, rol, id_institucion, activo`,
    [d.dni, d.nombres, d.apellidos, d.correo, await hashPassword(d.password), d.rol, d.id_institucion ?? null],
  );
  res.status(201).json(u);
});

const esquemaRol = z.object({
  rol: z.enum(roles, { message: 'Elige un rol.' }),
  id_institucion: z.number().int().positive().nullable().optional(),
  activo: z.boolean().optional(),
});

rutasAdministracion.patch('/usuarios/:id', requiere('Admin'), async (req, res) => {
  const id = idParam(req);
  const d = validar(esquemaRol, req.body);
  exigirInstitucionSiCoordinador(d.rol, d.id_institucion);
  if (req.usuario?.id === id && d.rol !== 'Admin') {
    throw new ErrorApp(409, 'No puedes quitarte a ti mismo el rol de administrador.');
  }
  const [u] = await consulta(
    `UPDATE usuarios SET rol = $2, id_institucion = $3, activo = COALESCE($4, activo)
      WHERE id_usuario = $1
      RETURNING id_usuario, dni, nombres, apellidos, correo, rol, id_institucion, activo`,
    [id, d.rol, d.rol === 'Coordinador' ? d.id_institucion : (d.id_institucion ?? null), d.activo ?? null],
  );
  if (!u) throw new ErrorApp(404, 'El usuario no existe.');
  res.json(u);
});

rutasAdministracion.get('/notificaciones', requiere('Admin'), async (_req, res) => {
  res.json(await consulta('SELECT * FROM notificaciones ORDER BY id_notificacion DESC LIMIT 50'));
});
