import { Router } from 'express';
import QRCode from 'qrcode';
import { z } from 'zod';
import { config } from '../config.js';
import { consulta, transaccion } from '../db/pool.js';
import { hayCupo } from '../domain/cupos.js';
import { validarDni } from '../domain/dni.js';
import { ErrorApp } from '../domain/errores.js';
import { codigoCredencial } from '../domain/firma.js';
import { emitirToken, requiere, sesionDe, type Sesion } from '../middleware/auth.js';
import { enviarCorreo } from '../services/correo.js';
import { buscarPorDni, comprobarClave, hashPassword, sesionDesdeUsuario } from './auth.js';
import { autorizarCapacitacion, idParam, validar } from './util.js';

export const rutasInscripciones = Router();

const esquemaInscripcion = z.object({
  dni: z.string().trim(),
  password: z.string().min(1, 'Ingresa una contraseña.'),
  nombres: z.string().trim().max(80).optional(),
  apellidos: z.string().trim().max(80).optional(),
  correo: z.string().trim().toLowerCase().optional(),
});

const datosNuevo = z.object({
  nombres: z.string({ message: 'Escribe tus nombres.' }).trim().min(2, 'Escribe tus nombres.'),
  apellidos: z.string({ message: 'Escribe tus apellidos.' }).trim().min(2, 'Escribe tus apellidos.'),
  correo: z.string({ message: 'Escribe tu correo.' }).email('Escribe un correo válido.'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres.'),
});

interface CursoBloqueado {
  id_capacitacion: number;
  titulo: string;
  estado: string;
  vacantes_max: number;
  fecha_inicio: string;
  lugar: string;
  modalidad: string;
  institucion: string;
}

/**
 * HU-01 · Inscripción con DNI.
 * Si el DNI no existe, crea la cuenta de participante en el mismo paso.
 * El curso se bloquea (SELECT … FOR UPDATE) para que dos inscripciones
 * simultáneas no superen las vacantes.
 */
rutasInscripciones.post('/capacitaciones/:id/inscripciones', async (req, res) => {
  const idCap = idParam(req);
  const d = validar(esquemaInscripcion, req.body);
  const v = validarDni(d.dni);
  if (!v.valido) throw new ErrorApp(400, 'Revisa los datos marcados.', { dni: v.motivo });

  let usuario = await buscarPorDni(d.dni);
  let nuevo = false;
  if (usuario) {
    if (!(await comprobarClave(usuario, d.password))) {
      throw new ErrorApp(401, 'Este DNI ya tiene cuenta. Ingresa tu contraseña para inscribirte.', { password: 'Contraseña incorrecta.' });
    }
    if (usuario.rol !== 'Participante') throw new ErrorApp(409, 'Solo las cuentas de participante pueden inscribirse.');
  } else {
    const n = validar(datosNuevo, d);
    const [dup] = await consulta('SELECT 1 FROM usuarios WHERE correo = $1', [n.correo]);
    if (dup) throw new ErrorApp(409, 'Ese correo ya está registrado con otro DNI.', { correo: 'Correo ya registrado.' });
    nuevo = true;
    usuario = {
      id_usuario: 0, dni: d.dni, nombres: n.nombres, apellidos: n.apellidos, correo: n.correo,
      password_hash: await hashPassword(n.password), rol: 'Participante', id_institucion: null, activo: true,
    };
  }

  const resultado = await transaccion(async (c) => {
    const { rows: [curso] } = await c.query<CursoBloqueado>(
      `SELECT c.id_capacitacion, c.titulo, c.estado, c.vacantes_max, c.fecha_inicio, c.lugar, c.modalidad, i.razon_social AS institucion
         FROM capacitaciones c JOIN instituciones i USING (id_institucion)
        WHERE c.id_capacitacion = $1 FOR UPDATE OF c`,
      [idCap],
    );
    if (!curso) throw new ErrorApp(404, 'La capacitación no existe.');
    if (curso.estado !== 'Abierta') throw new ErrorApp(409, 'Esta capacitación no tiene la inscripción abierta.');

    let idUsuario = usuario.id_usuario;
    if (nuevo) {
      const { rows: [u] } = await c.query<{ id_usuario: number }>(
        `INSERT INTO usuarios (dni, nombres, apellidos, correo, password_hash, rol)
         VALUES ($1, $2, $3, $4, $5, 'Participante') RETURNING id_usuario`,
        [usuario.dni, usuario.nombres, usuario.apellidos, usuario.correo, usuario.password_hash],
      );
      idUsuario = u.id_usuario;
    }

    const { rows: [previa] } = await c.query<{ id_inscripcion: number; estado: string }>(
      'SELECT id_inscripcion, estado FROM inscripciones WHERE id_capacitacion = $1 AND id_participante = $2',
      [idCap, idUsuario],
    );
    if (previa && previa.estado !== 'Anulada') throw new ErrorApp(409, 'Ya estás inscrito en esta capacitación.');

    const { rows: [{ n }] } = await c.query<{ n: number }>(
      "SELECT count(*)::int AS n FROM inscripciones WHERE id_capacitacion = $1 AND estado <> 'Anulada'",
      [idCap],
    );
    if (!hayCupo(curso.vacantes_max, n)) throw new ErrorApp(409, 'No quedan vacantes en esta capacitación.');

    const { rows: [ins] } = previa
      ? await c.query<{ id_inscripcion: number }>(
          "UPDATE inscripciones SET estado = 'Confirmada', fecha_registro = now() WHERE id_inscripcion = $1 RETURNING id_inscripcion",
          [previa.id_inscripcion],
        )
      : await c.query<{ id_inscripcion: number }>(
          'INSERT INTO inscripciones (id_capacitacion, id_participante) VALUES ($1, $2) RETURNING id_inscripcion',
          [idCap, idUsuario],
        );
    return { curso, idUsuario, idInscripcion: ins.id_inscripcion, disponibles: curso.vacantes_max - n - 1 };
  });

  const sesion: Sesion = sesionDesdeUsuario({ ...usuario, id_usuario: resultado.idUsuario });
  const credencial = codigoCredencial(config.qrSecret, resultado.idInscripcion);

  // HU-02 · Confirmación por correo
  await enviarCorreo(
    usuario.correo,
    `Inscripción confirmada: ${resultado.curso.titulo}`,
    [
      `Hola, ${usuario.nombres}.`,
      '',
      `Tu inscripción a "${resultado.curso.titulo}" (${resultado.curso.institucion}) quedó confirmada.`,
      `Inicio: ${resultado.curso.fecha_inicio} · Modalidad: ${resultado.curso.modalidad}${resultado.curso.lugar ? ` · Lugar: ${resultado.curso.lugar}` : ''}`,
      `Código de tu credencial de asistencia: ${credencial}`,
      '',
      `Revisa tus inscripciones en ${config.publicUrl}/mis-inscripciones`,
    ].join('\n'),
  );

  res.status(201).json({
    id_inscripcion: resultado.idInscripcion,
    credencial,
    disponibles: resultado.disponibles,
    cuenta_nueva: nuevo,
    token: emitirToken(sesion),
    usuario: sesion,
  });
});

// Mis inscripciones (participante)
rutasInscripciones.get('/mis-inscripciones', requiere('Participante'), async (req, res) => {
  const u = sesionDe(req);
  const filas = await consulta<{ id_inscripcion: number }>(
    `SELECT x.id_inscripcion, x.estado, x.nota_final, x.fecha_registro,
            c.id_capacitacion, c.titulo, c.fecha_inicio, c.fecha_fin, c.modalidad, c.lugar, c.horas_academicas,
            c.numero_sesiones, c.asistencia_minima, c.acta_cerrada, c.estado AS estado_capacitacion,
            i.razon_social AS institucion,
            (SELECT count(*)::int FROM asistencias a WHERE a.id_inscripcion = x.id_inscripcion AND a.estado <> 'Falta') AS asistidas,
            k.codigo_unico AS certificado
       FROM inscripciones x
       JOIN capacitaciones c USING (id_capacitacion)
       JOIN instituciones i ON i.id_institucion = c.id_institucion
       LEFT JOIN certificados k ON k.id_inscripcion = x.id_inscripcion
      WHERE x.id_participante = $1
      ORDER BY c.fecha_inicio DESC`,
    [u.id],
  );
  res.json(filas.map((f) => ({ ...f, credencial: codigoCredencial(config.qrSecret, f.id_inscripcion) })));
});

async function inscripcionPropia(idInscripcion: number, idUsuario: number) {
  const [x] = await consulta<{ id_inscripcion: number; estado: string; acta_cerrada: boolean; estado_capacitacion: string }>(
    `SELECT x.id_inscripcion, x.estado, c.acta_cerrada, c.estado AS estado_capacitacion
       FROM inscripciones x JOIN capacitaciones c USING (id_capacitacion)
      WHERE x.id_inscripcion = $1 AND x.id_participante = $2`,
    [idInscripcion, idUsuario],
  );
  if (!x) throw new ErrorApp(404, 'No encontramos esa inscripción en tu cuenta.');
  return x;
}

rutasInscripciones.get('/inscripciones/:id/credencial', requiere('Participante'), async (req, res) => {
  const x = await inscripcionPropia(idParam(req), sesionDe(req).id);
  const codigo = codigoCredencial(config.qrSecret, x.id_inscripcion);
  res.json({ codigo, qr: await QRCode.toDataURL(codigo, { margin: 1, width: 320 }) });
});

// Cancelar inscripción: libera la vacante.
rutasInscripciones.delete('/inscripciones/:id', requiere('Participante'), async (req, res) => {
  const x = await inscripcionPropia(idParam(req), sesionDe(req).id);
  if (x.estado !== 'Confirmada' || x.acta_cerrada || x.estado_capacitacion === 'Finalizada') {
    throw new ErrorApp(409, 'Esta inscripción ya no se puede cancelar.');
  }
  await consulta("UPDATE inscripciones SET estado = 'Anulada' WHERE id_inscripcion = $1", [x.id_inscripcion]);
  res.status(204).end();
});

// Lista de inscritos con asistencia y nota (docente, coordinador, admin)
rutasInscripciones.get('/capacitaciones/:id/inscritos', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  await autorizarCapacitacion(req, id, 'aula');
  res.json(await consulta(
    `SELECT x.id_inscripcion, x.estado, x.nota_final, x.fecha_registro,
            u.dni, u.nombres, u.apellidos, u.correo,
            (SELECT count(*)::int FROM asistencias a WHERE a.id_inscripcion = x.id_inscripcion AND a.estado <> 'Falta') AS asistidas,
            k.codigo_unico AS certificado
       FROM inscripciones x
       JOIN usuarios u ON u.id_usuario = x.id_participante
       LEFT JOIN certificados k ON k.id_inscripcion = x.id_inscripcion
      WHERE x.id_capacitacion = $1 AND x.estado <> 'Anulada'
      ORDER BY u.apellidos, u.nombres`,
    [id],
  ));
});
