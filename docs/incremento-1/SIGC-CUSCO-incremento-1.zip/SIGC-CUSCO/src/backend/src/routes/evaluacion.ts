import { Router } from 'express';
import { z } from 'zod';
import { consulta, transaccion } from '../db/pool.js';
import { ErrorApp } from '../domain/errores.js';
import { condicionFinal } from '../domain/evaluacion.js';
import { requiere, sesionDe } from '../middleware/auth.js';
import { certificadoDe, emitirCertificado, leerPdf, verificarCertificado } from '../services/certificados.js';
import { autorizarCapacitacion, exigirActaAbierta, idParam, validar } from './util.js';

export const rutasEvaluacion = Router();

const esquemaNotas = z.object({
  notas: z.array(z.object({
    id_inscripcion: z.number().int().positive(),
    nota: z.number({ message: 'La nota debe ser un número.' }).min(0, 'Mínimo 0.').max(20, 'Máximo 20.').nullable(),
  })).min(1, 'Envía al menos una nota.'),
});

// HU-04 · Registrar notas (escala vigesimal) mientras el acta está abierta.
rutasEvaluacion.put('/capacitaciones/:id/notas', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  exigirActaAbierta(c);
  const { notas } = validar(esquemaNotas, req.body);
  await transaccion(async (cl) => {
    for (const n of notas) {
      const r = await cl.query(
        "UPDATE inscripciones SET nota_final = $3 WHERE id_inscripcion = $1 AND id_capacitacion = $2 AND estado <> 'Anulada'",
        [n.id_inscripcion, id, n.nota === null ? null : Math.round(n.nota * 100) / 100],
      );
      if (r.rowCount === 0) throw new ErrorApp(400, `La inscripción ${n.id_inscripcion} no pertenece a esta capacitación.`);
    }
  });
  res.json({ actualizadas: notas.length });
});

// HU-04 · Cerrar acta: calcula Aprobado/Desaprobado y bloquea cambios.
rutasEvaluacion.post('/capacitaciones/:id/acta/cerrar', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  exigirActaAbierta(c);
  const filas = await consulta<{ id_inscripcion: number; nota_final: number | null; asistidas: number; participante: string }>(
    `SELECT x.id_inscripcion, x.nota_final, u.nombres || ' ' || u.apellidos AS participante,
            (SELECT count(*)::int FROM asistencias a WHERE a.id_inscripcion = x.id_inscripcion AND a.estado <> 'Falta') AS asistidas
       FROM inscripciones x JOIN usuarios u ON u.id_usuario = x.id_participante
      WHERE x.id_capacitacion = $1 AND x.estado <> 'Anulada'`,
    [id],
  );
  if (filas.length === 0) throw new ErrorApp(409, 'No hay inscritos: no se puede cerrar un acta vacía.');
  const sinNota = filas.filter((f) => f.nota_final === null);
  if (sinNota.length > 0) {
    throw new ErrorApp(409, `Faltan ${sinNota.length} nota(s) para cerrar el acta.`, { pendientes: sinNota.map((f) => f.participante) });
  }
  const resumen = { aprobados: 0, desaprobados: 0 };
  await transaccion(async (cl) => {
    for (const f of filas) {
      const cond = condicionFinal(f.nota_final as number, f.asistidas, c.numero_sesiones, c.asistencia_minima);
      resumen[cond === 'Aprobado' ? 'aprobados' : 'desaprobados']++;
      await cl.query('UPDATE inscripciones SET estado = $2 WHERE id_inscripcion = $1', [f.id_inscripcion, cond]);
    }
    await cl.query("UPDATE capacitaciones SET acta_cerrada = TRUE, estado = 'Finalizada' WHERE id_capacitacion = $1", [id]);
  });
  res.json({ ...resumen, total: filas.length });
});

// Emisión masiva de certificados para los aprobados.
rutasEvaluacion.post('/capacitaciones/:id/certificados', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  const id = idParam(req);
  const c = await autorizarCapacitacion(req, id, 'aula');
  if (!c.acta_cerrada) throw new ErrorApp(409, 'Cierra el acta antes de emitir certificados.');
  const aprobados = await consulta<{ id_inscripcion: number }>(
    "SELECT id_inscripcion FROM inscripciones WHERE id_capacitacion = $1 AND estado = 'Aprobado' ORDER BY id_inscripcion",
    [id],
  );
  const inicio = performance.now();
  let emitidos = 0;
  // Se procesan en grupos de 8 para solapar consultas, QR y escritura de archivos (RNF-02).
  for (let i = 0; i < aprobados.length; i += 8) {
    const grupo = await Promise.all(aprobados.slice(i, i + 8).map((a) => emitirCertificado(a.id_inscripcion)));
    emitidos += grupo.filter((r) => r.nuevo).length;
  }
  res.json({ emitidos, ya_existian: aprobados.length - emitidos, milisegundos: Math.round(performance.now() - inicio) });
});

// HU-05 · El participante descarga su certificado (se emite al pedirlo si aún no existe).
rutasEvaluacion.get('/inscripciones/:id/certificado', requiere('Participante'), async (req, res) => {
  const idIns = idParam(req);
  const [x] = await consulta<{ estado: string; acta_cerrada: boolean }>(
    `SELECT x.estado, c.acta_cerrada FROM inscripciones x JOIN capacitaciones c USING (id_capacitacion)
      WHERE x.id_inscripcion = $1 AND x.id_participante = $2`,
    [idIns, sesionDe(req).id],
  );
  if (!x) throw new ErrorApp(404, 'No encontramos esa inscripción en tu cuenta.');
  if (!x.acta_cerrada) throw new ErrorApp(409, 'El certificado estará disponible cuando el docente cierre el acta.');
  if (x.estado !== 'Aprobado') {
    throw new ErrorApp(403, 'No cumples los requisitos del certificado: nota mínima 11 y la asistencia mínima del curso.');
  }
  const { certificado } = await emitirCertificado(idIns);
  res.type('application/pdf')
    .setHeader('Content-Disposition', `attachment; filename="${certificado.codigo_unico}.pdf"`)
    .send(await leerPdf(certificado));
});

// Descarga para gestión (docente, coordinador, admin)
rutasEvaluacion.get('/capacitaciones/:id/certificados/:idInscripcion/pdf', requiere('Admin', 'Coordinador', 'Docente'), async (req, res) => {
  await autorizarCapacitacion(req, idParam(req), 'aula');
  const k = await certificadoDe(idParam(req, 'idInscripcion'));
  if (!k) throw new ErrorApp(404, 'Ese certificado aún no se emite.');
  res.type('application/pdf').setHeader('Content-Disposition', `attachment; filename="${k.codigo_unico}.pdf"`).send(await leerPdf(k));
});

// HU-08 · Verificación pública
rutasEvaluacion.get('/verificar/:codigo', async (req, res) => {
  const { hash_pdf: _omitido, ...publico } = await verificarCertificado(String(req.params.codigo));
  res.json(publico);
});

rutasEvaluacion.post('/verificar/:codigo/archivo', async (req, res) => {
  const { sha256 } = validar(z.object({ sha256: z.string().regex(/^[a-f0-9]{64}$/i, 'Huella SHA-256 inválida.') }), req.body);
  const v = await verificarCertificado(String(req.params.codigo));
  res.json({ coincide: v.hash_pdf === sha256.toLowerCase(), integro: v.integro });
});

