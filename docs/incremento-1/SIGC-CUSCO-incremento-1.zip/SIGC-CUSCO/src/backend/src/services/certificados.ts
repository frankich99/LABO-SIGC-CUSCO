import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { config } from '../config.js';
import { consulta } from '../db/pool.js';
import { ErrorApp } from '../domain/errores.js';
import { huellaCertificado, nuevoCodigoCertificado, sha256, type DatosCertificado } from '../domain/firma.js';
import { pdfCertificado } from './pdf.js';

interface FilaParaCertificado {
  id_inscripcion: number;
  estado: string;
  nota_final: number | null;
  dni: string;
  participante: string;
  capacitacion: string;
  institucion: string;
  horas: number;
}

export interface Certificado {
  id_certificado: number;
  id_inscripcion: number;
  codigo_unico: string;
  hash_sha256: string;
  hash_pdf: string;
  fecha_emision: string;
  url_pdf: string;
}

const carpeta = () => path.join(config.storageDir, 'certificados');

async function datosInscripcion(idInscripcion: number): Promise<FilaParaCertificado> {
  const [f] = await consulta<FilaParaCertificado>(
    `SELECT x.id_inscripcion, x.estado, x.nota_final, u.dni, u.nombres || ' ' || u.apellidos AS participante,
            c.titulo AS capacitacion, i.razon_social AS institucion, c.horas_academicas AS horas
       FROM inscripciones x
       JOIN usuarios u ON u.id_usuario = x.id_participante
       JOIN capacitaciones c USING (id_capacitacion)
       JOIN instituciones i ON i.id_institucion = c.id_institucion
      WHERE x.id_inscripcion = $1`,
    [idInscripcion],
  );
  if (!f) throw new ErrorApp(404, 'La inscripción no existe.');
  return f;
}

export async function certificadoDe(idInscripcion: number): Promise<Certificado | undefined> {
  const [k] = await consulta<Certificado>('SELECT * FROM certificados WHERE id_inscripcion = $1', [idInscripcion]);
  return k;
}

/** HU-05 · Emite (una sola vez) el certificado PDF de una inscripción aprobada. */
export async function emitirCertificado(idInscripcion: number): Promise<{ certificado: Certificado; nuevo: boolean }> {
  const existente = await certificadoDe(idInscripcion);
  if (existente) return { certificado: existente, nuevo: false };

  const f = await datosInscripcion(idInscripcion);
  if (f.estado !== 'Aprobado' || f.nota_final === null) {
    throw new ErrorApp(403, 'No cumples los requisitos para el certificado: se necesita la condición de aprobado con el acta cerrada.');
  }
  const fechaEmision = new Date().toISOString();
  const codigo = nuevoCodigoCertificado(new Date().getFullYear());
  const datos: DatosCertificado = {
    codigo, dni: f.dni, participante: f.participante, capacitacion: f.capacitacion,
    institucion: f.institucion, horas: f.horas, nota: f.nota_final, fechaEmision,
  };
  const huella = huellaCertificado(datos);
  const pdf = await pdfCertificado(datos, huella, `${config.publicUrl}/verificar/${codigo}`);

  await mkdir(carpeta(), { recursive: true });
  const archivo = `${codigo}.pdf`;
  await writeFile(path.join(carpeta(), archivo), pdf);

  const filas = await consulta<Certificado>(
    `INSERT INTO certificados (id_inscripcion, codigo_unico, hash_sha256, hash_pdf, fecha_emision, url_pdf)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (id_inscripcion) DO NOTHING RETURNING *`,
    [idInscripcion, codigo, huella, sha256(pdf), fechaEmision, `certificados/${archivo}`],
  );
  if (filas.length === 0) {
    // Otra petición lo emitió al mismo tiempo: se devuelve el que quedó registrado.
    const ganador = await certificadoDe(idInscripcion);
    if (!ganador) throw new ErrorApp(500, 'No se pudo registrar el certificado.');
    return { certificado: ganador, nuevo: false };
  }
  return { certificado: filas[0], nuevo: true };
}

export async function leerPdf(k: Certificado): Promise<Buffer> {
  return readFile(path.join(config.storageDir, k.url_pdf));
}

export interface ResultadoVerificacion {
  codigo: string;
  integro: boolean;
  participante: string;
  dni_parcial: string;
  capacitacion: string;
  institucion: string;
  horas: number;
  nota: number;
  fecha_emision: string;
  hash_sha256: string;
}

/** HU-08 · Recalcula la huella con los datos vigentes y la compara con la registrada al emitir. */
export async function verificarCertificado(codigo: string): Promise<ResultadoVerificacion & { hash_pdf: string }> {
  const [k] = await consulta<Certificado>('SELECT * FROM certificados WHERE codigo_unico = $1', [codigo.trim().toUpperCase()]);
  if (!k) throw new ErrorApp(404, 'No existe un certificado con ese código.');
  const f = await datosInscripcion(k.id_inscripcion);
  const fecha = new Date(k.fecha_emision).toISOString();
  const recalculada = huellaCertificado({
    codigo: k.codigo_unico, dni: f.dni, participante: f.participante, capacitacion: f.capacitacion,
    institucion: f.institucion, horas: f.horas, nota: f.nota_final ?? -1, fechaEmision: fecha,
  });
  return {
    codigo: k.codigo_unico,
    integro: recalculada === k.hash_sha256 && f.estado === 'Aprobado',
    participante: f.participante,
    dni_parcial: `****${f.dni.slice(4)}`,
    capacitacion: f.capacitacion,
    institucion: f.institucion,
    horas: f.horas,
    nota: f.nota_final ?? 0,
    fecha_emision: fecha,
    hash_sha256: k.hash_sha256,
    hash_pdf: k.hash_pdf,
  };
}
