import nodemailer from 'nodemailer';
import { config } from '../config.js';
import { consulta } from '../db/pool.js';

const transporte = config.smtp.host
  ? nodemailer.createTransport({
      host: config.smtp.host,
      port: config.smtp.port,
      auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.pass } : undefined,
    })
  : null;

/**
 * Envía un correo y deja constancia en la tabla notificaciones.
 * Sin SMTP configurado, el mensaje queda registrado como "Simulado".
 * Nunca interrumpe la operación que lo origina.
 */
export async function enviarCorreo(destinatario: string, asunto: string, cuerpo: string): Promise<void> {
  let estado: 'Enviado' | 'Simulado' | 'Error' = 'Simulado';
  let detalle: string | null = null;
  if (transporte) {
    try {
      await transporte.sendMail({ from: config.smtp.from, to: destinatario, subject: asunto, text: cuerpo });
      estado = 'Enviado';
    } catch (e) {
      estado = 'Error';
      detalle = e instanceof Error ? e.message : String(e);
    }
  }
  await consulta(
    'INSERT INTO notificaciones (destinatario, asunto, cuerpo, estado, detalle) VALUES ($1, $2, $3, $4, $5)',
    [destinatario, asunto, cuerpo, estado, detalle],
  );
}
