import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';
import type { DatosCertificado } from '../domain/firma.js';

const CARMIN = '#9E1B3B';
const TINTA = '#1E2A2F';
const GRIS = '#5B6770';

function aBuffer(doc: PDFKit.PDFDocument): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const partes: Buffer[] = [];
    doc.on('data', (p: Buffer) => partes.push(p));
    doc.on('end', () => resolve(Buffer.concat(partes)));
    doc.on('error', reject);
    doc.end();
  });
}

function fechaLarga(iso: string): string {
  return new Date(iso).toLocaleDateString('es-PE', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'America/Lima' });
}

/** Certificado A4 horizontal con QR de verificación pública y huella SHA-256. */
export async function pdfCertificado(d: DatosCertificado, huella: string, urlVerificacion: string): Promise<Buffer> {
  const doc = new PDFDocument({
    size: 'A4',
    layout: 'landscape',
    margin: 48,
    info: { Title: `Certificado ${d.codigo}`, Author: d.institucion, Subject: d.capacitacion, CreationDate: new Date(d.fechaEmision) },
  });
  const ancho = doc.page.width;
  const alto = doc.page.height;

  // Franja escalonada superior (motivo de la identidad visual)
  for (let i = 0; i < 28; i++) {
    doc.rect(i * (ancho / 28), 0, ancho / 28 - 2, i % 2 === 0 ? 14 : 8).fill(CARMIN);
  }
  doc.rect(28, 34, ancho - 56, alto - 62).lineWidth(1).stroke('#C9CED1');

  doc.fillColor(GRIS).font('Helvetica').fontSize(12).text(d.institucion, 64, 64);
  doc.fillColor(TINTA).font('Helvetica-Bold').fontSize(34).text('Certificado de capacitación', 64, 96);
  doc.font('Helvetica').fontSize(13).fillColor(GRIS).text('Se otorga el presente certificado a', 64, 160);
  doc.font('Helvetica-Bold').fontSize(28).fillColor(TINTA).text(d.participante, 64, 182, { width: ancho - 330 });
  doc.font('Helvetica').fontSize(12).fillColor(GRIS).text(`DNI ${d.dni}`, 64, doc.y + 4);

  doc.moveDown(1.2);
  doc.font('Helvetica').fontSize(13).fillColor(TINTA).text('por haber aprobado la capacitación', 64, doc.y, { continued: false });
  doc.font('Helvetica-Bold').fontSize(18).fillColor(CARMIN).text(d.capacitacion, 64, doc.y + 4, { width: ancho - 330 });
  doc.font('Helvetica').fontSize(13).fillColor(TINTA)
    .text(`con una duración de ${d.horas} horas académicas y nota final de ${d.nota.toFixed(2)} (escala vigesimal).`, 64, doc.y + 8, { width: ancho - 330 });

  doc.fontSize(12).fillColor(GRIS).text(`Cusco, ${fechaLarga(d.fechaEmision)}`, 64, alto - 150);

  // QR y datos de verificación
  const qr = await QRCode.toBuffer(urlVerificacion, { margin: 1, width: 360, errorCorrectionLevel: 'M' });
  const xQr = ancho - 236;
  doc.image(qr, xQr, 92, { width: 170 });
  doc.font('Helvetica-Bold').fontSize(11).fillColor(TINTA).text(d.codigo, xQr - 10, 272, { width: 190, align: 'center' });
  doc.font('Helvetica').fontSize(9).fillColor(GRIS)
    .text('Escanea el QR o ingresa este código en el portal de verificación de SIGC-CUSCO.', xQr - 10, 290, { width: 190, align: 'center' });

  doc.font('Helvetica').fontSize(8).fillColor(GRIS).text(`Huella SHA-256: ${huella}`, 64, alto - 92, { width: ancho - 128 });
  doc.text(`Verificación: ${urlVerificacion}`, 64, alto - 78, { width: ancho - 128 });

  return aBuffer(doc);
}

export interface FilaPadron {
  dni: string;
  participante: string;
  asistidas: number;
  porcentaje: number;
  nota: number | null;
  estado: string;
}

/** Padrón de participantes para auditoría (A4 vertical). */
export async function pdfPadron(titulo: string, institucion: string, sesiones: number, filas: FilaPadron[]): Promise<Buffer> {
  const doc = new PDFDocument({ size: 'A4', margin: 40, info: { Title: `Padrón · ${titulo}` } });
  doc.font('Helvetica').fontSize(10).fillColor(GRIS).text(institucion);
  doc.font('Helvetica-Bold').fontSize(16).fillColor(TINTA).text(`Padrón de participantes: ${titulo}`);
  doc.font('Helvetica').fontSize(9).fillColor(GRIS)
    .text(`Sesiones programadas: ${sesiones} · Generado: ${new Date().toLocaleString('es-PE', { timeZone: 'America/Lima' })}`);
  doc.moveDown();

  const cols = [
    { t: 'N.º', w: 28 }, { t: 'DNI', w: 64 }, { t: 'Participante', w: 190 },
    { t: 'Asist.', w: 50 }, { t: '%', w: 44 }, { t: 'Nota', w: 44 }, { t: 'Condición', w: 95 },
  ];
  const fila = (valores: string[], negrita: boolean) => {
    const y = doc.y;
    let x = 40;
    doc.font(negrita ? 'Helvetica-Bold' : 'Helvetica').fontSize(9).fillColor(TINTA);
    valores.forEach((v, i) => {
      doc.text(v, x + 2, y, { width: cols[i].w - 4, lineBreak: false, ellipsis: true });
      x += cols[i].w;
    });
    doc.moveTo(40, y + 14).lineTo(x, y + 14).lineWidth(0.5).stroke('#D5D9DC');
    doc.y = y + 18;
  };
  fila(cols.map((c) => c.t), true);
  filas.forEach((f, i) => {
    if (doc.y > doc.page.height - 60) doc.addPage();
    fila([String(i + 1), f.dni, f.participante, `${f.asistidas}/${sesiones}`, `${f.porcentaje}`, f.nota === null ? '—' : f.nota.toFixed(2), f.estado], false);
  });
  if (filas.length === 0) doc.font('Helvetica').text('Sin participantes inscritos.');
  return aBuffer(doc);
}
