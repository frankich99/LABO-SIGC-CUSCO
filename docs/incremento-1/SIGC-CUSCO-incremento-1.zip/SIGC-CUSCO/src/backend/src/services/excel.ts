import ExcelJS from 'exceljs';
import type { FilaPadron } from './pdf.js';

export interface DetalleAsistencia { dni: string; participante: string; sesion: number; fechaHora: string; estado: string; metodo: string }

/** Libro Excel con padrón y detalle de asistencia, para auditoría (OSCE/OCI). */
export async function excelReporte(titulo: string, institucion: string, sesiones: number, padron: FilaPadron[], detalle: DetalleAsistencia[]): Promise<Buffer> {
  const libro = new ExcelJS.Workbook();
  libro.creator = 'SIGC-CUSCO';
  libro.created = new Date();

  const h1 = libro.addWorksheet('Padrón');
  h1.addRow([institucion]);
  h1.addRow([`Capacitación: ${titulo}`]);
  h1.addRow([`Sesiones programadas: ${sesiones}`]);
  h1.addRow([]);
  const cab = h1.addRow(['N.º', 'DNI', 'Participante', 'Sesiones asistidas', '% asistencia', 'Nota final', 'Condición']);
  cab.font = { bold: true };
  padron.forEach((f, i) => h1.addRow([i + 1, f.dni, f.participante, f.asistidas, f.porcentaje, f.nota, f.estado]));
  h1.columns.forEach((c, i) => { c.width = [6, 12, 36, 18, 14, 11, 14][i]; });
  h1.getRow(1).font = { bold: true, size: 13 };

  const h2 = libro.addWorksheet('Asistencia');
  const cab2 = h2.addRow(['DNI', 'Participante', 'Sesión', 'Fecha y hora', 'Estado', 'Método']);
  cab2.font = { bold: true };
  detalle.forEach((d) => h2.addRow([d.dni, d.participante, d.sesion, d.fechaHora, d.estado, d.metodo]));
  h2.columns.forEach((c, i) => { c.width = [12, 36, 9, 22, 11, 15][i]; });

  return Buffer.from(await libro.xlsx.writeBuffer());
}
