import { crearApp } from './app.js';
import { config } from './config.js';
import { aplicarEsquema } from './db/esquema.js';

await aplicarEsquema();
crearApp().listen(config.puerto, () => {
  console.log(`SIGC-CUSCO API escuchando en http://localhost:${config.puerto}`);
});
