import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { consulta } from '../db/pool.js';
import { ErrorApp } from '../domain/errores.js';

export type Rol = 'Admin' | 'Coordinador' | 'Docente' | 'Participante';

export interface Sesion {
  id: number;
  rol: Rol;
  nombre: string;
  institucion: number | null;
}

declare module 'express-serve-static-core' {
  interface Request {
    usuario?: Sesion;
  }
}

export function emitirToken(s: Sesion): string {
  return jwt.sign(s, config.jwtSecret, { expiresIn: '8h' });
}

/**
 * Lee el token si existe; no exige sesión.
 * El rol y la institución se leen de la base en cada petición, de modo que
 * un cambio de rol hecho por el administrador rige de inmediato (HU-10).
 */
export async function leerSesion(req: Request, _res: Response, next: NextFunction): Promise<void> {
  const cab = req.headers.authorization;
  if (cab?.startsWith('Bearer ')) {
    let d: Sesion | null;
    try {
      d = jwt.verify(cab.slice(7), config.jwtSecret) as Sesion;
    } catch {
      d = null; // token vencido o alterado: se trata como visitante
    }
    if (d) {
      const [u] = await consulta<{ rol: Rol; id_institucion: number | null; nombres: string; apellidos: string; activo: boolean }>(
        'SELECT rol, id_institucion, nombres, apellidos, activo FROM usuarios WHERE id_usuario = $1',
        [d.id],
      );
      if (u?.activo) req.usuario = { id: d.id, rol: u.rol, nombre: `${u.nombres} ${u.apellidos}`, institucion: u.id_institucion };
    }
  }
  next();
}

/** Exige sesión iniciada y, si se indican, uno de los roles permitidos (RBAC). */
export function requiere(...roles: Rol[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.usuario) return next(new ErrorApp(401, 'Inicia sesión para continuar.'));
    if (roles.length > 0 && !roles.includes(req.usuario.rol)) {
      return next(new ErrorApp(403, 'Tu rol no tiene permiso para esta acción.'));
    }
    next();
  };
}

export function sesionDe(req: Request): Sesion {
  if (!req.usuario) throw new ErrorApp(401, 'Inicia sesión para continuar.');
  return req.usuario;
}
