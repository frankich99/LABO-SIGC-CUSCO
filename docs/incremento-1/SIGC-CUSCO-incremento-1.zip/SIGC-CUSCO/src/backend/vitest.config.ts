import { tmpdir } from 'node:os';
import path from 'node:path';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    fileParallelism: false,
    testTimeout: 20000,
    hookTimeout: 30000,
    env: {
      NODE_ENV: 'test',
      DATABASE_URL: process.env.TEST_DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/sigc_test',
      JWT_SECRET: 'secreto-de-pruebas',
      QR_SECRET: 'secreto-qr-de-pruebas',
      BCRYPT_COST: '4',
      STORAGE_DIR: path.join(tmpdir(), 'sigc-pruebas'),
      PUBLIC_URL: 'http://sigc.test',
    },
    coverage: { provider: 'v8', include: ['src/**/*.ts'], exclude: ['src/server.ts', 'src/db/seed.ts', 'src/db/migrate.ts'], reporter: ['text', 'json-summary'] },
  },
});
