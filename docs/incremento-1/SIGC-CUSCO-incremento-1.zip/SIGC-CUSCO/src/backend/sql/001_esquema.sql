-- SIGC-CUSCO · Esquema físico PostgreSQL 16
-- Basado en el DDL de la especificación v2 (docs/v2/v2.tex), con ajustes del Incremento 1:
--   * usuarios.id_institucion para el aislamiento multientidad del Coordinador
--   * capacitaciones: descripción, modalidad, lugar, sesiones, asistencia mínima y cierre de acta
--   * certificados.hash_pdf para verificar el archivo descargado
--   * notificaciones como bandeja de salida de correos

CREATE TABLE IF NOT EXISTS instituciones (
    id_institucion SERIAL PRIMARY KEY,
    ruc VARCHAR(11) UNIQUE NOT NULL CHECK (ruc ~ '^(10|15|17|20)[0-9]{9}$'),
    razon_social VARCHAR(150) NOT NULL,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('Publica', 'Privada')),
    logo_url TEXT,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario SERIAL PRIMARY KEY,
    dni VARCHAR(8) UNIQUE NOT NULL CHECK (dni ~ '^[0-9]{8}$'),
    nombres VARCHAR(80) NOT NULL,
    apellidos VARCHAR(80) NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol VARCHAR(20) NOT NULL CHECK (rol IN ('Admin', 'Coordinador', 'Docente', 'Participante')),
    id_institucion INT REFERENCES instituciones(id_institucion) ON DELETE RESTRICT,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS capacitaciones (
    id_capacitacion SERIAL PRIMARY KEY,
    id_institucion INT NOT NULL REFERENCES instituciones(id_institucion) ON DELETE RESTRICT,
    id_docente INT REFERENCES usuarios(id_usuario) ON DELETE SET NULL,
    titulo VARCHAR(150) NOT NULL,
    descripcion TEXT NOT NULL DEFAULT '',
    modalidad VARCHAR(15) NOT NULL DEFAULT 'Presencial' CHECK (modalidad IN ('Presencial', 'Virtual', 'Mixta')),
    lugar VARCHAR(150) NOT NULL DEFAULT '',
    horas_academicas INT NOT NULL CHECK (horas_academicas > 0),
    vacantes_max INT NOT NULL CHECK (vacantes_max > 0),
    numero_sesiones INT NOT NULL DEFAULT 1 CHECK (numero_sesiones > 0),
    asistencia_minima INT NOT NULL DEFAULT 75 CHECK (asistencia_minima BETWEEN 0 AND 100),
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE,
    estado VARCHAR(20) NOT NULL DEFAULT 'Abierta'
        CHECK (estado IN ('Planificada', 'Abierta', 'En_Curso', 'Finalizada')),
    acta_cerrada BOOLEAN NOT NULL DEFAULT FALSE,
    creado_en TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_fechas CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio)
);

CREATE TABLE IF NOT EXISTS inscripciones (
    id_inscripcion SERIAL PRIMARY KEY,
    id_capacitacion INT NOT NULL REFERENCES capacitaciones(id_capacitacion) ON DELETE CASCADE,
    id_participante INT NOT NULL REFERENCES usuarios(id_usuario) ON DELETE RESTRICT,
    fecha_registro TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    nota_final NUMERIC(4,2) CHECK (nota_final >= 0 AND nota_final <= 20),
    estado VARCHAR(20) NOT NULL DEFAULT 'Confirmada'
        CHECK (estado IN ('Confirmada', 'Aprobado', 'Desaprobado', 'Anulada')),
    CONSTRAINT uq_participante_curso UNIQUE (id_capacitacion, id_participante)
);

CREATE TABLE IF NOT EXISTS asistencias (
    id_asistencia SERIAL PRIMARY KEY,
    id_inscripcion INT NOT NULL REFERENCES inscripciones(id_inscripcion) ON DELETE CASCADE,
    numero_sesion INT NOT NULL CHECK (numero_sesion > 0),
    fecha_hora TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(15) NOT NULL DEFAULT 'Presente' CHECK (estado IN ('Presente', 'Tardanza', 'Falta')),
    metodo VARCHAR(15) NOT NULL DEFAULT 'QR_Digital'
        CHECK (metodo IN ('QR_Digital', 'PIN_Manual', 'Offline_Sync')),
    CONSTRAINT uq_asistencia_sesion UNIQUE (id_inscripcion, numero_sesion)
);

CREATE TABLE IF NOT EXISTS certificados (
    id_certificado SERIAL PRIMARY KEY,
    id_inscripcion INT UNIQUE NOT NULL REFERENCES inscripciones(id_inscripcion) ON DELETE RESTRICT,
    codigo_unico VARCHAR(32) UNIQUE NOT NULL,
    hash_sha256 CHAR(64) NOT NULL,
    hash_pdf CHAR(64) NOT NULL,
    fecha_emision TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    url_pdf TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notificaciones (
    id_notificacion SERIAL PRIMARY KEY,
    destinatario VARCHAR(100) NOT NULL,
    asunto VARCHAR(200) NOT NULL,
    cuerpo TEXT NOT NULL,
    estado VARCHAR(12) NOT NULL CHECK (estado IN ('Enviado', 'Simulado', 'Error')),
    detalle TEXT,
    creado_en TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_usuarios_dni ON usuarios(dni);
CREATE INDEX IF NOT EXISTS idx_inscripciones_curso ON inscripciones(id_capacitacion);
CREATE INDEX IF NOT EXISTS idx_certificados_hash ON certificados(hash_sha256);
CREATE INDEX IF NOT EXISTS idx_certificados_codigo ON certificados(codigo_unico);
CREATE INDEX IF NOT EXISTS idx_capacitaciones_institucion ON capacitaciones(id_institucion);
