import { describe, expect, it } from 'vitest';
import { disponibles, hayCupo } from '../src/domain/cupos.js';
import { validarDni } from '../src/domain/dni.js';
import { condicionFinal, porcentajeAsistencia, validarNota } from '../src/domain/evaluacion.js';
import {
  codigoCredencial, firmarSesion, huellaCertificado, leerCredencial, nuevoCodigoCertificado, verificarSesion,
  type DatosCertificado,
} from '../src/domain/firma.js';

// Las pruebas de esta sección se escribieron antes que el código (TDD: rojo → verde → refactorizar).

describe('cupos disponibles = capacidad − inscritos', () => {
  it('queda una vacante cuando hay 29 de 30', () => expect(disponibles(30, 29)).toBe(1));
  it('no quedan vacantes cuando hay 30 de 30', () => expect(disponibles(30, 30)).toBe(0));
  it('nunca devuelve un número negativo (caso límite: sobreinscripción histórica)', () => expect(disponibles(30, 31)).toBe(0));
  it('hayCupo es falso con el curso lleno', () => {
    expect(hayCupo(1, 0)).toBe(true);
    expect(hayCupo(1, 1)).toBe(false);
  });
  it('rechaza capacidades no válidas', () => {
    expect(() => disponibles(0, 0)).toThrow(RangeError);
    expect(() => disponibles(10, -1)).toThrow(RangeError);
    expect(() => disponibles(2.5, 0)).toThrow(RangeError);
  });
});

describe('validación de DNI', () => {
  it('acepta 8 dígitos', () => expect(validarDni('70123450')).toEqual({ valido: true }));
  it('acepta espacios alrededor', () => expect(validarDni(' 70123450 ').valido).toBe(true));
  it.each([
    ['7012345', 'exactamente 8'],
    ['701234501', 'exactamente 8'],
    ['7012345A', 'solo puede contener números'],
    ['11111111', 'todos los dígitos iguales'],
    ['', 'solo puede contener números'],
  ])('rechaza %s', (dni, motivo) => {
    const r = validarDni(dni);
    expect(r.valido).toBe(false);
    if (!r.valido) expect(r.motivo).toContain(motivo);
  });
  it('rechaza valores que no son texto', () => expect(validarDni(70123450).valido).toBe(false));
});

describe('evaluación y condición final', () => {
  it('11 es la nota mínima aprobatoria', () => {
    expect(condicionFinal(11, 4, 4, 75)).toBe('Aprobado');
    expect(condicionFinal(10.99, 4, 4, 75)).toBe('Desaprobado');
  });
  it('desaprueba con buena nota si no cumple la asistencia mínima', () => {
    expect(condicionFinal(18, 2, 4, 75)).toBe('Desaprobado');
    expect(condicionFinal(18, 3, 4, 75)).toBe('Aprobado');
  });
  it('calcula el porcentaje de asistencia', () => {
    expect(porcentajeAsistencia(3, 4)).toBe(75);
    expect(porcentajeAsistencia(2, 3)).toBe(66.7);
    expect(porcentajeAsistencia(9, 4)).toBe(100);
  });
  it('valida la escala vigesimal', () => {
    expect(validarNota(0)).toBe(true);
    expect(validarNota(20)).toBe(true);
    expect(validarNota(20.5)).toBe(false);
    expect(validarNota(Number.NaN)).toBe(false);
    expect(() => condicionFinal(21, 4, 4, 75)).toThrow(RangeError);
    expect(() => porcentajeAsistencia(1, 0)).toThrow(RangeError);
  });
});

describe('firmas: QR de sesión, credencial y huella del certificado', () => {
  const secreto = 'secreto';

  it('el QR de sesión se lee mientras está vigente', () => {
    const t = firmarSesion(secreto, 7, 2, 10_000);
    expect(verificarSesion(secreto, t, 9_000)).toEqual({ ok: true, datos: { idCapacitacion: 7, sesion: 2, expira: 10_000 } });
  });
  it('el QR de sesión vence', () => {
    const t = firmarSesion(secreto, 7, 2, 10_000);
    expect(verificarSesion(secreto, t, 10_001)).toEqual({ ok: false, motivo: 'expirado' });
  });
  it('un QR alterado o firmado con otro secreto no es válido', () => {
    const t = firmarSesion(secreto, 7, 2, 10_000);
    const [carga, firma] = t.split('.');
    const otraCarga = Buffer.from(JSON.stringify({ c: 8, s: 2, e: 10_000 })).toString('base64url');
    expect(verificarSesion(secreto, `${otraCarga}.${firma}`, 0).ok).toBe(false);
    expect(verificarSesion('otro', t, 0).ok).toBe(false);
    expect(verificarSesion(secreto, carga, 0).ok).toBe(false);
    expect(verificarSesion(secreto, 'basura.basura', 0).ok).toBe(false);
  });
  it('la credencial del participante identifica su inscripción y no se puede falsificar', () => {
    const c = codigoCredencial(secreto, 42);
    expect(leerCredencial(secreto, c)).toBe(42);
    expect(leerCredencial(secreto, c.replace('INS-42', 'INS-43'))).toBeNull();
    expect(leerCredencial(secreto, '70123450')).toBeNull();
  });
  it('el código de certificado tiene formato SIGC-AAAA-XXXXXXXXXX y es único', () => {
    const codigos = new Set(Array.from({ length: 200 }, () => nuevoCodigoCertificado(2026)));
    expect(codigos.size).toBe(200);
    for (const c of codigos) expect(c).toMatch(/^SIGC-2026-[A-HJ-NP-Z2-9]{10}$/);
  });
  it('la huella cambia si se altera cualquier dato del certificado', () => {
    const d: DatosCertificado = {
      codigo: 'SIGC-2026-ABCDEFGHJK', dni: '70123450', participante: 'Carmen Villca Sutta', capacitacion: 'Curso',
      institucion: 'Municipalidad', horas: 20, nota: 15, fechaEmision: '2026-10-06T15:00:00.000Z',
    };
    const h = huellaCertificado(d);
    expect(h).toMatch(/^[a-f0-9]{64}$/);
    expect(huellaCertificado({ ...d })).toBe(h);
    expect(huellaCertificado({ ...d, nota: 15.01 })).not.toBe(h);
    expect(huellaCertificado({ ...d, participante: 'Carmen Villca' })).not.toBe(h);
  });
});
