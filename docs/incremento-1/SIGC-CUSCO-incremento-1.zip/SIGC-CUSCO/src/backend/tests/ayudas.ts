import bcrypt from 'bcryptjs';
import request from 'supertest';
import { crearApp } from '../src/app.js';
import { aplicarEsquema, vaciarBase } from '../src/db/esquema.js';
import { consulta } from '../src/db/pool.js';

export const app = crearApp();
export const api = () => request(app);

export async function baseLimpia(): Promise<void> {
  await aplicarEsquema();
  await vaciarBase();
}

export async function crearInstitucion(ruc = '20100000011', nombre = 'Municipalidad Distrital de Wanchaq', tipo = 'Publica') {
  const [i] = await consulta<{ id_institucion: number }>(
    'INSERT INTO instituciones (ruc, razon_social, tipo) VALUES ($1,$2,$3) RETURNING id_institucion', [ruc, nombre, tipo]);
  return i.id_institucion;
}

let correlativo = 0;

/** Crea un usuario directo en la base y devuelve su id y un token de sesión. */
export async function crearUsuario(rol: string, dni: string, institucion: number | null = null, clave = 'Clave12345') {
  correlativo++;
  const [u] = await consulta<{ id_usuario: number }>(
    `INSERT INTO usuarios (dni, nombres, apellidos, correo, password_hash, rol, id_institucion)
     VALUES ($1, $2, 'Prueba', $3, $4, $5, $6) RETURNING id_usuario`,
    [dni, `${rol} ${correlativo}`, `u${correlativo}.${dni}@prueba.pe`, await bcrypt.hash(clave, 4), rol, institucion],
  );
  const r = await api().post('/api/auth/login').send({ usuario: dni, password: clave });
  return { id: u.id_usuario, token: r.body.token as string };
}

export const bearer = (token: string) => ({ Authorization: `Bearer ${token}` });

export function cursoValido(idInstitucion: number, extra: Record<string, unknown> = {}) {
  return {
    id_institucion: idInstitucion,
    titulo: 'Atención al turista y calidad de servicio',
    descripcion: 'Protocolos de recepción',
    modalidad: 'Presencial',
    lugar: 'Auditorio',
    horas_academicas: 16,
    vacantes_max: 25,
    numero_sesiones: 4,
    asistencia_minima: 75,
    fecha_inicio: '2026-10-26',
    fecha_fin: '2026-11-06',
    ...extra,
  };
}

export function nuevoParticipante(dni: string, extra: Record<string, unknown> = {}) {
  return { dni, nombres: 'Carmen', apellidos: 'Villca Sutta', correo: `p${dni}@correo.pe`, password: 'Cusco2026', ...extra };
}
