import { createHash } from 'node:crypto';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { consulta, pool } from '../src/db/pool.js';
import { api, baseLimpia, bearer, crearInstitucion, crearUsuario, cursoValido, nuevoParticipante } from './ayudas.js';

afterAll(async () => { await pool.end(); });

let muni: number;
let hotel: number;
let admin: { id: number; token: string };
let coord: { id: number; token: string };
let docente: { id: number; token: string };

beforeEach(async () => {
  await baseLimpia();
  muni = await crearInstitucion();
  hotel = await crearInstitucion('20600000022', 'Hotel Inti Wasi Cusco S.A.C.', 'Privada');
  admin = await crearUsuario('Admin', '40000001');
  coord = await crearUsuario('Coordinador', '40000002', muni);
  docente = await crearUsuario('Docente', '40000003');
});

async function crearCurso(extra: Record<string, unknown> = {}) {
  const r = await api().post('/api/capacitaciones').set(bearer(coord.token))
    .send(cursoValido(muni, { id_docente: docente.id, ...extra }));
  expect(r.status).toBe(201);
  return r.body.id_capacitacion as number;
}

async function inscribir(idCap: number, dni: string) {
  return api().post(`/api/capacitaciones/${idCap}/inscripciones`).send(nuevoParticipante(dni));
}

describe('HU-10 · autenticación y roles (RBAC)', () => {
  it('rechaza credenciales incorrectas y acepta las correctas', async () => {
    const mal = await api().post('/api/auth/login').send({ usuario: '40000001', password: 'otra' });
    expect(mal.status).toBe(401);
    const bien = await api().post('/api/auth/login').send({ usuario: '40000001', password: 'Clave12345' });
    expect(bien.status).toBe(200);
    expect(bien.body.usuario.rol).toBe('Admin');
  });

  it('un participante no puede crear capacitaciones ni ver usuarios', async () => {
    const p = await crearUsuario('Participante', '70123450');
    expect((await api().post('/api/capacitaciones').set(bearer(p.token)).send(cursoValido(muni))).status).toBe(403);
    expect((await api().get('/api/usuarios').set(bearer(p.token))).status).toBe(403);
    expect((await api().get('/api/usuarios')).status).toBe(401);
  });

  it('el cambio de rol rige de inmediato, sin volver a iniciar sesión', async () => {
    const u = await crearUsuario('Participante', '70123451');
    expect((await api().get('/api/capacitaciones/gestion').set(bearer(u.token))).status).toBe(403);
    const r = await api().patch(`/api/usuarios/${u.id}`).set(bearer(admin.token)).send({ rol: 'Docente' });
    expect(r.status).toBe(200);
    expect((await api().get('/api/capacitaciones/gestion').set(bearer(u.token))).status).toBe(200);
  });

  it('un coordinador necesita institución y el admin no puede quitarse su rol', async () => {
    const u = await crearUsuario('Participante', '70123452');
    expect((await api().patch(`/api/usuarios/${u.id}`).set(bearer(admin.token)).send({ rol: 'Coordinador' })).status).toBe(400);
    expect((await api().patch(`/api/usuarios/${admin.id}`).set(bearer(admin.token)).send({ rol: 'Docente' })).status).toBe(409);
  });

  it('el admin crea usuarios con DNI válido y sin duplicados', async () => {
    const datos = { dni: '40000009', nombres: 'Luis', apellidos: 'Paucar', correo: 'luis@demo.pe', password: 'Segura2026', rol: 'Docente' };
    expect((await api().post('/api/usuarios').set(bearer(admin.token)).send(datos)).status).toBe(201);
    expect((await api().post('/api/usuarios').set(bearer(admin.token)).send(datos)).status).toBe(409);
    const malDni = await api().post('/api/usuarios').set(bearer(admin.token)).send({ ...datos, dni: '123', correo: 'x@demo.pe' });
    expect(malDni.status).toBe(400);
    expect(malDni.body.detalles.dni).toContain('8 dígitos');
  });
});

describe('HU-07 · multientidad', () => {
  it('el admin registra instituciones con RUC válido y único', async () => {
    const ok = await api().post('/api/instituciones').set(bearer(admin.token))
      .send({ ruc: '20600000033', razon_social: 'Qosqo Andes Travel E.I.R.L.', tipo: 'Privada' });
    expect(ok.status).toBe(201);
    const dup = await api().post('/api/instituciones').set(bearer(admin.token))
      .send({ ruc: '20600000033', razon_social: 'Otra', tipo: 'Privada' });
    expect(dup.status).toBe(409);
    const mal = await api().post('/api/instituciones').set(bearer(admin.token)).send({ ruc: '123', razon_social: 'X', tipo: 'Otra' });
    expect(mal.status).toBe(400);
    expect(Object.keys(mal.body.detalles)).toEqual(expect.arrayContaining(['ruc', 'razon_social', 'tipo']));
  });

  it('un coordinador solo crea y ve cursos de su institución', async () => {
    const ajeno = await api().post('/api/capacitaciones').set(bearer(coord.token)).send(cursoValido(hotel));
    expect(ajeno.status).toBe(403);
    const idHotel = (await api().post('/api/capacitaciones').set(bearer(admin.token)).send(cursoValido(hotel))).body.id_capacitacion;
    await crearCurso();
    const lista = await api().get('/api/capacitaciones/gestion').set(bearer(coord.token));
    expect(lista.body).toHaveLength(1);
    expect((await api().put(`/api/capacitaciones/${idHotel}`).set(bearer(coord.token)).send(cursoValido(muni))).status).toBe(403);
  });
});

describe('HU-06 y HU-12 · capacitaciones y catálogo público', () => {
  it('bloquea el guardado con campos vacíos o con formato erróneo', async () => {
    const r = await api().post('/api/capacitaciones').set(bearer(coord.token))
      .send(cursoValido(muni, { titulo: '', vacantes_max: 0, fecha_inicio: '26/10/2026' }));
    expect(r.status).toBe(400);
    expect(r.body.detalles).toMatchObject({ titulo: expect.any(String), vacantes_max: expect.any(String), fecha_inicio: expect.any(String) });
    const fechas = await api().post('/api/capacitaciones').set(bearer(coord.token))
      .send(cursoValido(muni, { fecha_inicio: '2026-11-10', fecha_fin: '2026-11-01' }));
    expect(fechas.body.detalles.fecha_fin).toContain('anterior');
  });

  it('una capacitación válida queda "Abierta" y aparece en el catálogo con sus vacantes', async () => {
    const id = await crearCurso();
    const cat = await api().get('/api/capacitaciones');
    expect(cat.status).toBe(200);
    expect(cat.body).toHaveLength(1);
    expect(cat.body[0]).toMatchObject({ id_capacitacion: id, estado: 'Abierta', disponibles: 25, institucion: 'Municipalidad Distrital de Wanchaq' });
    expect((await api().get('/api/capacitaciones?q=turista')).body).toHaveLength(1);
    expect((await api().get('/api/capacitaciones?q=zzz')).body).toHaveLength(0);
    expect((await api().get(`/api/capacitaciones?institucion=${hotel}`)).body).toHaveLength(0);
  });

  it('no permite bajar las vacantes por debajo de los inscritos', async () => {
    const id = await crearCurso({ vacantes_max: 3 });
    await inscribir(id, '70123450');
    await inscribir(id, '70123451');
    const r = await api().put(`/api/capacitaciones/${id}`).set(bearer(coord.token)).send(cursoValido(muni, { vacantes_max: 1 }));
    expect(r.status).toBe(409);
  });
});

describe('HU-01 y HU-02 · inscripción con DNI', () => {
  it('inscribe con un DNI nuevo, crea la cuenta, descuenta el cupo y envía la confirmación', async () => {
    const id = await crearCurso();
    const r = await inscribir(id, '70123450');
    expect(r.status).toBe(201);
    expect(r.body).toMatchObject({ cuenta_nueva: true, disponibles: 24 });
    expect(r.body.credencial).toMatch(/^INS-\d+-/);
    const [n] = await consulta<{ asunto: string; estado: string }>('SELECT asunto, estado FROM notificaciones');
    expect(n).toMatchObject({ asunto: expect.stringContaining('Inscripción confirmada'), estado: 'Simulado' });
    expect((await api().get(`/api/capacitaciones/${id}`)).body.disponibles).toBe(24);
  });

  it('rechaza un DNI inválido y una segunda inscripción al mismo curso', async () => {
    const id = await crearCurso();
    const mal = await inscribir(id, '1234');
    expect(mal.status).toBe(400);
    expect(mal.body.detalles.dni).toBeDefined();
    await inscribir(id, '70123450');
    const otra = await api().post(`/api/capacitaciones/${id}/inscripciones`).send({ dni: '70123450', password: 'Cusco2026' });
    expect(otra.status).toBe(409);
    expect(otra.body.error).toContain('Ya estás inscrito');
  });

  it('un DNI con cuenta necesita su contraseña', async () => {
    const id1 = await crearCurso();
    const id2 = await crearCurso({ titulo: 'Primeros auxilios en eventos masivos' });
    await inscribir(id1, '70123450');
    expect((await api().post(`/api/capacitaciones/${id2}/inscripciones`).send({ dni: '70123450', password: 'mala' })).status).toBe(401);
    const ok = await api().post(`/api/capacitaciones/${id2}/inscripciones`).send({ dni: '70123450', password: 'Cusco2026' });
    expect(ok.status).toBe(201);
    expect(ok.body.cuenta_nueva).toBe(false);
  });

  it('rechaza la inscripción cuando no hay vacantes', async () => {
    const id = await crearCurso({ vacantes_max: 1 });
    expect((await inscribir(id, '70123450')).status).toBe(201);
    const llena = await inscribir(id, '70123451');
    expect(llena.status).toBe(409);
    expect(llena.body.error).toContain('No quedan vacantes');
  });

  it('con inscripciones simultáneas nunca se supera el cupo', async () => {
    const id = await crearCurso({ vacantes_max: 3 });
    const respuestas = await Promise.all(['70123450', '70123451', '70123452', '70123453', '70123454', '70123455'].map((d) => inscribir(id, d)));
    expect(respuestas.filter((r) => r.status === 201)).toHaveLength(3);
    expect(respuestas.filter((r) => r.status === 409)).toHaveLength(3);
    const [{ n }] = await consulta<{ n: number }>("SELECT count(*)::int AS n FROM inscripciones WHERE estado <> 'Anulada'");
    expect(n).toBe(3);
  });

  it('cancelar libera la vacante y se puede volver a inscribir', async () => {
    const id = await crearCurso({ vacantes_max: 1 });
    const r = await inscribir(id, '70123450');
    const tok = r.body.token as string;
    expect((await api().delete(`/api/inscripciones/${r.body.id_inscripcion}`).set(bearer(tok))).status).toBe(204);
    expect((await inscribir(id, '70123451')).status).toBe(201);
    const mias = await api().get('/api/mis-inscripciones').set(bearer(tok));
    expect(mias.body[0].estado).toBe('Anulada');
  });

  it('no inscribe en capacitaciones que no están abiertas', async () => {
    const id = await crearCurso();
    await api().patch(`/api/capacitaciones/${id}/estado`).set(bearer(coord.token)).send({ estado: 'En_Curso' });
    expect((await inscribir(id, '70123450')).status).toBe(409);
  });
});

describe('HU-03 y HU-11 · asistencia por QR, manual y sin conexión', () => {
  it('registra asistencia con el QR de la sesión e impide el doble registro', async () => {
    const id = await crearCurso();
    const p = await inscribir(id, '70123450');
    const qr = await api().post(`/api/capacitaciones/${id}/sesiones/1/qr`).set(bearer(docente.token));
    expect(qr.status).toBe(200);
    expect(qr.body.qr).toMatch(/^data:image\/png;base64,/);
    const marca = await api().post('/api/asistencias/qr').set(bearer(p.body.token)).send({ token: qr.body.token });
    expect(marca.status).toBe(201);
    const otra = await api().post('/api/asistencias/qr').set(bearer(p.body.token)).send({ token: qr.body.token });
    expect(otra.status).toBe(409);
    expect(otra.body.error).toContain('ya fue registrada');
    const [a] = await consulta<{ metodo: string }>('SELECT metodo FROM asistencias');
    expect(a.metodo).toBe('QR_Digital');
  });

  it('rechaza un QR alterado y a quien no está inscrito', async () => {
    const id = await crearCurso();
    const extraño = await crearUsuario('Participante', '70123459');
    const qr = await api().post(`/api/capacitaciones/${id}/sesiones/1/qr`).set(bearer(docente.token));
    expect((await api().post('/api/asistencias/qr').set(bearer(extraño.token)).send({ token: qr.body.token })).status).toBe(403);
    expect((await api().post('/api/asistencias/qr').set(bearer(extraño.token)).send({ token: `${qr.body.token}x` })).status).toBe(400);
  });

  it('solo el docente asignado genera QR y la sesión debe existir', async () => {
    const id = await crearCurso();
    const otro = await crearUsuario('Docente', '40000008');
    expect((await api().post(`/api/capacitaciones/${id}/sesiones/1/qr`).set(bearer(otro.token))).status).toBe(403);
    expect((await api().post(`/api/capacitaciones/${id}/sesiones/9/qr`).set(bearer(docente.token))).status).toBe(400);
  });

  it('el docente marca por DNI o por código de credencial', async () => {
    const id = await crearCurso();
    const p = await inscribir(id, '70123450');
    const porDni = await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: 1, identificador: '70123450' });
    expect(porDni.status).toBe(201);
    const porCodigo = await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: 2, identificador: p.body.credencial });
    expect(porCodigo.status).toBe(201);
    const nadie = await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: 1, identificador: '79999999' });
    expect(nadie.status).toBe(404);
  });

  it('sincroniza lo marcado sin conexión e informa duplicados y errores', async () => {
    const id = await crearCurso();
    await inscribir(id, '70123450');
    await inscribir(id, '70123451');
    const hora = '2026-10-05T09:05:00-05:00';
    const r = await api().post(`/api/capacitaciones/${id}/asistencias/sync`).set(bearer(docente.token)).send({
      registros: [
        { clave: 'a', sesion: 1, identificador: '70123450', fecha_hora: hora },
        { clave: 'b', sesion: 1, identificador: '70123450', fecha_hora: hora },
        { clave: 'c', sesion: 1, identificador: '70123451', estado: 'Tardanza', fecha_hora: hora },
        { clave: 'd', sesion: 1, identificador: '79999999', fecha_hora: hora },
        { clave: 'e', sesion: 7, identificador: '70123451', fecha_hora: hora },
      ],
    });
    expect(r.status).toBe(200);
    expect(r.body.resultados.map((x: { resultado: string }) => x.resultado)).toEqual(['registrado', 'duplicado', 'registrado', 'error', 'error']);
    const filas = await consulta<{ metodo: string; fecha_hora: Date }>('SELECT metodo, fecha_hora FROM asistencias ORDER BY 1');
    expect(filas.every((f) => f.metodo === 'Offline_Sync')).toBe(true);
    expect(new Date(filas[0].fecha_hora).toISOString()).toBe('2026-10-05T14:05:00.000Z');
  });
});

describe('HU-04, HU-05 y HU-08 · notas, acta, certificados y verificación pública', () => {
  async function cursoConActa() {
    const id = await crearCurso({ numero_sesiones: 4, asistencia_minima: 75 });
    const aprobado = await inscribir(id, '70123450');
    const bajaAsistencia = await inscribir(id, '70123451');
    const notaBaja = await inscribir(id, '70123452');
    for (let s = 1; s <= 4; s++) {
      await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: s, identificador: '70123450' });
      await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: s, identificador: '70123452' });
    }
    await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: 1, identificador: '70123451' });
    return { id, aprobado: aprobado.body, bajaAsistencia: bajaAsistencia.body, notaBaja: notaBaja.body };
  }

  it('valida la escala vigesimal y exige todas las notas para cerrar el acta', async () => {
    const { id, aprobado, bajaAsistencia } = await cursoConActa();
    const fuera = await api().put(`/api/capacitaciones/${id}/notas`).set(bearer(docente.token))
      .send({ notas: [{ id_inscripcion: aprobado.id_inscripcion, nota: 21 }] });
    expect(fuera.status).toBe(400);
    await api().put(`/api/capacitaciones/${id}/notas`).set(bearer(docente.token))
      .send({ notas: [{ id_inscripcion: aprobado.id_inscripcion, nota: 16 }, { id_inscripcion: bajaAsistencia.id_inscripcion, nota: 18 }] });
    const cierre = await api().post(`/api/capacitaciones/${id}/acta/cerrar`).set(bearer(docente.token));
    expect(cierre.status).toBe(409);
    expect(cierre.body.error).toContain('Faltan 1 nota');
  });

  it('al cerrar el acta aprueba con nota ≥ 11 y asistencia mínima, y luego bloquea cambios', async () => {
    const { id, aprobado, bajaAsistencia, notaBaja } = await cursoConActa();
    await api().put(`/api/capacitaciones/${id}/notas`).set(bearer(docente.token)).send({ notas: [
      { id_inscripcion: aprobado.id_inscripcion, nota: 16 },
      { id_inscripcion: bajaAsistencia.id_inscripcion, nota: 18 },
      { id_inscripcion: notaBaja.id_inscripcion, nota: 10.5 },
    ] });
    const cierre = await api().post(`/api/capacitaciones/${id}/acta/cerrar`).set(bearer(docente.token));
    expect(cierre.status).toBe(200);
    expect(cierre.body).toEqual({ aprobados: 1, desaprobados: 2, total: 3 });
    const estados = await consulta<{ dni: string; estado: string }>(
      'SELECT u.dni, x.estado FROM inscripciones x JOIN usuarios u ON u.id_usuario = x.id_participante ORDER BY u.dni');
    expect(estados.map((e) => e.estado)).toEqual(['Aprobado', 'Desaprobado', 'Desaprobado']);
    const tarde = await api().put(`/api/capacitaciones/${id}/notas`).set(bearer(docente.token))
      .send({ notas: [{ id_inscripcion: notaBaja.id_inscripcion, nota: 20 }] });
    expect(tarde.status).toBe(409);
    expect((await api().post(`/api/capacitaciones/${id}/asistencias`).set(bearer(docente.token)).send({ sesion: 2, identificador: '70123451' })).status).toBe(409);
  });

  it('entrega el PDF al aprobado, lo niega al desaprobado y lo verifica públicamente', async () => {
    const { id, aprobado, bajaAsistencia, notaBaja } = await cursoConActa();
    const sinActa = await api().get(`/api/inscripciones/${aprobado.id_inscripcion}/certificado`).set(bearer(aprobado.token));
    expect(sinActa.status).toBe(409);
    await api().put(`/api/capacitaciones/${id}/notas`).set(bearer(docente.token)).send({ notas: [
      { id_inscripcion: aprobado.id_inscripcion, nota: 15.5 },
      { id_inscripcion: bajaAsistencia.id_inscripcion, nota: 18 },
      { id_inscripcion: notaBaja.id_inscripcion, nota: 8 },
    ] });
    await api().post(`/api/capacitaciones/${id}/acta/cerrar`).set(bearer(docente.token));

    const negado = await api().get(`/api/inscripciones/${bajaAsistencia.id_inscripcion}/certificado`).set(bearer(bajaAsistencia.token));
    expect(negado.status).toBe(403);
    expect(negado.body.error).toContain('No cumples los requisitos');

    const pdf = await api().get(`/api/inscripciones/${aprobado.id_inscripcion}/certificado`).set(bearer(aprobado.token))
      .buffer(true).parse((res, cb) => { const p: Buffer[] = []; res.on('data', (c: Buffer) => p.push(c)); res.on('end', () => cb(null, Buffer.concat(p))); });
    expect(pdf.status).toBe(200);
    expect(pdf.headers['content-type']).toContain('application/pdf');
    const cuerpo = pdf.body as Buffer;
    expect(cuerpo.subarray(0, 4).toString()).toBe('%PDF');

    const [{ codigo_unico }] = await consulta<{ codigo_unico: string }>('SELECT codigo_unico FROM certificados');
    const v = await api().get(`/api/verificar/${codigo_unico.toLowerCase()}`);
    expect(v.status).toBe(200);
    expect(v.body).toMatchObject({ integro: true, nota: 15.5, horas: 16, dni_parcial: '****3450' });
    expect(v.body.hash_pdf).toBeUndefined();

    const huellaArchivo = createHash('sha256').update(cuerpo).digest('hex');
    expect((await api().post(`/api/verificar/${codigo_unico}/archivo`).send({ sha256: huellaArchivo })).body.coincide).toBe(true);
    expect((await api().post(`/api/verificar/${codigo_unico}/archivo`).send({ sha256: 'a'.repeat(64) })).body.coincide).toBe(false);

    // Una alteración posterior de los datos se detecta.
    await consulta("UPDATE inscripciones SET nota_final = 19 WHERE id_inscripcion = $1", [aprobado.id_inscripcion]);
    expect((await api().get(`/api/verificar/${codigo_unico}`)).body.integro).toBe(false);
    expect((await api().get('/api/verificar/SIGC-2026-NOEXISTE00')).status).toBe(404);
  });

  it('emite certificados en lote solo con el acta cerrada y sin duplicar (RNF-02: 100 en < 15 s)', async () => {
    const id = await crearCurso({ vacantes_max: 100, numero_sesiones: 1, asistencia_minima: 0 });
    expect((await api().post(`/api/capacitaciones/${id}/certificados`).set(bearer(docente.token))).status).toBe(409);
    await consulta(
      `INSERT INTO usuarios (dni, nombres, apellidos, correo, password_hash, rol)
       SELECT (71000000 + g)::text, 'Participante', 'Lote ' || g, 'lote' || g || '@prueba.pe', 'x', 'Participante' FROM generate_series(1, 100) g`);
    await consulta(
      `INSERT INTO inscripciones (id_capacitacion, id_participante, nota_final)
       SELECT $1, id_usuario, 14 FROM usuarios WHERE dni LIKE '710%'`, [id]);
    expect((await api().post(`/api/capacitaciones/${id}/acta/cerrar`).set(bearer(docente.token))).body.aprobados).toBe(100);
    const lote = await api().post(`/api/capacitaciones/${id}/certificados`).set(bearer(docente.token));
    expect(lote.status).toBe(200);
    expect(lote.body.emitidos).toBe(100);
    // La instrumentación de cobertura hace más lento el PDF; el límite se mide en la corrida normal (npm test).
    if (!process.env.COBERTURA) expect(lote.body.milisegundos).toBeLessThan(15000);
    console.log(`RNF-02: 100 certificados emitidos en ${lote.body.milisegundos} ms`);
    const otraVez = await api().post(`/api/capacitaciones/${id}/certificados`).set(bearer(docente.token));
    expect(otraVez.body).toMatchObject({ emitidos: 0, ya_existian: 100 });
  }, 60000);
});

describe('HU-09 · reportes para auditoría', () => {
  it('resume por capacitación y respeta la institución del coordinador', async () => {
    const id = await crearCurso({ vacantes_max: 4 });
    await inscribir(id, '70123450');
    await inscribir(id, '70123451');
    await api().post('/api/capacitaciones').set(bearer(admin.token)).send(cursoValido(hotel));
    const r = await api().get('/api/reportes/resumen').set(bearer(coord.token));
    expect(r.status).toBe(200);
    expect(r.body.totales).toMatchObject({ capacitaciones: 1, inscritos: 2 });
    expect(r.body.capacitaciones[0].ocupacion).toBe(50);
    expect((await api().get('/api/reportes/resumen').set(bearer(admin.token))).body.totales.capacitaciones).toBe(2);
    expect((await api().get('/api/reportes/resumen').set(bearer(docente.token))).status).toBe(403);
  });

  it('exporta el padrón en Excel y PDF', async () => {
    const id = await crearCurso();
    await inscribir(id, '70123450');
    const xlsx = await api().get(`/api/reportes/capacitaciones/${id}/excel`).set(bearer(coord.token));
    expect(xlsx.status).toBe(200);
    expect(xlsx.headers['content-type']).toContain('spreadsheetml');
    const pdf = await api().get(`/api/reportes/capacitaciones/${id}/pdf`).set(bearer(docente.token));
    expect(pdf.status).toBe(200);
    expect(pdf.headers['content-type']).toContain('application/pdf');
  });
});

describe('robustez', () => {
  it('responde 404 en rutas inexistentes y 400 ante JSON mal formado', async () => {
    expect((await api().get('/api/no-existe')).status).toBe(404);
    const r = await api().post('/api/auth/login').set('Content-Type', 'application/json').send('{"usuario":');
    expect(r.status).toBe(400);
    expect((await api().get('/api/capacitaciones/abc')).status).toBe(400);
    expect((await api().get('/api/salud')).body).toEqual({ estado: 'ok' });
  });
});
