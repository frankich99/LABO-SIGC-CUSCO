# SIGC-CUSCO · Código fuente (Incremento 1)

## Arquitectura

```
Navegador (React 18 + Vite + Tailwind 4, PWA)
   │  HTTPS · JSON · JWT Bearer
   ▼
API REST (Node.js 22 + Express 5 + TypeScript)
   ├── middleware/auth.ts      RBAC: el rol se relee de la base en cada petición
   ├── domain/                 reglas puras con pruebas TDD (DNI, cupos, notas, firmas)
   ├── routes/                 auth, administración, capacitaciones, inscripciones,
   │                           asistencias, evaluación/certificados, reportes
   └── services/               PDF (PDFKit + QR), Excel (ExcelJS), correo (Nodemailer)
   │
   ▼
PostgreSQL 16 (sql/001_esquema.sql) + carpeta storage/ con los PDF emitidos
```

## Historias implementadas

| Jira | Historia | Dónde |
| --- | --- | --- |
| SIGC-1 | Roles y permisos (RBAC) | `middleware/auth.ts`, `routes/administracion.ts`, página Usuarios |
| SIGC-2 | Crear y configurar capacitaciones | `routes/capacitaciones.ts`, página Crear capacitación |
| SIGC-3 | Inscripción con DNI y control de vacantes | `routes/inscripciones.ts` (`SELECT … FOR UPDATE`) |
| SIGC-4 | Asistencia por QR dinámico | `routes/asistencias.ts`, `domain/firma.ts` (HMAC, vence en 90 s) |
| SIGC-5 | Notas y cálculo de aprobación | `routes/evaluacion.ts`, `domain/evaluacion.ts` |
| SIGC-6 | Certificado PDF con QR | `services/certificados.ts`, `services/pdf.ts` |
| SIGC-7 | Multientidad | `instituciones`, coordinador limitado a su institución |
| SIGC-8 | Verificación pública | `/api/verificar/:codigo`, página Verificar (huella del PDF en el navegador) |
| SIGC-9 | Tablero y reportes Excel/PDF | `routes/reportes.ts`, página Reportes |
| SIGC-10 | Correo de confirmación | `services/correo.ts` (sin SMTP queda como «Simulado») |
| SIGC-11 | Catálogo público | `GET /api/capacitaciones`, página Capacitaciones |
| SIGC-12 | Asistencia sin conexión | `frontend/src/cola.ts` (IndexedDB), `public/sw.js`, `POST …/asistencias/sync` |

## Reglas de negocio

- Cupos disponibles = vacantes − inscripciones no anuladas; nunca negativo. Las inscripciones simultáneas no superan el cupo.
- DNI: 8 dígitos, no todos iguales. Un DNI con cuenta debe dar su contraseña.
- Aprobado: nota ≥ 11 (0–20) **y** asistencia ≥ mínimo del curso (75 % por defecto). Presente y tardanza cuentan.
- El acta cerrada bloquea notas y asistencia; el curso pasa a «Finalizada».
- Certificado: uno por inscripción aprobada. Huella SHA-256 sobre código, DNI, nombre, curso, institución, horas, nota y fecha. Si alguien altera esos datos en la base, la verificación pública lo muestra.

## Variables de entorno

Ver `backend/.env.example`. En producción `JWT_SECRET` y `QR_SECRET` son obligatorias.

## Pruebas

`backend/tests/dominio.test.ts` (reglas puras, escritas primero) y `backend/tests/api.test.ts` (integración HTTP contra PostgreSQL). La prueba de lote verifica el RNF-02: 100 certificados en menos de 15 s.
