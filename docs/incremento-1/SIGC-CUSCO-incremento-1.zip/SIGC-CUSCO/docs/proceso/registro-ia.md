# Política y registro de uso de IA · SIGC-CUSCO

## Política

1. **La IA asiste; el equipo decide.** Aceptar requisitos, aprobar un pull request e integrar a `main` son decisiones humanas.
2. **Usos permitidos:** borradores de código y pruebas, explicación de errores, sugerencias de revisión, borradores de documentación y casos de prueba.
3. **Usos no permitidos:** pegar datos personales reales (DNI, notas, correos de participantes), secretos (`JWT_SECRET`, contraseñas) o documentos internos de las instituciones; aprobar un PR solo porque la IA dice que el código es correcto.
4. **Verificación obligatoria:** todo código sugerido pasa por `npm test`, `npm run lint`, `npm run typecheck`, CI en verde y la revisión de otra persona que pueda explicar el cambio.
5. **Registro:** cada uso que termine en el repositorio se anota abajo y se enlaza en el PR (casilla de la plantilla).
6. **Revisión de la política:** en cada retrospectiva, con el dato de cuántos cambios asistidos por IA fueron rechazados o corregidos en revisión.

## Formato de registro

| Campo | Qué anotar |
| --- | --- |
| Fecha | AAAA-MM-DD |
| Herramienta / modelo | Nombre y versión |
| Persona que la usó | Integrante |
| Tarea o PR | Historia de Jira o número de PR |
| Propósito | Qué se pidió |
| Contexto entregado | Qué información se compartió (sin datos personales) |
| Propuesta aceptada | Qué se incorporó |
| Cambios humanos | Qué se corrigió o descartó |
| Pruebas | Evidencia de verificación |
| Revisor y decisión | Quién revisó y qué decidió |

## Registro

### 2026-10-06 · Incremento 1 (rama `incremento-1`)

| Campo | Valor |
| --- | --- |
| Herramienta / modelo | Claude (Anthropic), modelo Claude Opus 5.5, en claude.ai |
| Persona que la usó | Yaranga Achahui, Aldo (Product Owner) |
| Tarea o PR | SIGC-1 a SIGC-12; informe del Incremento 1 |
| Propósito | Generar el primer incremento funcional a partir del backlog de Jira, la especificación v2 y las diapositivas del curso; redactar el informe del proceso |
| Contexto entregado | Repositorio público SIGC-CUSCO (backlog, especificación v2, DDL), diapositivas «Introducción a la IS» y «Comparación y adaptación de métodos», estructura del informe. Sin datos personales: los datos de demostración son ficticios |
| Propuesta aceptada | Backend, frontend, esquema SQL, pruebas, CI, Docker, README y borrador del informe |
| Cambios respecto a lo especificado | El esquema v2 se amplió (asistencia mínima, cierre de acta, `hash_pdf`, notificaciones); el rol «Alumno» se llamó «Participante» como en las historias |
| Pruebas | 52 pruebas Vitest en verde, 92 % de líneas cubiertas, lint y tipos sin advertencias, recorrido completo en navegador con capturas |
| Revisor y decisión | **Pendiente.** Antes de integrar a `main`: revisión del Tech Lead (Noe Franklin Choquenaira) y de la Scrum Master (Carolay Ccama), que deben poder explicar cada módulo |
